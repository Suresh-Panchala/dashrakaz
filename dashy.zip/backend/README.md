# StormWater Monitoring Backend

Backend server for StormWater Monitoring Dashboard with MQTT integration and MongoDB storage.

## 🚀 Features

- ✅ Real-time MQTT data subscription and storage
- ✅ MongoDB integration for historical data
- ✅ RESTful API for data retrieval and filtering
- ✅ CSV export functionality
- ✅ PDF report generation
- ✅ Date range queries and aggregation
- ✅ Statistics and analytics endpoints
- ✅ CORS enabled for frontend integration
- ✅ Rate limiting and security headers

## 📋 Prerequisites

- Node.js 16+ and npm
- MongoDB installed and running
- Mosquitto MQTT broker installed and running
- Ubuntu VPS (for production deployment)

## 🔧 Installation

### 1. Install Dependencies

```bash
cd backend
npm install
```

### 2. Configure Environment Variables

Create a `.env` file in the backend directory:

```bash
cp config.example.env .env
```

Edit `.env` file with your configuration:

```env
# Server Configuration
PORT=5000
NODE_ENV=production

# MongoDB Configuration
MONGODB_URI=mongodb://localhost:27017/stormwater

# MQTT Configuration
MQTT_BROKER_URL=mqtt://localhost:1883
MQTT_TOPIC=stromwater/khusam/device1/data

# CORS Configuration
FRONTEND_URL=http://localhost:3000
```

### 3. Start MongoDB

```bash
sudo systemctl start mongod
sudo systemctl status mongod
```

### 4. Start Mosquitto

```bash
sudo systemctl start mosquitto
sudo systemctl status mosquitto
```

### 5. Start Backend Server

**Development:**
```bash
npm run dev
```

**Production:**
```bash
npm start
```

## 🌐 API Endpoints

### Health Check
```
GET /api/health
```

### Data Endpoints

- **Latest Data**: `GET /api/data/latest/:deviceId?limit=10`
- **Historical Data**: `GET /api/data/history/:deviceId?page=1&limit=100`
- **Statistics**: `GET /api/data/stats/:deviceId?hours=24`
- **Date Range**: `GET /api/data/range/:deviceId?startDate=...&endDate=...&interval=hour`
- **Export CSV**: `GET /api/data/export/csv/:deviceId?startDate=...&endDate=...`
- **Export PDF**: `GET /api/data/export/pdf/:deviceId?startDate=...&endDate=...`
- **All Devices**: `GET /api/data/devices`
- **Device Info**: `GET /api/data/device/:deviceId`

## 🐳 Deployment on Ubuntu VPS

### Step 1: Update System

```bash
sudo apt update && sudo apt upgrade -y
```

### Step 2: Install Node.js

```bash
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs
node --version
npm --version
```

### Step 3: Install MongoDB (if not already installed)

```bash
sudo apt install -y mongodb
sudo systemctl start mongodb
sudo systemctl enable mongodb
```

### Step 4: Install Mosquitto (if not already installed)

```bash
sudo apt install -y mosquitto mosquitto-clients
sudo systemctl start mosquitto
sudo systemctl enable mosquitto
```

### Step 5: Clone and Setup Project

```bash
cd /var/www
sudo mkdir stormwater
sudo chown $USER:$USER stormwater
cd stormwater

# Upload your backend folder here
# Or clone from git repository
```

### Step 6: Install Dependencies

```bash
cd backend
npm install --production
```

### Step 7: Configure Environment

```bash
cp config.example.env .env
nano .env
```

Update with your VPS settings:
```env
PORT=5000
NODE_ENV=production
MONGODB_URI=mongodb://localhost:27017/stormwater
MQTT_BROKER_URL=mqtt://localhost:1883
MQTT_TOPIC=stromwater/khusam/device1/data
FRONTEND_URL=http://your-vps-ip:3000
```

### Step 8: Install PM2 for Process Management

```bash
sudo npm install -g pm2
```

### Step 9: Start Backend with PM2

```bash
pm2 start server.js --name stormwater-backend
pm2 save
pm2 startup
```

### Step 10: Configure Nginx (Optional - Recommended)

```bash
sudo apt install -y nginx

sudo nano /etc/nginx/sites-available/stormwater-backend
```

Add this configuration:

```nginx
server {
    listen 80;
    server_name your-domain.com;

    location /api {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Enable the site:

```bash
sudo ln -s /etc/nginx/sites-available/stormwater-backend /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### Step 11: Configure Firewall

```bash
sudo ufw allow 5000
sudo ufw allow 80
sudo ufw allow 443
sudo ufw enable
```

## 📊 Monitoring

### View PM2 Logs

```bash
pm2 logs stormwater-backend
```

### View PM2 Status

```bash
pm2 status
```

### Restart Backend

```bash
pm2 restart stormwater-backend
```

### Stop Backend

```bash
pm2 stop stormwater-backend
```

## 🔍 Troubleshooting

### Check MongoDB Status

```bash
sudo systemctl status mongodb
```

### Check Mosquitto Status

```bash
sudo systemctl status mosquitto
```

### Test MQTT Connection

```bash
mosquitto_sub -h localhost -t "stromwater/khusam/device1/data" -v
```

### Check Backend Logs

```bash
pm2 logs stormwater-backend --lines 100
```

### Test API Health

```bash
curl http://localhost:5000/api/health
```

## 📝 Database Maintenance

### Backup MongoDB

```bash
mongodump --db stormwater --out /backup/mongodb/$(date +%Y%m%d)
```

### Restore MongoDB

```bash
mongorestore --db stormwater /backup/mongodb/20240101/stormwater
```

### View Database Size

```bash
mongo
> use stormwater
> db.stats()
```

## 🔒 Security Recommendations

1. **Enable MongoDB Authentication**:
```bash
mongo
> use admin
> db.createUser({user: "admin", pwd: "secure_password", roles: ["root"]})
```

2. **Enable Mosquitto Authentication**:
```bash
sudo mosquitto_passwd -c /etc/mosquitto/passwd username
```

Update `/etc/mosquitto/mosquitto.conf`:
```
allow_anonymous false
password_file /etc/mosquitto/passwd
```

3. **Use HTTPS with Let's Encrypt**:
```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```

## 📞 Support

For issues or questions, check the logs and ensure all services are running properly.

