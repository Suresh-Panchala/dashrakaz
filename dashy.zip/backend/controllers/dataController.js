const SensorData = require('../models/SensorData');
const Device = require('../models/Device');
const { exportToCSV } = require('../utils/csvExporter');
const { exportToPDF } = require('../utils/pdfExporter');

// Get latest data for a device
exports.getLatestData = async (req, res) => {
  try {
    const { deviceId } = req.params;
    const limit = parseInt(req.query.limit) || 1;

    const data = await SensorData
      .find({ deviceId })
      .sort({ timestamp: -1 })
      .limit(limit);

    res.json({
      success: true,
      count: data.length,
      data
    });
  } catch (error) {
    console.error('Error fetching latest data:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch latest data'
    });
  }
};

// Get historical data with pagination and filters
exports.getHistoricalData = async (req, res) => {
  try {
    const { deviceId } = req.params;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 100;
    const skip = (page - 1) * limit;

    // Build query
    const query = { deviceId };

    // Date filters
    if (req.query.startDate || req.query.endDate) {
      query.timestamp = {};
      if (req.query.startDate) {
        query.timestamp.$gte = new Date(req.query.startDate);
      }
      if (req.query.endDate) {
        query.timestamp.$lte = new Date(req.query.endDate);
      }
    }

    // Get total count
    const total = await SensorData.countDocuments(query);

    // Get data
    const data = await SensorData
      .find(query)
      .sort({ timestamp: -1 })
      .skip(skip)
      .limit(limit);

    res.json({
      success: true,
      data,
      pagination: {
        total,
        page,
        limit,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('Error fetching historical data:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch historical data'
    });
  }
};

// Get statistics/aggregated data
exports.getStatistics = async (req, res) => {
  try {
    const { deviceId } = req.params;
    const hours = parseInt(req.query.hours) || 24;
    
    const startDate = new Date();
    startDate.setHours(startDate.getHours() - hours);

    const stats = await SensorData.aggregate([
      {
        $match: {
          deviceId,
          timestamp: { $gte: startDate }
        }
      },
      {
        $group: {
          _id: null,
          avgVoltageR: { $avg: '$voltageR' },
          avgVoltageY: { $avg: '$voltageY' },
          avgVoltageB: { $avg: '$voltageB' },
          avgCurrentR: { $avg: '$currentR' },
          avgCurrentY: { $avg: '$currentY' },
          avgCurrentB: { $avg: '$currentB' },
          avgKW: { $avg: '$kw' },
          avgKVA: { $avg: '$kva' },
          avgKVAR: { $avg: '$kvar' },
          avgPF: { $avg: '$powerFactor' },
          avgFrequency: { $avg: '$frequency' },
          maxKW: { $max: '$kw' },
          minKW: { $min: '$kw' },
          totalRecords: { $sum: 1 }
        }
      }
    ]);

    res.json({
      success: true,
      period: `${hours} hours`,
      stats: stats[0] || {}
    });
  } catch (error) {
    console.error('Error fetching statistics:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch statistics'
    });
  }
};

// Get data for a specific date range
exports.getDateRangeData = async (req, res) => {
  try {
    const { deviceId } = req.params;
    const { startDate, endDate, interval } = req.query;

    if (!startDate || !endDate) {
      return res.status(400).json({
        success: false,
        error: 'Start date and end date are required'
      });
    }

    const query = {
      deviceId,
      timestamp: {
        $gte: new Date(startDate),
        $lte: new Date(endDate)
      }
    };

    let data;

    // If interval is specified, aggregate data by interval
    if (interval) {
      const groupBy = getGroupByInterval(interval);
      data = await SensorData.aggregate([
        { $match: query },
        {
          $group: {
            _id: groupBy,
            avgVoltageR: { $avg: '$voltageR' },
            avgVoltageY: { $avg: '$voltageY' },
            avgVoltageB: { $avg: '$voltageB' },
            avgCurrentR: { $avg: '$currentR' },
            avgCurrentY: { $avg: '$currentY' },
            avgCurrentB: { $avg: '$currentB' },
            avgKW: { $avg: '$kw' },
            avgKVA: { $avg: '$kva' },
            avgKVAR: { $avg: '$kvar' },
            avgPF: { $avg: '$powerFactor' },
            avgFrequency: { $avg: '$frequency' },
            timestamp: { $first: '$timestamp' }
          }
        },
        { $sort: { timestamp: 1 } }
      ]);
    } else {
      // Return all data points
      data = await SensorData
        .find(query)
        .sort({ timestamp: 1 })
        .limit(10000); // Safety limit
    }

    res.json({
      success: true,
      count: data.length,
      data
    });
  } catch (error) {
    console.error('Error fetching date range data:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch date range data'
    });
  }
};

// Export data as CSV
exports.exportCSV = async (req, res) => {
  try {
    const { deviceId } = req.params;
    const { startDate, endDate } = req.query;

    const query = { deviceId };
    if (startDate || endDate) {
      query.timestamp = {};
      if (startDate) query.timestamp.$gte = new Date(startDate);
      if (endDate) query.timestamp.$lte = new Date(endDate);
    }

    const data = await SensorData
      .find(query)
      .sort({ timestamp: 1 })
      .limit(50000)
      .lean();

    if (data.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'No data found for export'
      });
    }

    const csv = await exportToCSV(data);
    
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename=stormwater_data_${deviceId}_${Date.now()}.csv`);
    res.send(csv);
  } catch (error) {
    console.error('Error exporting CSV:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to export CSV'
    });
  }
};

// Export data as PDF
exports.exportPDF = async (req, res) => {
  try {
    const { deviceId } = req.params;
    const { startDate, endDate } = req.query;

    const query = { deviceId };
    if (startDate || endDate) {
      query.timestamp = {};
      if (startDate) query.timestamp.$gte = new Date(startDate);
      if (endDate) query.timestamp.$lte = new Date(endDate);
    }

    const data = await SensorData
      .find(query)
      .sort({ timestamp: 1 })
      .limit(1000)
      .lean();

    if (data.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'No data found for export'
      });
    }

    const device = await Device.findOne({ deviceId });
    
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename=stormwater_report_${deviceId}_${Date.now()}.pdf`);
    
    await exportToPDF(data, device, res);
  } catch (error) {
    console.error('Error exporting PDF:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to export PDF'
    });
  }
};

// Get all devices
exports.getAllDevices = async (req, res) => {
  try {
    const devices = await Device.find({ isActive: true });
    res.json({
      success: true,
      count: devices.length,
      data: devices
    });
  } catch (error) {
    console.error('Error fetching devices:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch devices'
    });
  }
};

// Get device info
exports.getDeviceInfo = async (req, res) => {
  try {
    const { deviceId } = req.params;
    const device = await Device.findOne({ deviceId });
    
    if (!device) {
      return res.status(404).json({
        success: false,
        error: 'Device not found'
      });
    }

    res.json({
      success: true,
      data: device
    });
  } catch (error) {
    console.error('Error fetching device info:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch device info'
    });
  }
};

// Helper function to get group by interval
function getGroupByInterval(interval) {
  switch (interval) {
    case 'hour':
      return {
        year: { $year: '$timestamp' },
        month: { $month: '$timestamp' },
        day: { $dayOfMonth: '$timestamp' },
        hour: { $hour: '$timestamp' }
      };
    case 'day':
      return {
        year: { $year: '$timestamp' },
        month: { $month: '$timestamp' },
        day: { $dayOfMonth: '$timestamp' }
      };
    case 'month':
      return {
        year: { $year: '$timestamp' },
        month: { $month: '$timestamp' }
      };
    default:
      return '$timestamp';
  }
}

