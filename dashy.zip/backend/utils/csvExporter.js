const { Parser } = require('json2csv');

exports.exportToCSV = async (data) => {
  try {
    // Define fields for CSV
    const fields = [
      { label: 'Timestamp', value: 'timestamp' },
      { label: 'Device ID', value: 'deviceId' },
      { label: 'Device Name', value: 'deviceName' },
      
      // Voltage
      { label: 'Voltage R (V)', value: 'voltageR' },
      { label: 'Voltage Y (V)', value: 'voltageY' },
      { label: 'Voltage B (V)', value: 'voltageB' },
      
      // Current
      { label: 'Current R (A)', value: 'currentR' },
      { label: 'Current Y (A)', value: 'currentY' },
      { label: 'Current B (A)', value: 'currentB' },
      
      // Power
      { label: 'KW', value: 'kw' },
      { label: 'KVA', value: 'kva' },
      { label: 'KVAR', value: 'kvar' },
      { label: 'Power Factor', value: 'powerFactor' },
      { label: 'Frequency (Hz)', value: 'frequency' },
      
      // Pump 1
      { label: 'Pump 1 Manual', value: 'pump1.manual' },
      { label: 'Pump 1 Auto', value: 'pump1.auto' },
      { label: 'Pump 1 RHS', value: 'pump1.rhs' },
      
      // Pump 2
      { label: 'Pump 2 Manual', value: 'pump2.manual' },
      { label: 'Pump 2 Auto', value: 'pump2.auto' },
      { label: 'Pump 2 RHS', value: 'pump2.rhs' },
      
      // Pump 3
      { label: 'Pump 3 Manual', value: 'pump3.manual' },
      { label: 'Pump 3 Auto', value: 'pump3.auto' },
      { label: 'Pump 3 RHS', value: 'pump3.rhs' },
      
      // Pump 4
      { label: 'Pump 4 Manual', value: 'pump4.manual' },
      { label: 'Pump 4 Auto', value: 'pump4.auto' },
      { label: 'Pump 4 RHS', value: 'pump4.rhs' }
    ];

    const parser = new Parser({ fields });
    const csv = parser.parse(data);
    
    return csv;
  } catch (error) {
    console.error('Error generating CSV:', error);
    throw error;
  }
};

