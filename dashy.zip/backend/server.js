require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const connectDB = require('./config/database');
const mqttService = require('./services/mqttService');
const dataRoutes = require('./routes/dataRoutes');

const app = express();
const PORT = process.env.PORT || 5000;

// Security middleware
app.use(helmet());

// CORS configuration
const corsOptions = {
  origin: process.env.FRONTEND_URL || '*',
  credentials: true,
  optionsSuccessStatus: 200
};
app.use(cors(corsOptions));

// Compression middleware
app.use(compression());

// Body parser
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // Limit each IP to 100 requests per windowMs
  message: 'Too many requests from this IP, please try again later.'
});
app.use('/api/', limiter);

// Connect to MongoDB
connectDB();

// Connect to MQTT Broker and subscribe to topics
const initializeMQTT = () => {
  const brokerUrl = process.env.MQTT_BROKER_URL || 'mqtt://localhost:1883';
  const topic = process.env.MQTT_TOPIC || 'stromwater/khusam/device1/data';
  const deviceId = 'device1';
  const deviceName = 'StormWater Device 1';

  mqttService.connect(brokerUrl);
  mqttService.subscribe(topic, deviceId, deviceName);
};

// Initialize MQTT after a short delay to ensure DB is ready
setTimeout(initializeMQTT, 2000);

// API Routes
app.use('/api/data', dataRoutes);

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date(),
    mqtt: mqttService.getConnectionStatus(),
    database: mongoose.connection.readyState === 1
  });
});

// Root endpoint
app.get('/', (req, res) => {
  res.json({
    message: 'StormWater Monitoring API',
    version: '1.0.0',
    endpoints: {
      health: '/api/health',
      latestData: '/api/data/latest/:deviceId',
      historicalData: '/api/data/history/:deviceId',
      statistics: '/api/data/stats/:deviceId',
      dateRange: '/api/data/range/:deviceId',
      exportCSV: '/api/data/export/csv/:deviceId',
      exportPDF: '/api/data/export/pdf/:deviceId',
      devices: '/api/data/devices'
    }
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(err.status || 500).json({
    success: false,
    error: err.message || 'Internal Server Error'
  });
});

// Handle 404
app.use((req, res) => {
  res.status(404).json({
    success: false,
    error: 'Route not found'
  });
});

// Start server
app.listen(PORT, () => {
  console.log('='.repeat(50));
  console.log('🚀 StormWater Monitoring Backend Server');
  console.log('='.repeat(50));
  console.log(`📡 Server running on port ${PORT}`);
  console.log(`🌍 Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`🔗 API URL: http://localhost:${PORT}`);
  console.log('='.repeat(50));
});

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\n⚠️ Shutting down gracefully...');
  mqttService.disconnect();
  mongoose.connection.close(() => {
    console.log('✅ MongoDB connection closed');
    process.exit(0);
  });
});

process.on('SIGTERM', () => {
  console.log('\n⚠️ SIGTERM received, shutting down...');
  mqttService.disconnect();
  mongoose.connection.close(() => {
    console.log('✅ MongoDB connection closed');
    process.exit(0);
  });
});

module.exports = app;

