import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useDevices } from '../context/DeviceContext';
import DeviceManager from './DeviceManager';
import './Header.css';

const Header = ({ isConnected }) => {
  const { user, logout } = useAuth();
  const { selectedDevice, devices, selectDevice } = useDevices();
  const [showDeviceManager, setShowDeviceManager] = useState(false);
  const [showDeviceDropdown, setShowDeviceDropdown] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);

  return (
    <>
      <header className="modern-header">
        <div className="header-container">
          <div className="header-left">
            <div className="logo-section">
              <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="20" cy="20" r="18" fill="url(#headerGradient)" opacity="0.2"/>
                <path d="M20 8C20 8 14 13 14 19C14 22.3137 16.6863 25 20 25C23.3137 25 26 22.3137 26 19C26 13 20 8 20 8Z"
                      fill="url(#headerGradient)" stroke="white" strokeWidth="1.5"/>
                <circle cx="20" cy="30" r="2" fill="#60a5fa"/>
                <defs>
                  <linearGradient id="headerGradient" x1="20" y1="8" x2="20" y2="32" gradientUnits="userSpaceOnUse">
                    <stop stopColor="#60a5fa"/>
                    <stop offset="1" stopColor="#3b82f6"/>
                  </linearGradient>
                </defs>
              </svg>
              <div className="logo-text">
                <h1>StormWater</h1>
                <span>Monitoring System</span>
              </div>
            </div>

            {selectedDevice && (
              <div className="device-selector">
                <button
                  className="device-dropdown-button"
                  onClick={() => setShowDeviceDropdown(!showDeviceDropdown)}
                >
                  <div className="device-info-compact">
                    <span className="device-name">{selectedDevice.name}</span>
                    <span className="device-location">{selectedDevice.location}</span>
                  </div>
                  <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                    <path d="M6 8L10 12L14 8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </button>

                {showDeviceDropdown && (
                  <div className="device-dropdown-menu">
                    {devices.map((device) => (
                      <button
                        key={device.id}
                        className={`device-dropdown-item ${selectedDevice?.id === device.id ? 'active' : ''}`}
                        onClick={() => {
                          selectDevice(device);
                          setShowDeviceDropdown(false);
                        }}
                      >
                        <div className="dropdown-device-info">
                          <span className="dropdown-device-name">{device.name}</span>
                          <span className="dropdown-device-location">{device.location}</span>
                        </div>
                        {selectedDevice?.id === device.id && (
                          <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                            <path d="M3 8L6 11L13 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                          </svg>
                        )}
                      </button>
                    ))}
                    <div className="dropdown-divider"></div>
                    <button
                      className="device-dropdown-item manage"
                      onClick={() => {
                        setShowDeviceManager(true);
                        setShowDeviceDropdown(false);
                      }}
                    >
                      <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                        <path d="M8 3V13M3 8H13" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                      </svg>
                      Manage Devices
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="header-right">
            <div className="connection-indicator">
              <div className={`status-dot ${isConnected ? 'connected' : 'disconnected'}`}></div>
              <span>{isConnected ? 'Connected' : 'Disconnected'}</span>
            </div>

            <button className="icon-button" onClick={() => setShowDeviceManager(true)}>
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                <rect x="3" y="4" width="14" height="12" rx="2" stroke="currentColor" strokeWidth="1.5"/>
                <path d="M7 8H13M7 12H10" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
              </svg>
            </button>

            <div className="user-menu-container">
              <button
                className="user-avatar"
                onClick={() => setShowUserMenu(!showUserMenu)}
              >
                <div className="avatar-circle">
                  {user?.name?.charAt(0).toUpperCase() || 'U'}
                </div>
                <span className="user-name">{user?.name || 'User'}</span>
              </button>

              {showUserMenu && (
                <div className="user-dropdown-menu">
                  <div className="user-dropdown-header">
                    <div className="avatar-circle large">
                      {user?.name?.charAt(0).toUpperCase() || 'U'}
                    </div>
                    <div className="user-dropdown-info">
                      <span className="user-dropdown-name">{user?.name}</span>
                      <span className="user-dropdown-email">{user?.email}</span>
                    </div>
                  </div>
                  <div className="dropdown-divider"></div>
                  <button className="user-dropdown-item" onClick={logout}>
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                      <path d="M6 14H3C2.44772 14 2 13.5523 2 13V3C2 2.44772 2.44772 2 3 2H6M11 11L14 8M14 8L11 5M14 8H6"
                            stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                    Logout
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {showDeviceManager && <DeviceManager onClose={() => setShowDeviceManager(false)} />}
    </>
  );
};

export default Header;
