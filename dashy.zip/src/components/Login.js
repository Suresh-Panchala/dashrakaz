import React, { useState } from 'react';
import './Login.css';

const Login = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    // Simulate API call delay
    setTimeout(() => {
      const result = onLogin(email, password);
      if (!result.success) {
        setError(result.error || 'Login failed');
      }
      setIsLoading(false);
    }, 800);
  };

  return (
    <div className="login-container">
      <div className="login-background">
        <div className="animated-bg"></div>
        <div className="animated-bg-layer2"></div>
      </div>

      <div className="login-card">
        <div className="login-header">
          <div className="logo-container">
            <svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="30" cy="30" r="28" fill="url(#gradient)" opacity="0.2"/>
              <path d="M30 10C30 10 20 18 20 28C20 33.5228 24.4772 38 30 38C35.5228 38 40 33.5228 40 28C40 18 30 10 30 10Z"
                    fill="url(#gradient)" stroke="white" strokeWidth="2"/>
              <circle cx="30" cy="45" r="3" fill="#3b82f6"/>
              <defs>
                <linearGradient id="gradient" x1="30" y1="10" x2="30" y2="50" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#60a5fa"/>
                  <stop offset="1" stopColor="#3b82f6"/>
                </linearGradient>
              </defs>
            </svg>
          </div>
          <h1>StormWater</h1>
          <p>Monitoring System</p>
        </div>

        <form onSubmit={handleSubmit} className="login-form">
          <div className="form-group">
            <label htmlFor="email">Email Address</label>
            <div className="input-wrapper">
              <svg className="input-icon" width="20" height="20" viewBox="0 0 20 20" fill="none">
                <path d="M3 6L10 11L17 6M3 6V14C3 14.5523 3.44772 15 4 15H16C16.5523 15 17 14.5523 17 14V6M3 6C3 5.44772 3.44772 5 4 5H16C16.5523 5 17 5.44772 17 6"
                      stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
              </svg>
              <input
                id="email"
                type="email"
                placeholder="admin@stormwater.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
          </div>

          <div className="form-group">
            <label htmlFor="password">Password</label>
            <div className="input-wrapper">
              <svg className="input-icon" width="20" height="20" viewBox="0 0 20 20" fill="none">
                <rect x="5" y="9" width="10" height="7" rx="1" stroke="currentColor" strokeWidth="2"/>
                <path d="M7 9V6C7 4.34315 8.34315 3 10 3C11.6569 3 13 4.34315 13 6V9"
                      stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
              </svg>
              <input
                id="password"
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
          </div>

          {error && (
            <div className="error-message">
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                <circle cx="8" cy="8" r="7" stroke="currentColor" strokeWidth="2"/>
                <path d="M8 4V8M8 11H8.01" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
              </svg>
              {error}
            </div>
          )}

          <button type="submit" className="login-button" disabled={isLoading}>
            {isLoading ? (
              <>
                <span className="button-spinner"></span>
                Signing in...
              </>
            ) : (
              'Sign In'
            )}
          </button>
        </form>

        <div className="login-footer">
          <div style={{ marginBottom: '12px', padding: '12px', background: '#f0f9ff', borderRadius: '8px', border: '1px solid #bfdbfe' }}>
            <p style={{ margin: '0 0 8px 0', fontSize: '12px', fontWeight: '600', color: '#1e40af' }}>Demo Access Levels:</p>
            <p style={{ margin: '0 0 4px 0', fontSize: '11px', color: '#1e3a8a' }}>
              <strong>Admin:</strong> Use email with "admin" (e.g., admin@stormwater.com) + any password
            </p>
            <p style={{ margin: 0, fontSize: '11px', color: '#1e3a8a' }}>
              <strong>User:</strong> Any other email (e.g., user@example.com) + any password
            </p>
          </div>
          <p style={{ fontSize: '11px', color: '#6b7280', margin: 0 }}>
            Admin can add/edit/delete devices. User has read-only access.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
