import React, { useState } from 'react';
import './Sidebar.css';

const Sidebar = ({ currentView, onViewChange }) => {
  const [isCollapsed, setIsCollapsed] = useState(false);

  const menuItems = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: (
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
          <rect x="3" y="3" width="6" height="6" rx="1" stroke="currentColor" strokeWidth="1.5"/>
          <rect x="11" y="3" width="6" height="6" rx="1" stroke="currentColor" strokeWidth="1.5"/>
          <rect x="3" y="11" width="6" height="6" rx="1" stroke="currentColor" strokeWidth="1.5"/>
          <rect x="11" y="11" width="6" height="6" rx="1" stroke="currentColor" strokeWidth="1.5"/>
        </svg>
      ),
    },
    {
      id: 'historical',
      label: 'Historical',
      icon: (
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
          <path d="M10 4V10L14 12" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
          <path d="M3 10C3 6.13401 6.13401 3 10 3C13.866 3 17 6.13401 17 10C17 13.866 13.866 17 10 17C6.13401 17 3 13.866 3 10Z" stroke="currentColor" strokeWidth="1.5"/>
          <path d="M2 10H4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
        </svg>
      ),
    },
    {
      id: 'analytics',
      label: 'Analytics',
      icon: (
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
          <path d="M3 17V11M10 17V7M17 17V3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
        </svg>
      ),
    },
    {
      id: 'devices',
      label: 'Devices',
      icon: (
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
          <rect x="4" y="3" width="12" height="14" rx="2" stroke="currentColor" strokeWidth="1.5"/>
          <path d="M8 7H12M8 10H12" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
          <circle cx="10" cy="14" r="1" fill="currentColor"/>
        </svg>
      ),
    },
    {
      id: 'alerts',
      label: 'Alerts',
      icon: (
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
          <path d="M10 6V10M10 14H10.01M18 10C18 14.4183 14.4183 18 10 18C5.58172 18 2 14.4183 2 10C2 5.58172 5.58172 2 10 2C14.4183 2 18 5.58172 18 10Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
        </svg>
      ),
    },
    {
      id: 'users',
      label: 'Users',
      icon: (
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
          <circle cx="10" cy="7" r="3" stroke="currentColor" strokeWidth="1.5"/>
          <path d="M4 17C4 13.6863 6.68629 11 10 11C13.3137 11 16 13.6863 16 17" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
        </svg>
      ),
    },
    {
      id: 'settings',
      label: 'Settings',
      icon: (
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
          <path d="M10 12C11.1046 12 12 11.1046 12 10C12 8.89543 11.1046 8 10 8C8.89543 8 8 8.89543 8 10C8 11.1046 8.89543 12 10 12Z" stroke="currentColor" strokeWidth="1.5"/>
          <path d="M16.5 10C16.5 10.3 16.46 10.59 16.41 10.88L18.09 12.19C18.23 12.3 18.27 12.5 18.18 12.66L16.58 15.34C16.49 15.5 16.29 15.56 16.12 15.5L14.13 14.73C13.74 15.03 13.32 15.28 12.86 15.47L12.54 17.58C12.52 17.76 12.36 17.9 12.17 17.9H8.96C8.77 17.9 8.61 17.76 8.59 17.58L8.27 15.47C7.81 15.28 7.39 15.04 7 14.73L5.01 15.5C4.84 15.57 4.64 15.5 4.55 15.34L2.95 12.66C2.86 12.5 2.9 12.3 3.04 12.19L4.72 10.88C4.67 10.59 4.63 10.29 4.63 10C4.63 9.71 4.67 9.41 4.72 9.12L3.04 7.81C2.9 7.7 2.86 7.5 2.95 7.34L4.55 4.66C4.64 4.5 4.84 4.44 5.01 4.5L7 5.27C7.39 4.97 7.81 4.72 8.27 4.53L8.59 2.42C8.61 2.24 8.77 2.1 8.96 2.1H12.17C12.36 2.1 12.52 2.24 12.54 2.42L12.86 4.53C13.32 4.72 13.74 4.96 14.13 5.27L16.12 4.5C16.29 4.43 16.49 4.5 16.58 4.66L18.18 7.34C18.27 7.5 18.23 7.7 18.09 7.81L16.41 9.12C16.46 9.41 16.5 9.7 16.5 10Z" stroke="currentColor" strokeWidth="1.5"/>
        </svg>
      ),
    },
  ];

  return (
    <aside className={`sidebar ${isCollapsed ? 'collapsed' : ''}`}>
      <div className="sidebar-header">
        <div className="sidebar-logo">
          <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
            <circle cx="16" cy="16" r="14" fill="url(#sidebarGradient)" opacity="0.2"/>
            <path d="M16 6C16 6 12 10 12 15C12 17.7614 14.2386 20 17 20C19.7614 20 22 17.7614 22 15C22 10 16 6 16 6Z"
                  fill="url(#sidebarGradient)" stroke="white" strokeWidth="1.5"/>
            <circle cx="16" cy="24" r="1.5" fill="#4f46e5"/>
            <defs>
              <linearGradient id="sidebarGradient" x1="16" y1="6" x2="16" y2="26" gradientUnits="userSpaceOnUse">
                <stop stopColor="#6366f1"/>
                <stop offset="1" stopColor="#4f46e5"/>
              </linearGradient>
            </defs>
          </svg>
          {!isCollapsed && <span className="logo-text">StormWater</span>}
        </div>
        <button
          className="collapse-btn"
          onClick={() => setIsCollapsed(!isCollapsed)}
        >
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
            <path d="M12 6L8 10L12 14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"
                  style={{ transform: isCollapsed ? 'rotate(180deg)' : 'none', transformOrigin: 'center' }}/>
          </svg>
        </button>
      </div>

      <nav className="sidebar-nav">
        {menuItems.map((item) => (
          <button
            key={item.id}
            className={`nav-item ${currentView === item.id ? 'active' : ''}`}
            onClick={() => onViewChange(item.id)}
            title={isCollapsed ? item.label : ''}
          >
            <span className="nav-icon">{item.icon}</span>
            {!isCollapsed && <span className="nav-label">{item.label}</span>}
          </button>
        ))}
      </nav>

      <div className="sidebar-footer">
        <div className="user-profile">
          <div className="user-avatar-small">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <circle cx="8" cy="5" r="3" stroke="currentColor" strokeWidth="1.5"/>
              <path d="M2 14C2 11.2386 4.23858 9 7 9H9C11.7614 9 14 11.2386 14 14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
            </svg>
          </div>
          {!isCollapsed && (
            <div className="user-info-small">
              <span className="user-name-small">Admin</span>
              <span className="user-role">Administrator</span>
            </div>
          )}
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
