import React, { useState } from 'react';
import { useUsers } from '../context/UserContext';
import { useAuth } from '../context/AuthContext';
import './UsersPage.css';

const UsersPage = () => {
  const { user: currentUser } = useAuth();
  const { users, addUser, updateUser, deleteUser, toggleUserStatus } = useUsers();
  const [isAddingUser, setIsAddingUser] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    role: 'user',
    password: '',
  });

  const isAdmin = currentUser?.role === 'admin';

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingUser) {
      updateUser(editingUser.id, {
        name: formData.name,
        email: formData.email,
        role: formData.role,
      });
      setEditingUser(null);
    } else {
      addUser(formData);
      setIsAddingUser(false);
    }
    setFormData({
      name: '',
      email: '',
      role: 'user',
      password: '',
    });
  };

  const handleEdit = (user) => {
    setEditingUser(user);
    setFormData({
      name: user.name,
      email: user.email,
      role: user.role,
      password: '',
    });
    setIsAddingUser(true);
  };

  const handleCancel = () => {
    setIsAddingUser(false);
    setEditingUser(null);
    setFormData({
      name: '',
      email: '',
      role: 'user',
      password: '',
    });
  };

  const handleDelete = (userId) => {
    if (window.confirm('Are you sure you want to delete this user?')) {
      deleteUser(userId);
    }
  };

  if (!isAdmin) {
    return (
      <div className="users-page">
        <div className="access-denied">
          <svg width="80" height="80" viewBox="0 0 80 80" fill="none">
            <circle cx="40" cy="40" r="38" stroke="#ef4444" strokeWidth="2"/>
            <path d="M40 25V45M40 55H40.02" stroke="#ef4444" strokeWidth="3" strokeLinecap="round"/>
          </svg>
          <h2>Access Denied</h2>
          <p>You need administrator privileges to access user management.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="users-page">
      <div className="users-page-header">
        <div>
          <h2>User Management</h2>
          <p className="users-subtitle">
            Manage system users and their access levels
          </p>
        </div>
        <div className="header-actions">
          {!isAddingUser && (
            <button className="btn-add-user" onClick={() => setIsAddingUser(true)}>
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                <path d="M8 3V13M3 8H13" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
              </svg>
              Add User
            </button>
          )}
        </div>
      </div>

      {isAddingUser && (
        <div className="user-form-section">
          <div className="form-header">
            <h3>{editingUser ? 'Edit User' : 'Add New User'}</h3>
            <p>Fill in the user information below</p>
          </div>
          <form onSubmit={handleSubmit} className="user-form">
            <div className="form-grid">
              <div className="form-field">
                <label htmlFor="name">Full Name *</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  placeholder="e.g., John Doe"
                  required
                />
              </div>

              <div className="form-field">
                <label htmlFor="email">Email Address *</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  placeholder="e.g., john.doe@example.com"
                  required
                />
              </div>

              <div className="form-field">
                <label htmlFor="role">Role *</label>
                <select
                  id="role"
                  name="role"
                  value={formData.role}
                  onChange={handleInputChange}
                  required
                >
                  <option value="user">User</option>
                  <option value="admin">Admin</option>
                </select>
              </div>

              {!editingUser && (
                <div className="form-field">
                  <label htmlFor="password">Password *</label>
                  <input
                    type="password"
                    id="password"
                    name="password"
                    value={formData.password}
                    onChange={handleInputChange}
                    placeholder="Enter password"
                    required={!editingUser}
                  />
                </div>
              )}
            </div>

            <div className="form-actions">
              <button type="button" className="btn-cancel" onClick={handleCancel}>
                Cancel
              </button>
              <button type="submit" className="btn-submit">
                {editingUser ? 'Update User' : 'Add User'}
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="users-table-container">
        <table className="users-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Role</th>
              <th>Status</th>
              <th>Created</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.length === 0 ? (
              <tr>
                <td colSpan="6" className="empty-state">
                  <div className="empty-state-content">
                    <svg width="60" height="60" viewBox="0 0 60 60" fill="none">
                      <circle cx="30" cy="22" r="10" stroke="#d1d5db" strokeWidth="2"/>
                      <path d="M10 50C10 38.9543 18.9543 30 30 30C41.0457 30 50 38.9543 50 50" stroke="#d1d5db" strokeWidth="2" strokeLinecap="round"/>
                    </svg>
                    <p>No users found</p>
                  </div>
                </td>
              </tr>
            ) : (
              users.map(user => (
                <tr key={user.id}>
                  <td>
                    <div className="user-name-cell">
                      <div className="user-avatar-small">
                        {user.name.charAt(0).toUpperCase()}
                      </div>
                      <span>{user.name}</span>
                    </div>
                  </td>
                  <td>
                    <span className="user-email">{user.email}</span>
                  </td>
                  <td>
                    <span className={`role-badge ${user.role}`}>
                      {user.role === 'admin' ? (
                        <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                          <path d="M6 1L7.5 4.5L11 5L8 8L9 11.5L6 9.5L3 11.5L4 8L1 5L4.5 4.5L6 1Z" fill="currentColor"/>
                        </svg>
                      ) : (
                        <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                          <circle cx="6" cy="4" r="2" stroke="currentColor" strokeWidth="1.2"/>
                          <path d="M2 10C2 8.34315 3.79086 7 6 7C8.20914 7 10 8.34315 10 10" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"/>
                        </svg>
                      )}
                      {user.role.charAt(0).toUpperCase() + user.role.slice(1)}
                    </span>
                  </td>
                  <td>
                    <button
                      className={`status-toggle ${user.status}`}
                      onClick={() => toggleUserStatus(user.id)}
                    >
                      <div className="status-dot"></div>
                      {user.status.charAt(0).toUpperCase() + user.status.slice(1)}
                    </button>
                  </td>
                  <td>
                    <span className="date-text">
                      {new Date(user.createdAt).toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric'
                      })}
                    </span>
                  </td>
                  <td>
                    <div className="action-buttons">
                      <button
                        className="btn-action edit"
                        onClick={() => handleEdit(user)}
                        title="Edit"
                      >
                        <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                          <path d="M10 2L12 4L5 11H3V9L10 2Z" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      </button>
                      <button
                        className="btn-action delete"
                        onClick={() => handleDelete(user.id)}
                        title="Delete"
                        disabled={users.length === 1}
                      >
                        <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                          <path d="M3 4H11M5 4V3C5 2.44772 5.44772 2 6 2H8C8.55228 2 9 2.44772 9 3V4M5.5 6.5V10.5M8.5 6.5V10.5M4 4H10V11C10 11.5523 9.55228 12 9 12H5C4.44772 12 4 11.5523 4 11V4Z" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default UsersPage;
