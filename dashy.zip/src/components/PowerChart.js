import React, { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const PowerChart = ({ title, data, dataKeys, colors, yAxisLabel, maxDataPoints = 20 }) => {
  const [chartData, setChartData] = useState([]);

  useEffect(() => {
    if (data) {
      const timestamp = new Date().toLocaleTimeString();
      const newDataPoint = {
        time: timestamp,
        ...dataKeys.reduce((acc, key) => {
          acc[key] = data[key] || 0;
          return acc;
        }, {}),
      };

      setChartData(prevData => {
        const updatedData = [...prevData, newDataPoint];
        // Keep only the last N data points
        return updatedData.slice(-maxDataPoints);
      });
    }
  }, [data, dataKeys, maxDataPoints]);

  return (
    <div style={{
      border: '1px solid #f3f4f6',
      borderRadius: '12px',
      padding: '20px',
      backgroundColor: '#ffffff',
      boxShadow: '0 1px 3px rgba(0,0,0,0.05)',
    }}>
      <h3 style={{ margin: '0 0 16px 0', fontSize: '15px', fontWeight: '600', color: '#374151' }}>
        {title}
      </h3>
      <ResponsiveContainer width="100%" height={280}>
        <LineChart data={chartData}>
          <defs>
            {dataKeys.map((key, index) => (
              <linearGradient key={key} id={`gradient-${key}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={colors[index]} stopOpacity={0.8}/>
                <stop offset="95%" stopColor={colors[index]} stopOpacity={0}/>
              </linearGradient>
            ))}
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" vertical={false} />
          <XAxis
            dataKey="time"
            stroke="#9ca3af"
            fontSize={11}
            tick={{ fill: '#9ca3af' }}
            tickLine={false}
            axisLine={{ stroke: '#f3f4f6' }}
          />
          <YAxis
            stroke="#9ca3af"
            fontSize={11}
            tick={{ fill: '#9ca3af' }}
            tickLine={false}
            axisLine={{ stroke: '#f3f4f6' }}
            label={{ value: yAxisLabel, angle: -90, position: 'insideLeft', style: { fill: '#9ca3af', fontSize: 11 } }}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: '#ffffff',
              border: '1px solid #f3f4f6',
              borderRadius: '8px',
              fontSize: '12px',
              boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
            }}
          />
          <Legend
            wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }}
            iconType="circle"
          />
          {dataKeys.map((key, index) => (
            <Line
              key={key}
              type="monotone"
              dataKey={key}
              stroke={colors[index] || '#3b82f6'}
              strokeWidth={2.5}
              dot={false}
              activeDot={{ r: 5, strokeWidth: 2 }}
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};

export default PowerChart;
