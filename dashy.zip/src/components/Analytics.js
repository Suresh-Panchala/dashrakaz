import React, { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { useTheme } from '../context/ThemeContext';
import './Analytics.css';

const Analytics = ({ message }) => {
  const { theme } = useTheme();
  const [timeRange, setTimeRange] = useState('20'); // 20, 50, 100 data points
  const [selectedCategory, setSelectedCategory] = useState('all'); // all, voltage, current, power, frequency, energy
  const [chartData, setChartData] = useState({
    voltage: [],
    current: [],
    power: [],
    frequency: [],
    energy: [],
  });

  // Theme-aware colors
  const chartColors = {
    grid: theme === 'dark' ? '#374151' : '#f0f0f0',
    axis: theme === 'dark' ? '#4b5563' : '#e5e7eb',
    text: theme === 'dark' ? '#9ca3af' : '#6b7280',
  };

  const maxDataPoints = {
    '20': 20,
    '50': 50,
    '100': 100,
  };

  useEffect(() => {
    if (!message || !message.data) return;

    const timestamp = new Date().toLocaleTimeString();
    const maxPoints = maxDataPoints[timeRange];

    // Update voltage data
    setChartData(prev => ({
      ...prev,
      voltage: [...prev.voltage, {
        time: timestamp,
        'P1-R': message.data.VRMS_1_R || 0,
        'P1-Y': message.data.VRMS_1_Y || 0,
        'P1-B': message.data.VRMS_1_B || 0,
        'P2-R': message.data.VRMS_2_R || 0,
        'P2-Y': message.data.VRMS_2_Y || 0,
        'P2-B': message.data.VRMS_2_B || 0,
      }].slice(-maxPoints),
      current: [...prev.current, {
        time: timestamp,
        'P1-R': message.data.IRMS_1_R || 0,
        'P1-Y': message.data.IRMS_1_Y || 0,
        'P1-B': message.data.IRMS_1_B || 0,
        'P2-R': message.data.IRMS_2_R || 0,
        'P2-Y': message.data.IRMS_2_Y || 0,
        'P2-B': message.data.IRMS_2_B || 0,
      }].slice(-maxPoints),
      power: [...prev.power, {
        time: timestamp,
        'P1-R': message.data.POWER_1_R || 0,
        'P1-Y': message.data.POWER_1_Y || 0,
        'P1-B': message.data.POWER_1_B || 0,
        'P2-R': message.data.POWER_2_R || 0,
        'P2-Y': message.data.POWER_2_Y || 0,
        'P2-B': message.data.POWER_2_B || 0,
      }].slice(-maxPoints),
      frequency: [...prev.frequency, {
        time: timestamp,
        'P1-R': message.data.FREQ_1_R || 0,
        'P1-Y': message.data.FREQ_1_Y || 0,
        'P1-B': message.data.FREQ_1_B || 0,
        'P2-R': message.data.FREQ_2_R || 0,
        'P2-Y': message.data.FREQ_2_Y || 0,
        'P2-B': message.data.FREQ_2_B || 0,
      }].slice(-maxPoints),
      energy: [...prev.energy, {
        time: timestamp,
        'P1-R': message.data.VAHR_1_R || 0,
        'P1-Y': message.data.VAHR_1_Y || 0,
        'P1-B': message.data.VAHR_1_B || 0,
        'P2-R': message.data.VAHR_2_R || 0,
        'P2-Y': message.data.VAHR_2_Y || 0,
        'P2-B': message.data.VAHR_2_B || 0,
      }].slice(-maxPoints),
    }));
  }, [message, timeRange]);

  const handleExport = (category) => {
    const data = chartData[category];
    if (data.length === 0) return;

    const csv = [
      Object.keys(data[0]).join(','),
      ...data.map(row => Object.values(row).join(','))
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${category}_data_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="analytics-tooltip">
          <p className="tooltip-label">{label}</p>
          {payload.map((entry, index) => (
            <p key={index} style={{ color: entry.color, margin: '4px 0' }}>
              <strong>{entry.name}:</strong> {entry.value.toFixed(2)}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  const renderChart = (category, title, unit, icon, data) => {
    const colors = {
      'P1-R': '#ef4444',
      'P1-Y': '#f59e0b',
      'P1-B': '#3b82f6',
      'P2-R': '#dc2626',
      'P2-Y': '#d97706',
      'P2-B': '#2563eb',
    };

    return (
      <div className="analytics-chart-card" key={category}>
        <div className="analytics-chart-header">
          <div className="chart-title-section">
            <div className={`analytics-icon ${category}`}>
              {icon}
            </div>
            <div>
              <h4>{title}</h4>
              <p className="chart-unit">{unit}</p>
            </div>
          </div>
          <button
            className="export-button"
            onClick={() => handleExport(category)}
            disabled={data.length === 0}
          >
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <path d="M8 2V10M8 10L5 7M8 10L11 7" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M3 12V13C3 13.5523 3.44772 14 4 14H12C12.5523 14 13 13.5523 13 13V12" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
            </svg>
            Export CSV
          </button>
        </div>

        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke={chartColors.grid} />
            <XAxis
              dataKey="time"
              tick={{ fontSize: 11, fill: chartColors.text }}
              tickLine={false}
              axisLine={{ stroke: chartColors.axis }}
            />
            <YAxis
              tick={{ fontSize: 11, fill: chartColors.text }}
              tickLine={false}
              axisLine={{ stroke: chartColors.axis }}
              domain={['auto', 'auto']}
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend
              wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }}
              iconType="line"
            />
            {Object.keys(colors).map(key => (
              <Line
                key={key}
                type="monotone"
                dataKey={key}
                stroke={colors[key]}
                strokeWidth={2}
                name={key}
                dot={false}
                activeDot={{ r: 3 }}
              />
            ))}
          </LineChart>
        </ResponsiveContainer>
      </div>
    );
  };

  if (!message || !message.data) {
    return (
      <div className="analytics-container">
        <div className="analytics-header">
          <h2>Analytics</h2>
          <p className="analytics-subtitle">Detailed parameter analysis and trends</p>
        </div>
        <div className="no-analytics-data">
          <svg width="80" height="80" viewBox="0 0 80 80" fill="none">
            <path d="M10 70V40M30 70V20M50 70V30M70 70V10" stroke="#d1d5db" strokeWidth="3" strokeLinecap="round"/>
          </svg>
          <h3>No Data Available</h3>
          <p>Waiting for device connection to display analytics...</p>
        </div>
      </div>
    );
  }

  const charts = [
    {
      category: 'voltage',
      title: 'Voltage Analysis',
      unit: 'Volts (V)',
      icon: (
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
          <path d="M10 2L3 10H10L9 18L17 10H10L10 2Z" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      ),
    },
    {
      category: 'current',
      title: 'Current Analysis',
      unit: 'Amperes (A)',
      icon: (
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
          <circle cx="10" cy="10" r="7" stroke="white" strokeWidth="1.5"/>
          <path d="M10 6V10L13 13" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
        </svg>
      ),
    },
    {
      category: 'power',
      title: 'Power Analysis',
      unit: 'Watts (W)',
      icon: (
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
          <path d="M3 10H7L10 3L13 17L16 10H17" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      ),
    },
    {
      category: 'frequency',
      title: 'Frequency Analysis',
      unit: 'Hertz (Hz)',
      icon: (
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
          <path d="M2 10H5L8 4L12 16L15 10H18" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      ),
    },
    {
      category: 'energy',
      title: 'Energy Analysis',
      unit: 'Volt-Ampere Hours (VAh)',
      icon: (
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
          <rect x="4" y="3" width="12" height="14" rx="2" stroke="white" strokeWidth="1.5"/>
          <path d="M7 6H13M7 10H13M7 14H10" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
        </svg>
      ),
    },
  ];

  const filteredCharts = selectedCategory === 'all'
    ? charts
    : charts.filter(chart => chart.category === selectedCategory);

  return (
    <div className="analytics-container">
      <div className="analytics-header">
        <div>
          <h2>Analytics</h2>
          <p className="analytics-subtitle">Detailed parameter analysis and trends</p>
        </div>
        <div className="analytics-controls">
          <div className="control-group">
            <label>Time Range:</label>
            <select value={timeRange} onChange={(e) => setTimeRange(e.target.value)}>
              <option value="20">Last 20 points</option>
              <option value="50">Last 50 points</option>
              <option value="100">Last 100 points</option>
            </select>
          </div>
          <div className="control-group">
            <label>Category:</label>
            <select value={selectedCategory} onChange={(e) => setSelectedCategory(e.target.value)}>
              <option value="all">All Parameters</option>
              <option value="voltage">Voltage</option>
              <option value="current">Current</option>
              <option value="power">Power</option>
              <option value="frequency">Frequency</option>
              <option value="energy">Energy</option>
            </select>
          </div>
        </div>
      </div>

      <div className="analytics-charts">
        {filteredCharts.map(chart =>
          renderChart(chart.category, chart.title, chart.unit, chart.icon, chartData[chart.category])
        )}
      </div>
    </div>
  );
};

export default Analytics;
