import React from 'react';

const AlertBadge = ({ alerts }) => {
  const alertConfig = [
    {
      key: 'DryRunAlert',
      label: 'Dry Run',
      activeColor: '#ef4444',
      inactiveColor: '#6b7280',
    },
    {
      key: 'HighLevelFloatAlert',
      label: 'High Level',
      activeColor: '#f59e0b',
      inactiveColor: '#6b7280',
    },
  ];

  return (
    <div style={{
      border: '1px solid #f3f4f6',
      borderRadius: '12px',
      padding: '20px',
      backgroundColor: '#ffffff',
      boxShadow: '0 1px 3px rgba(0,0,0,0.05)',
    }}>
      <h3 style={{ margin: '0 0 16px 0', fontSize: '15px', fontWeight: '600', color: '#374151' }}>
        System Alerts
      </h3>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
        {alertConfig.map(alert => {
          const isActive = alerts[alert.key] === 1;
          return (
            <div
              key={alert.key}
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                padding: '12px 16px',
                backgroundColor: isActive ? `${alert.activeColor}15` : '#f9fafb',
                border: `2px solid ${isActive ? alert.activeColor : '#e5e7eb'}`,
                borderRadius: '8px',
                transition: 'all 0.3s ease',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <div
                  style={{
                    width: '12px',
                    height: '12px',
                    borderRadius: '50%',
                    backgroundColor: isActive ? alert.activeColor : alert.inactiveColor,
                    boxShadow: isActive ? `0 0 12px ${alert.activeColor}80` : 'none',
                    animation: isActive ? 'blink 1.5s infinite' : 'none',
                  }}
                />
                <span style={{
                  fontSize: '15px',
                  fontWeight: isActive ? 'bold' : 'normal',
                  color: isActive ? alert.activeColor : '#4b5563',
                }}>
                  {alert.label}
                </span>
              </div>
              <span style={{
                fontSize: '13px',
                fontWeight: 'bold',
                padding: '4px 12px',
                borderRadius: '12px',
                backgroundColor: isActive ? alert.activeColor : alert.inactiveColor,
                color: '#ffffff',
              }}>
                {isActive ? 'ACTIVE' : 'NORMAL'}
              </span>
            </div>
          );
        })}
      </div>
      <style>{`
        @keyframes blink {
          0%, 100% {
            opacity: 1;
          }
          50% {
            opacity: 0.3;
          }
        }
      `}</style>
    </div>
  );
};

export default AlertBadge;
