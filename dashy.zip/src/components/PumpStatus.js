import React from 'react';
import './PumpStatus.css';

const PumpStatus = ({ pumpNumber, manual, auto, rhs }) => {
  const mode = manual === 1 ? 'Manual' : auto === 1 ? 'Auto' : 'Off';
  const state = (manual === 1 || auto === 1) ? 'ON' : 'OFF';
  const isRunning = state === 'ON';
  const modeClass = mode === 'Manual' ? 'manual' : mode === 'Auto' ? 'auto' : 'off';

  return (
    <div className={`pump-status-card ${isRunning ? 'running' : 'stopped'}`}>
      {/* Background Decorative Elements */}
      <div className="pump-card-bg-decoration"></div>
      
      {/* Status Indicator Pulse */}
      {isRunning && <div className="pump-pulse-indicator"></div>}
      
      <div className="pump-status-header">
        <div className="pump-title-section">
          <div className={`pump-icon ${isRunning ? 'active' : ''}`}>
            <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
              <circle cx="16" cy="16" r="14" stroke="currentColor" strokeWidth="2" fill="none"/>
              <path d="M16 8V16L20 20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <circle cx="16" cy="16" r="2" fill="currentColor"/>
            </svg>
          </div>
          <div className="pump-title-text">
            <h3 className="pump-status-title">Pump {pumpNumber}</h3>
            <span className="pump-subtitle">Motor Control Unit</span>
          </div>
        </div>
        <div className={`pump-status-indicator ${isRunning ? 'active' : 'inactive'}`}>
          <div className="status-dot"></div>
          <span className="status-text">{state}</span>
        </div>
      </div>

      <div className="pump-stats-grid">
        <div className="pump-stat-item mode">
          <div className="stat-icon">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
              <path d="M10 2C10 2 7 5 7 8C7 9.65685 8.34315 11 10 11C11.6569 11 13 9.65685 13 8C13 5 10 2 10 2Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M4 14H16M4 18H16" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
            </svg>
          </div>
          <div className="stat-info">
            <span className="stat-label">Operation Mode</span>
            <span className={`stat-value mode-${modeClass}`}>
              {mode}
            </span>
          </div>
        </div>

        {rhs !== undefined && (
          <div className="pump-stat-item hours">
            <div className="stat-icon">
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                <circle cx="10" cy="10" r="8" stroke="currentColor" strokeWidth="1.5"/>
                <path d="M10 6V10L13 13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
              </svg>
            </div>
            <div className="stat-info">
              <span className="stat-label">Running Hours</span>
              <span className="stat-value hours-value">
                {rhs.toLocaleString()} <span className="unit">hrs</span>
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Performance Indicator Bar */}
      <div className="pump-performance-bar">
        <div className="performance-label">Status</div>
        <div className="performance-bar-track">
          <div className={`performance-bar-fill ${isRunning ? 'running' : 'stopped'}`}></div>
        </div>
        <div className="performance-status">{isRunning ? 'Operational' : 'Standby'}</div>
      </div>
    </div>
  );
};

export default PumpStatus;
