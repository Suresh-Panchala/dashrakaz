import { useState, useEffect, useCallback } from 'react';
import mqtt from 'mqtt';

export const useMQTT = (brokerUrl, topic, options = {}) => {
  const [client, setClient] = useState(null);
  const [isConnected, setIsConnected] = useState(false);
  const [message, setMessage] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Create MQTT client connection
    const mqttClient = mqtt.connect(brokerUrl, {
      ...options,
      reconnectPeriod: 1000,
      connectTimeout: 30 * 1000,
    });

    mqttClient.on('connect', () => {
      console.log('Connected to MQTT broker');
      setIsConnected(true);
      setError(null);

      // Subscribe to topic
      mqttClient.subscribe(topic, (err) => {
        if (err) {
          console.error('Subscription error:', err);
          setError(err.message);
        } else {
          console.log(`Subscribed to ${topic}`);
        }
      });
    });

    mqttClient.on('error', (err) => {
      console.error('MQTT error:', err);
      setError(err.message);
      setIsConnected(false);
    });

    mqttClient.on('reconnect', () => {
      console.log('Reconnecting to MQTT broker...');
    });

    mqttClient.on('close', () => {
      console.log('Disconnected from MQTT broker');
      setIsConnected(false);
    });

    mqttClient.on('message', (receivedTopic, payload) => {
      if (receivedTopic === topic) {
        try {
          const parsedMessage = JSON.parse(payload.toString());
          setMessage(parsedMessage);
          // If we're receiving messages, we're definitely connected
          setIsConnected(true);
        } catch (err) {
          console.error('Error parsing message:', err);
          setError('Failed to parse message');
        }
      }
    });

    setClient(mqttClient);

    // Cleanup on unmount
    return () => {
      if (mqttClient) {
        mqttClient.end();
      }
    };
  }, [brokerUrl, topic]);

  const publish = useCallback((publishTopic, publishMessage) => {
    if (client && isConnected) {
      client.publish(publishTopic, JSON.stringify(publishMessage));
    }
  }, [client, isConnected]);

  return {
    isConnected,
    message,
    error,
    publish,
  };
};
