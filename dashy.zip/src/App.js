import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { DeviceProvider, useDevices } from './context/DeviceContext';
import { UserProvider } from './context/UserContext';
import { ThemeProvider } from './context/ThemeContext';
import { useMQTT } from './hooks/useMQTT';
import Login from './components/Login';
import Sidebar from './components/Sidebar';
import TopBar from './components/TopBar';
import ParameterCard from './components/ParameterCard';
import PumpStatus from './components/PumpStatus';
import Alerts from './components/Alerts';
import AverageCharts from './components/AverageCharts';
import Analytics from './components/Analytics';
import HistoricalData from './components/HistoricalData';
import DevicesPage from './components/DevicesPage';
import UsersPage from './components/UsersPage';
import SettingsPage from './components/SettingsPage';
import './App.css';

function Dashboard() {
  const [currentView, setCurrentView] = useState('dashboard');
  const { selectedDevice } = useDevices();
  const { isConnected, message, error } = useMQTT(
    selectedDevice?.brokerUrl || '',
    selectedDevice?.topic || ''
  );

  if (!selectedDevice) {
    return (
      <div className="app-layout">
        <Sidebar currentView={currentView} onViewChange={setCurrentView} />
        <div className="main-wrapper">
          <TopBar isConnected={false} currentView={currentView} />
          <main className="main-container">
            <div className="no-data-state">
              <svg width="80" height="80" viewBox="0 0 80 80" fill="none">
                <circle cx="40" cy="40" r="38" stroke="#e5e7eb" strokeWidth="2"/>
                <path d="M40 20V44M40 56H40.02" stroke="#9ca3af" strokeWidth="3" strokeLinecap="round"/>
              </svg>
              <h2>No Device Selected</h2>
              <p>Please add a device to get started with monitoring.</p>
            </div>
          </main>
        </div>
      </div>
    );
  }

  return (
    <div className="app-layout">
      <Sidebar currentView={currentView} onViewChange={setCurrentView} />
      <div className="main-wrapper">
        <TopBar isConnected={isConnected} currentView={currentView} />

        <main className="main-container">
          {error && (
            <div className="error-alert">
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                <circle cx="10" cy="10" r="9" stroke="currentColor" strokeWidth="1.5"/>
                <path d="M10 6V10M10 14H10.01" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
              </svg>
              <strong>Connection Error:</strong> {error}
            </div>
          )}

          {currentView === 'dashboard' && (
            <>
              {message ? (
                <>
                  {/* Pump Status Cards - Top Row */}
                  <div className="pump-grid">
                    <PumpStatus
                      pumpNumber={1}
                      manual={message.data?.Pump_1_Manual}
                      auto={message.data?.Pump_1_Auto}
                      protection={message.data?.Pump_1_Protection}
                      contactorFeedback={message.data?.Pump_1_Contactor_Feedback}
                      rhs={message.data?.RHS_1}
                    />
                    <PumpStatus
                      pumpNumber={2}
                      manual={message.data?.Pump_2_Manual}
                      auto={message.data?.Pump_2_Auto}
                      protection={message.data?.Pump_2_Protection}
                      contactorFeedback={message.data?.Pump_2_Contactor_Feedback}
                      rhs={message.data?.RHS_2}
                    />
                  </div>

                  {/* All Parameters - Unified Grid (30 cards) */}
                  <div className="parameter-grid">
                    {/* Voltage Cards - Pump 1 (3) */}
                    <ParameterCard
                      title="Voltage"
                      value={message.data?.VRMS_1_R || 0}
                      unit="V"
                      phase="R"
                      pump={1}
                      color="red"
                      icon={
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                          <path d="M10 2L3 10H10L9 18L17 10H10L10 2Z" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      }
                    />
                    <ParameterCard
                      title="Voltage"
                      value={message.data?.VRMS_1_Y || 0}
                      unit="V"
                      phase="Y"
                      pump={1}
                      color="orange"
                      icon={
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                          <path d="M10 2L3 10H10L9 18L17 10H10L10 2Z" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      }
                    />
                    <ParameterCard
                      title="Voltage"
                      value={message.data?.VRMS_1_B || 0}
                      unit="V"
                      phase="B"
                      pump={1}
                      color="blue"
                      icon={
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                          <path d="M10 2L3 10H10L9 18L17 10H10L10 2Z" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      }
                    />

                    {/* Voltage Cards - Pump 2 (3) */}
                    <ParameterCard
                      title="Voltage"
                      value={message.data?.VRMS_2_R || 0}
                      unit="V"
                      phase="R"
                      pump={2}
                      color="red"
                      icon={
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                          <path d="M10 2L3 10H10L9 18L17 10H10L10 2Z" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      }
                    />
                    <ParameterCard
                      title="Voltage"
                      value={message.data?.VRMS_2_Y || 0}
                      unit="V"
                      phase="Y"
                      pump={2}
                      color="orange"
                      icon={
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                          <path d="M10 2L3 10H10L9 18L17 10H10L10 2Z" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      }
                    />
                    <ParameterCard
                      title="Voltage"
                      value={message.data?.VRMS_2_B || 0}
                      unit="V"
                      phase="B"
                      pump={2}
                      color="blue"
                      icon={
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                          <path d="M10 2L3 10H10L9 18L17 10H10L10 2Z" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      }
                    />

                    {/* Current Cards - Pump 1 (3) */}
                    <ParameterCard
                      title="Current"
                      value={message.data?.IRMS_1_R || 0}
                      unit="A"
                      phase="R"
                      pump={1}
                      color="red"
                      icon={
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                          <circle cx="10" cy="10" r="7" stroke="white" strokeWidth="1.5"/>
                          <path d="M10 6V10L13 13" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                        </svg>
                      }
                    />
                    <ParameterCard
                      title="Current"
                      value={message.data?.IRMS_1_Y || 0}
                      unit="A"
                      phase="Y"
                      pump={1}
                      color="orange"
                      icon={
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                          <circle cx="10" cy="10" r="7" stroke="white" strokeWidth="1.5"/>
                          <path d="M10 6V10L13 13" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                        </svg>
                      }
                    />
                    <ParameterCard
                      title="Current"
                      value={message.data?.IRMS_1_B || 0}
                      unit="A"
                      phase="B"
                      pump={1}
                      color="blue"
                      icon={
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                          <circle cx="10" cy="10" r="7" stroke="white" strokeWidth="1.5"/>
                          <path d="M10 6V10L13 13" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                        </svg>
                      }
                    />

                    {/* Current Cards - Pump 2 (3) */}
                    <ParameterCard
                      title="Current"
                      value={message.data?.IRMS_2_R || 0}
                      unit="A"
                      phase="R"
                      pump={2}
                      color="red"
                      icon={
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                          <circle cx="10" cy="10" r="7" stroke="white" strokeWidth="1.5"/>
                          <path d="M10 6V10L13 13" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                        </svg>
                      }
                    />
                    <ParameterCard
                      title="Current"
                      value={message.data?.IRMS_2_Y || 0}
                      unit="A"
                      phase="Y"
                      pump={2}
                      color="orange"
                      icon={
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                          <circle cx="10" cy="10" r="7" stroke="white" strokeWidth="1.5"/>
                          <path d="M10 6V10L13 13" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                        </svg>
                      }
                    />
                    <ParameterCard
                      title="Current"
                      value={message.data?.IRMS_2_B || 0}
                      unit="A"
                      phase="B"
                      pump={2}
                      color="blue"
                      icon={
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                          <circle cx="10" cy="10" r="7" stroke="white" strokeWidth="1.5"/>
                          <path d="M10 6V10L13 13" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                        </svg>
                      }
                    />

                    {/* Power Cards - Pump 1 (3) */}
                    <ParameterCard
                      title="Power"
                      value={message.data?.POWER_1_R || 0}
                      unit="W"
                      phase="R"
                      pump={1}
                      color="red"
                      icon={
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                          <path d="M3 10H7L10 3L13 17L16 10H17" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      }
                    />
                    <ParameterCard
                      title="Power"
                      value={message.data?.POWER_1_Y || 0}
                      unit="W"
                      phase="Y"
                      pump={1}
                      color="orange"
                      icon={
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                          <path d="M3 10H7L10 3L13 17L16 10H17" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      }
                    />
                    <ParameterCard
                      title="Power"
                      value={message.data?.POWER_1_B || 0}
                      unit="W"
                      phase="B"
                      pump={1}
                      color="blue"
                      icon={
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                          <path d="M3 10H7L10 3L13 17L16 10H17" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      }
                    />

                    {/* Power Cards - Pump 2 (3) */}
                    <ParameterCard
                      title="Power"
                      value={message.data?.POWER_2_R || 0}
                      unit="W"
                      phase="R"
                      pump={2}
                      color="red"
                      icon={
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                          <path d="M3 10H7L10 3L13 17L16 10H17" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      }
                    />
                    <ParameterCard
                      title="Power"
                      value={message.data?.POWER_2_Y || 0}
                      unit="W"
                      phase="Y"
                      pump={2}
                      color="orange"
                      icon={
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                          <path d="M3 10H7L10 3L13 17L16 10H17" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      }
                    />
                    <ParameterCard
                      title="Power"
                      value={message.data?.POWER_2_B || 0}
                      unit="W"
                      phase="B"
                      pump={2}
                      color="blue"
                      icon={
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                          <path d="M3 10H7L10 3L13 17L16 10H17" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      }
                    />

                    {/* Frequency Cards - Pump 1 (3) */}
                    <ParameterCard
                      title="Frequency"
                      value={message.data?.FREQ_1_R || 0}
                      unit="Hz"
                      phase="R"
                      pump={1}
                      color="purple"
                      icon={
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                          <path d="M2 10H5L8 4L12 16L15 10H18" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      }
                    />
                    <ParameterCard
                      title="Frequency"
                      value={message.data?.FREQ_1_Y || 0}
                      unit="Hz"
                      phase="Y"
                      pump={1}
                      color="purple"
                      icon={
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                          <path d="M2 10H5L8 4L12 16L15 10H18" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      }
                    />
                    <ParameterCard
                      title="Frequency"
                      value={message.data?.FREQ_1_B || 0}
                      unit="Hz"
                      phase="B"
                      pump={1}
                      color="purple"
                      icon={
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                          <path d="M2 10H5L8 4L12 16L15 10H18" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      }
                    />

                    {/* Frequency Cards - Pump 2 (3) */}
                    <ParameterCard
                      title="Frequency"
                      value={message.data?.FREQ_2_R || 0}
                      unit="Hz"
                      phase="R"
                      pump={2}
                      color="purple"
                      icon={
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                          <path d="M2 10H5L8 4L12 16L15 10H18" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      }
                    />
                    <ParameterCard
                      title="Frequency"
                      value={message.data?.FREQ_2_Y || 0}
                      unit="Hz"
                      phase="Y"
                      pump={2}
                      color="purple"
                      icon={
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                          <path d="M2 10H5L8 4L12 16L15 10H18" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      }
                    />
                    <ParameterCard
                      title="Frequency"
                      value={message.data?.FREQ_2_B || 0}
                      unit="Hz"
                      phase="B"
                      pump={2}
                      color="purple"
                      icon={
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                          <path d="M2 10H5L8 4L12 16L15 10H18" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      }
                    />

                    {/* Energy (VAHR) Cards - Pump 1 (3) */}
                    <ParameterCard
                      title="Energy"
                      value={message.data?.VAHR_1_R || 0}
                      unit="VAh"
                      phase="R"
                      pump={1}
                      color="yellow"
                      icon={
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                          <rect x="4" y="3" width="12" height="14" rx="2" stroke="white" strokeWidth="1.5"/>
                          <path d="M7 6H13M7 10H13M7 14H10" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                        </svg>
                      }
                    />
                    <ParameterCard
                      title="Energy"
                      value={message.data?.VAHR_1_Y || 0}
                      unit="VAh"
                      phase="Y"
                      pump={1}
                      color="yellow"
                      icon={
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                          <rect x="4" y="3" width="12" height="14" rx="2" stroke="white" strokeWidth="1.5"/>
                          <path d="M7 6H13M7 10H13M7 14H10" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                        </svg>
                      }
                    />
                    <ParameterCard
                      title="Energy"
                      value={message.data?.VAHR_1_B || 0}
                      unit="VAh"
                      phase="B"
                      pump={1}
                      color="yellow"
                      icon={
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                          <rect x="4" y="3" width="12" height="14" rx="2" stroke="white" strokeWidth="1.5"/>
                          <path d="M7 6H13M7 10H13M7 14H10" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                        </svg>
                      }
                    />

                    {/* Energy (VAHR) Cards - Pump 2 (3) */}
                    <ParameterCard
                      title="Energy"
                      value={message.data?.VAHR_2_R || 0}
                      unit="VAh"
                      phase="R"
                      pump={2}
                      color="yellow"
                      icon={
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                          <rect x="4" y="3" width="12" height="14" rx="2" stroke="white" strokeWidth="1.5"/>
                          <path d="M7 6H13M7 10H13M7 14H10" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                        </svg>
                      }
                    />
                    <ParameterCard
                      title="Energy"
                      value={message.data?.VAHR_2_Y || 0}
                      unit="VAh"
                      phase="Y"
                      pump={2}
                      color="yellow"
                      icon={
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                          <rect x="4" y="3" width="12" height="14" rx="2" stroke="white" strokeWidth="1.5"/>
                          <path d="M7 6H13M7 10H13M7 14H10" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                        </svg>
                      }
                    />
                    <ParameterCard
                      title="Energy"
                      value={message.data?.VAHR_2_B || 0}
                      unit="VAh"
                      phase="B"
                      pump={2}
                      color="yellow"
                      icon={
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                          <rect x="4" y="3" width="12" height="14" rx="2" stroke="white" strokeWidth="1.5"/>
                          <path d="M7 6H13M7 10H13M7 14H10" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                        </svg>
                      }
                    />
                  </div>

                  {/* Average Charts Section */}
                  <AverageCharts message={message} />
                </>
              ) : (
                <div className="no-data-state">
                  <div className="spinner-large"></div>
                  <h2>Connecting to Device</h2>
                </div>
              )}
            </>
          )}

          {currentView === 'reports' && (
            <div className="view-placeholder">
              <svg width="64" height="64" viewBox="0 0 64 64" fill="none">
                <rect x="12" y="8" width="40" height="48" rx="4" stroke="#d1d5db" strokeWidth="2"/>
                <path d="M20 20H44M20 28H44M20 36H36" stroke="#d1d5db" strokeWidth="2" strokeLinecap="round"/>
              </svg>
              <h2>Reports View</h2>
              <p>Historical data and reports will be displayed here.</p>
            </div>
          )}

          {currentView === 'analytics' && (
            <Analytics message={message} />
          )}

          {currentView === 'historical' && (
            <HistoricalData />
          )}

          {currentView === 'devices' && (
            <DevicesPage />
          )}

          {currentView === 'alerts' && (
            <Alerts message={message} />
          )}

          {currentView === 'users' && (
            <UsersPage />
          )}

          {currentView === 'settings' && (
            <SettingsPage />
          )}
        </main>
      </div>
    </div>
  );
}

function AppContent() {
  const { isAuthenticated, login } = useAuth();

  if (!isAuthenticated) {
    return <Login onLogin={login} />;
  }

  return <Dashboard />;
}

function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <DeviceProvider>
          <UserProvider>
            <AppContent />
          </UserProvider>
        </DeviceProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;
