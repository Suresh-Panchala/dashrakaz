# 🚀 Quick Start Guide - StormWater Monitoring System

## 📋 What You Have Now

Your StormWater Monitoring Dashboard now has a **complete backend system** with:

✅ **Backend Server** (Node.js + Express)
✅ **MQTT Integration** (Subscribes to Mosquitto and stores data)
✅ **MongoDB Integration** (Historical data storage)
✅ **REST API** (Data retrieval, filtering, and export)
✅ **CSV Export** (Download data as spreadsheet)
✅ **PDF Reports** (Generate professional reports)
✅ **Historical Data View** (Frontend component with charts)
✅ **Complete Deployment Guide** (Ubuntu VPS deployment)

## 🎯 Local Development (Testing on Your Computer)

### 1. Start MongoDB
```bash
# Windows (if using MongoDB on Windows)
mongod

# Ubuntu/Mac
sudo systemctl start mongod
```

### 2. Start Mosquitto
```bash
# Windows
# Start Mosquitto service from Services

# Ubuntu/Mac
sudo systemctl start mosquitto
```

### 3. Start Backend
```bash
cd backend

# Install dependencies
npm install

# Copy environment file
cp config.example.env .env

# Edit .env with your settings
# Then start server
npm run dev
```

Backend will run at: `http://localhost:5000`

### 4. Start Frontend
```bash
# In project root directory
npm install

# Create .env file
echo "REACT_APP_API_URL=http://localhost:5000/api" > .env

# Start frontend
npm start
```

Frontend will open at: `http://localhost:3000`

## 🌐 Production Deployment (Ubuntu VPS)

### Quick Deploy Command

```bash
# On your Ubuntu VPS

# 1. Upload your project to VPS
cd /var/www/stormwater

# 2. Run backend setup script
cd backend
chmod +x setup.sh
./setup.sh

# 3. Configure environment
nano .env
# Update with your VPS settings

# 4. Start backend with PM2
pm2 start server.js --name stormwater-backend
pm2 save
pm2 startup

# 5. Build and start frontend
cd ..
npm install
npm run build
pm2 serve build 3000 --name stormwater-frontend --spa
pm2 save
```

**For detailed deployment**, see: [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md)

## 📊 Accessing the Features

### 1. Dashboard View
- Real-time parameter monitoring
- Live pump status with animations
- Trend charts
- **New**: Professional animated pump cards!

### 2. Historical Data View (NEW!)
- Click "Historical" in the sidebar
- Select date range
- Choose aggregation interval (hourly/daily/monthly)
- View historical trends
- Export as CSV or PDF

### 3. Analytics View
- Detailed real-time charts
- Multiple parameter tracking
- Configurable data points

### 4. Export Data
From Historical Data view:
- Click "Export CSV" for spreadsheet
- Click "Export PDF" for reports
- Data downloads automatically

## 🔧 Configuration Files

### Backend Environment (backend/.env)
```env
PORT=5000
NODE_ENV=production
MONGODB_URI=mongodb://localhost:27017/stormwater
MQTT_BROKER_URL=mqtt://localhost:1883
MQTT_TOPIC=stromwater/khusam/device1/data
FRONTEND_URL=http://localhost:3000
```

### Frontend Environment (.env)
```env
REACT_APP_API_URL=http://localhost:5000/api
```

For VPS production:
```env
REACT_APP_API_URL=https://api.your-domain.com/api
```

## 📡 How It Works

1. **IoT Device** → Publishes MQTT messages to Mosquitto broker
2. **Backend MQTT Service** → Subscribes to topic and receives messages
3. **Backend** → Saves data to MongoDB automatically
4. **Frontend** → 
   - Connects directly to MQTT for real-time data (dashboard)
   - Calls backend API for historical data (historical view)
5. **User** → Can view, analyze, and export data

## 🎨 New Features Added

### Professional Pump Cards
- 🔄 Rotating icons when pump is running
- 💫 Pulsing status indicators
- 🌊 Animated performance bars
- ✨ Smooth hover effects
- 📊 Visual mode indicators

### Historical Data Analysis
- 📅 Date range selection
- 📈 Interactive trend charts
- 📊 Statistical summaries
- 📥 CSV/PDF export

### Theme Support
- 🌙 Dark mode fully functional
- ☀️ Light mode
- 🎨 All charts adapt to theme
- 🔄 Smooth theme transitions

### Fully Responsive
- 💻 Desktop optimized
- 📱 Tablet optimized
- 📞 Mobile optimized
- ✨ Touch-friendly UI

## 🗂️ File Structure

```
Your Project/
├── src/                          # Frontend source
│   ├── components/
│   │   ├── HistoricalData.js    # NEW: Historical data view
│   │   ├── PumpStatus.js        # UPDATED: Professional design
│   │   └── ...
│   ├── services/
│   │   └── api.js               # NEW: Backend API service
│   └── ...
├── backend/                      # NEW: Complete backend
│   ├── config/
│   │   └── database.js
│   ├── controllers/
│   │   └── dataController.js
│   ├── models/
│   │   ├── SensorData.js
│   │   └── Device.js
│   ├── routes/
│   │   └── dataRoutes.js
│   ├── services/
│   │   └── mqttService.js
│   ├── utils/
│   │   ├── csvExporter.js
│   │   └── pdfExporter.js
│   ├── server.js
│   ├── package.json
│   ├── setup.sh                 # Setup script
│   └── README.md
├── DEPLOYMENT_GUIDE.md           # NEW: Deployment guide
├── QUICK_START.md                # This file
└── README.md                     # Updated main README
```

## 📞 API Endpoints

All endpoints are prefixed with `/api`

### Data Endpoints
- `GET /api/data/latest/:deviceId` - Get latest data
- `GET /api/data/history/:deviceId` - Get paginated history
- `GET /api/data/stats/:deviceId` - Get statistics
- `GET /api/data/range/:deviceId` - Get date range data
- `GET /api/data/export/csv/:deviceId` - Export CSV
- `GET /api/data/export/pdf/:deviceId` - Export PDF
- `GET /api/data/devices` - List devices
- `GET /api/health` - Health check

### Example API Calls

**Get latest data:**
```bash
curl http://localhost:5000/api/data/latest/device1?limit=10
```

**Get historical data:**
```bash
curl "http://localhost:5000/api/data/history/device1?page=1&limit=100"
```

**Get statistics:**
```bash
curl "http://localhost:5000/api/data/stats/device1?hours=24"
```

**Health check:**
```bash
curl http://localhost:5000/api/health
```

## 🔍 Testing the System

### 1. Test MQTT Data Flow
```bash
# Subscribe to see data
mosquitto_sub -h localhost -t "stromwater/khusam/device1/data" -v

# Publish test data
mosquitto_pub -h localhost -t "stromwater/khusam/device1/data" -m '{"VR":230,"VY":231,"VB":229,"CR":12,"CY":13,"CB":12,"KW":8.5,"KVA":9.2,"KVAR":3.1,"PF":0.92,"F":50,"P1M":0,"P1A":1,"P1RHS":1250}'
```

### 2. Check MongoDB Data
```bash
mongosh stormwater
> db.sensorData.find().limit(5).pretty()
```

### 3. Test Backend API
```bash
curl http://localhost:5000/api/health
```

### 4. Check Frontend
Open browser: `http://localhost:3000`
- Go to "Historical" tab
- Select date range
- Click "Fetch Data"
- Try export buttons

## 📚 Documentation

- **[README.md](README.md)** - Main project documentation
- **[DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md)** - Complete VPS deployment
- **[backend/README.md](backend/README.md)** - Backend documentation

## 🎯 Next Steps

1. ✅ Test locally on your development machine
2. ✅ Verify all features work
3. ✅ Upload to your Ubuntu VPS
4. ✅ Follow DEPLOYMENT_GUIDE.md for production setup
5. ✅ Configure your domain and SSL
6. ✅ Set up monitoring and backups

## 🐛 Troubleshooting

### Backend not connecting to MongoDB
```bash
sudo systemctl status mongodb
sudo systemctl start mongodb
```

### Backend not receiving MQTT data
```bash
sudo systemctl status mosquitto
# Check topic name in backend/.env matches your device
```

### Frontend not fetching historical data
```bash
# Check backend is running
curl http://localhost:5000/api/health

# Check .env has correct API URL
cat .env
```

### No data in MongoDB
```bash
# Check backend logs
pm2 logs stormwater-backend

# Verify MQTT messages are coming
mosquitto_sub -h localhost -t "your/topic" -v
```

## ✅ Checklist for VPS Deployment

- [ ] MongoDB installed and running
- [ ] Mosquitto installed and running
- [ ] Node.js 16+ installed
- [ ] Backend deployed and running
- [ ] Frontend built and deployed
- [ ] Nginx configured (optional)
- [ ] SSL certificate installed (optional)
- [ ] Firewall configured
- [ ] PM2 processes running
- [ ] Environment files configured
- [ ] Database backups configured

## 🎉 You're All Set!

Your complete StormWater Monitoring System is ready for deployment! 🚀

**Key Features:**
- ✅ Real-time MQTT monitoring
- ✅ Historical data storage in MongoDB
- ✅ Beautiful, responsive UI
- ✅ Professional pump status cards
- ✅ CSV and PDF exports
- ✅ Date range analysis
- ✅ Dark/Light themes
- ✅ Production-ready backend

**Happy Monitoring! 🌊📊**

