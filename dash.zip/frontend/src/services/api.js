import axios from 'axios';
import useAuthStore from '../store/authStore';
import toast from 'react-hot-toast';

const API_BASE_URL = import.meta.env.VITE_API_URL || '/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor
api.interceptors.request.use(
  (config) => {
    const token = useAuthStore.getState().token;
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      useAuthStore.getState().logout();
      toast.error('Session expired. Please login again.');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Auth API
export const authAPI = {
  login: (credentials) => api.post('/auth/login', credentials),
  register: (userData) => api.post('/auth/register', userData),
  getMe: () => api.get('/auth/me'),
  changePassword: (passwords) => api.put('/auth/password', passwords),
};

// Devices API
export const devicesAPI = {
  getAll: () => api.get('/devices'),
  getById: (deviceId) => api.get(`/devices/${deviceId}`),
  getLatest: (deviceId) => api.get(`/devices/${deviceId}/latest`),
  getStats: (deviceId, period) => api.get(`/devices/${deviceId}/stats`, { params: { period } }),
  create: (deviceData) => api.post('/devices', deviceData),
  delete: (deviceId) => api.delete(`/devices/${deviceId}`),
};

// Data API
export const dataAPI = {
  getData: (deviceId, params) => api.get(`/data/${deviceId}`, { params }),
  getChartData: (deviceId, params) => api.get(`/data/${deviceId}/chart`, { params }),
  exportCSV: (deviceId, params) => 
    api.get(`/data/${deviceId}/export/csv`, { 
      params, 
      responseType: 'blob' 
    }),
  exportPDF: (deviceId, params) => 
    api.get(`/data/${deviceId}/export/pdf`, { 
      params, 
      responseType: 'blob' 
    }),
};

// Users API
export const usersAPI = {
  getAll: () => api.get('/users'),
  getById: (id) => api.get(`/users/${id}`),
  update: (id, userData) => api.put(`/users/${id}`, userData),
  delete: (id) => api.delete(`/users/${id}`),
};

// Alerts API
export const alertsAPI = {
  getAll: (params) => api.get('/alerts', { params }),
  getById: (id) => api.get(`/alerts/${id}`),
  acknowledge: (id) => api.put(`/alerts/${id}/acknowledge`),
  getStats: (params) => api.get('/alerts/stats/summary', { params }),
};

export default api;

