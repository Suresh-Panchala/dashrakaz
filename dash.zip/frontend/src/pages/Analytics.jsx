import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import {
  TrendingUp,
  Zap,
  Activity,
  Battery,
  Clock,
  Calendar,
  Download,
} from 'lucide-react';
import { dataAPI } from '../services/api';
import toast from 'react-hot-toast';

const Analytics = () => {
  const [dateRange, setDateRange] = useState('24h');
  const [chartData, setChartData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedDevice, setSelectedDevice] = useState('PUMP_001');
  const [exporting, setExporting] = useState(false);

  useEffect(() => {
    fetchAnalyticsData();
  }, [dateRange, selectedDevice]);

  const handleExport = async () => {
    setExporting(true);
    try {
      const hours = dateRange === '24h' ? 24 : dateRange === '7d' ? 168 : dateRange === '30d' ? 720 : 1;
      const endDate = new Date();
      const startDate = new Date(endDate.getTime() - hours * 60 * 60 * 1000);

      const response = await dataAPI.exportCSV(selectedDevice, {
        startDate: startDate.toISOString(),
        endDate: endDate.toISOString(),
      });

      // Check if response is valid
      if (!response.data || response.data.size === 0) {
        toast.error('No data available to export for the selected time range');
        return;
      }

      // Create download link
      const url = window.URL.createObjectURL(new Blob([response.data], { type: 'text/csv' }));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `analytics_${selectedDevice}_${dateRange}_${Date.now()}.csv`);
      document.body.appendChild(link);
      link.click();
      
      // Cleanup
      setTimeout(() => {
        link.remove();
        window.URL.revokeObjectURL(url);
      }, 100);

      toast.success('Analytics report exported successfully!');
    } catch (error) {
      console.error('Error exporting analytics:', error);
      const errorMessage = error.response?.data?.message || error.message || 'Failed to export analytics report';
      toast.error(errorMessage);
    } finally {
      setExporting(false);
    }
  };

  const fetchAnalyticsData = async () => {
    setLoading(true);
    try {
      const hours = dateRange === '24h' ? 24 : dateRange === '7d' ? 168 : dateRange === '30d' ? 720 : 1;
      const endDate = new Date();
      const startDate = new Date(endDate.getTime() - hours * 60 * 60 * 1000);

      const response = await dataAPI.getData(selectedDevice, {
        startDate: startDate.toISOString(),
        endDate: endDate.toISOString(),
        limit: 100,
        sortOrder: 'asc',
      });

      if (response.data.success && response.data.data) {
        // Transform data for charts
        const transformed = response.data.data.map((item) => ({
          time: new Date(item.timestamp).toLocaleTimeString('en-US', {
            hour: '2-digit',
            minute: '2-digit',
          }),
          timestamp: item.timestamp,
          // Pump 1
          voltage1R: item.data?.VRMS_1_R || 0,
          voltage1Y: item.data?.VRMS_1_Y || 0,
          voltage1B: item.data?.VRMS_1_B || 0,
          current1R: item.data?.IRMS_1_R || 0,
          current1Y: item.data?.IRMS_1_Y || 0,
          current1B: item.data?.IRMS_1_B || 0,
          power1R: item.data?.POWER_1_R || 0,
          power1Y: item.data?.POWER_1_Y || 0,
          power1B: item.data?.POWER_1_B || 0,
          // Pump 2
          voltage2R: item.data?.VRMS_2_R || 0,
          voltage2Y: item.data?.VRMS_2_Y || 0,
          voltage2B: item.data?.VRMS_2_B || 0,
          current2R: item.data?.IRMS_2_R || 0,
          current2Y: item.data?.IRMS_2_Y || 0,
          current2B: item.data?.IRMS_2_B || 0,
          power2R: item.data?.POWER_2_R || 0,
          power2Y: item.data?.POWER_2_Y || 0,
          power2B: item.data?.POWER_2_B || 0,
          // Other
          waterLevel: item.data?.Hydrostatic_Value || 0,
          rhs1: item.data?.RHS_1 || 0,
          rhs2: item.data?.RHS_2 || 0,
        }));
        setChartData(transformed);
      }
    } catch (error) {
      console.error('Error fetching analytics data:', error);
      toast.error('Failed to fetch analytics data');
    } finally {
      setLoading(false);
    }
  };

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700">
          <p className="text-sm font-bold text-gray-900 dark:text-white mb-2">{label}</p>
          {payload.map((entry, index) => (
            <p key={index} className="text-xs" style={{ color: entry.color }}>
              {entry.name}: <span className="font-bold">{entry.value.toFixed(2)}</span>
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="card p-6 bg-gradient-to-r from-primary-500/10 via-indigo-500/10 to-purple-500/10 border-l-4 border-primary-500"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-primary-500 to-indigo-600 shadow-lg">
              <TrendingUp className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-black text-gray-900 dark:text-white">
                Analytics & Trends
              </h1>
              <p className="text-sm text-gray-600 dark:text-gray-400 font-medium">
                Historical data visualization and insights
              </p>
            </div>
          </div>
          <button 
            onClick={handleExport}
            disabled={exporting || loading}
            className="btn-primary flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {exporting ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                Exporting...
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                Export CSV
              </>
            )}
          </button>
        </div>
      </motion.div>

      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Date Range */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="card p-4"
        >
          <label className="flex items-center gap-2 text-sm font-bold text-gray-700 dark:text-gray-300 mb-3">
            <Calendar className="w-4 h-4" />
            Time Range
          </label>
          <div className="grid grid-cols-4 gap-2">
            {['1h', '24h', '7d', '30d'].map((range) => (
              <button
                key={range}
                onClick={() => setDateRange(range)}
                className={`px-4 py-2 rounded-lg font-bold text-sm transition-all ${
                  dateRange === range
                    ? 'bg-gradient-to-r from-primary-500 to-indigo-600 text-white shadow-lg'
                    : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700'
                }`}
              >
                {range.toUpperCase()}
              </button>
            ))}
          </div>
        </motion.div>

        {/* Device Selector */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="card p-4"
        >
          <label className="flex items-center gap-2 text-sm font-bold text-gray-700 dark:text-gray-300 mb-3">
            <Activity className="w-4 h-4" />
            Device
          </label>
          <select
            value={selectedDevice}
            onChange={(e) => setSelectedDevice(e.target.value)}
            className="w-full px-4 py-2 rounded-lg border-2 border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white font-medium focus:border-primary-500 focus:ring-2 focus:ring-primary-500/20 transition-all"
          >
            <option value="PUMP_001">PUMP_001</option>
            <option value="PUMP_002">PUMP_002</option>
          </select>
        </motion.div>
      </div>

      {loading ? (
        <div className="card p-12 text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600 mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400">Loading analytics data...</p>
        </div>
      ) : (
        <>
          {/* Voltage Trends */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="card p-6"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 rounded-lg bg-gradient-to-br from-blue-500 to-blue-700 shadow-md">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-black text-gray-900 dark:text-white">
                  Voltage Trends (3-Phase)
                </h2>
                <p className="text-xs text-gray-600 dark:text-gray-400">
                  Real-time voltage monitoring across all phases
                </p>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" opacity={0.1} />
                <XAxis
                  dataKey="time"
                  stroke="#6B7280"
                  style={{ fontSize: '12px', fontWeight: 'bold' }}
                />
                <YAxis
                  stroke="#6B7280"
                  style={{ fontSize: '12px', fontWeight: 'bold' }}
                  label={{ value: 'Voltage (V)', angle: -90, position: 'insideLeft' }}
                />
                <Tooltip content={<CustomTooltip />} />
                <Legend wrapperStyle={{ fontSize: '12px', fontWeight: 'bold' }} />
                <Line
                  type="monotone"
                  dataKey="voltage1R"
                  stroke="#ef4444"
                  strokeWidth={2}
                  name="Pump 1 - R Phase"
                  dot={false}
                />
                <Line
                  type="monotone"
                  dataKey="voltage1Y"
                  stroke="#f59e0b"
                  strokeWidth={2}
                  name="Pump 1 - Y Phase"
                  dot={false}
                />
                <Line
                  type="monotone"
                  dataKey="voltage1B"
                  stroke="#3b82f6"
                  strokeWidth={2}
                  name="Pump 1 - B Phase"
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </motion.div>

          {/* Current Trends */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="card p-6"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 rounded-lg bg-gradient-to-br from-green-500 to-green-700 shadow-md">
                <Activity className="w-5 h-5 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-black text-gray-900 dark:text-white">
                  Current Trends (3-Phase)
                </h2>
                <p className="text-xs text-gray-600 dark:text-gray-400">
                  Current consumption patterns over time
                </p>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorR" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ef4444" stopOpacity={0.8} />
                    <stop offset="95%" stopColor="#ef4444" stopOpacity={0.1} />
                  </linearGradient>
                  <linearGradient id="colorY" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.8} />
                    <stop offset="95%" stopColor="#f59e0b" stopOpacity={0.1} />
                  </linearGradient>
                  <linearGradient id="colorB" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.8} />
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0.1} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" opacity={0.1} />
                <XAxis
                  dataKey="time"
                  stroke="#6B7280"
                  style={{ fontSize: '12px', fontWeight: 'bold' }}
                />
                <YAxis
                  stroke="#6B7280"
                  style={{ fontSize: '12px', fontWeight: 'bold' }}
                  label={{ value: 'Current (A)', angle: -90, position: 'insideLeft' }}
                />
                <Tooltip content={<CustomTooltip />} />
                <Legend wrapperStyle={{ fontSize: '12px', fontWeight: 'bold' }} />
                <Area
                  type="monotone"
                  dataKey="current1R"
                  stroke="#ef4444"
                  fillOpacity={1}
                  fill="url(#colorR)"
                  name="Pump 1 - R Phase"
                />
                <Area
                  type="monotone"
                  dataKey="current1Y"
                  stroke="#f59e0b"
                  fillOpacity={1}
                  fill="url(#colorY)"
                  name="Pump 1 - Y Phase"
                />
                <Area
                  type="monotone"
                  dataKey="current1B"
                  stroke="#3b82f6"
                  fillOpacity={1}
                  fill="url(#colorB)"
                  name="Pump 1 - B Phase"
                />
              </AreaChart>
            </ResponsiveContainer>
          </motion.div>

          {/* Power Consumption */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="card p-6"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 rounded-lg bg-gradient-to-br from-purple-500 to-purple-700 shadow-md">
                <Battery className="w-5 h-5 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-black text-gray-900 dark:text-white">
                  Power Consumption (3-Phase)
                </h2>
                <p className="text-xs text-gray-600 dark:text-gray-400">
                  Power usage analysis and comparison
                </p>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" opacity={0.1} />
                <XAxis
                  dataKey="time"
                  stroke="#6B7280"
                  style={{ fontSize: '12px', fontWeight: 'bold' }}
                />
                <YAxis
                  stroke="#6B7280"
                  style={{ fontSize: '12px', fontWeight: 'bold' }}
                  label={{ value: 'Power (W)', angle: -90, position: 'insideLeft' }}
                />
                <Tooltip content={<CustomTooltip />} />
                <Legend wrapperStyle={{ fontSize: '12px', fontWeight: 'bold' }} />
                <Bar dataKey="power1R" fill="#ef4444" name="Pump 1 - R Phase" />
                <Bar dataKey="power1Y" fill="#f59e0b" name="Pump 1 - Y Phase" />
                <Bar dataKey="power1B" fill="#3b82f6" name="Pump 1 - B Phase" />
              </BarChart>
            </ResponsiveContainer>
          </motion.div>

          {/* Running Hours Comparison */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="card p-6"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 rounded-lg bg-gradient-to-br from-indigo-500 to-indigo-700 shadow-md">
                <Clock className="w-5 h-5 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-black text-gray-900 dark:text-white">
                  Running Hours Trend
                </h2>
                <p className="text-xs text-gray-600 dark:text-gray-400">
                  Cumulative runtime comparison
                </p>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" opacity={0.1} />
                <XAxis
                  dataKey="time"
                  stroke="#6B7280"
                  style={{ fontSize: '12px', fontWeight: 'bold' }}
                />
                <YAxis
                  stroke="#6B7280"
                  style={{ fontSize: '12px', fontWeight: 'bold' }}
                  label={{ value: 'Hours', angle: -90, position: 'insideLeft' }}
                />
                <Tooltip content={<CustomTooltip />} />
                <Legend wrapperStyle={{ fontSize: '12px', fontWeight: 'bold' }} />
                <Line
                  type="monotone"
                  dataKey="rhs1"
                  stroke="#6366f1"
                  strokeWidth={3}
                  name="Pump 1"
                  dot={{ r: 4 }}
                />
                <Line
                  type="monotone"
                  dataKey="rhs2"
                  stroke="#8b5cf6"
                  strokeWidth={3}
                  name="Pump 2"
                  dot={{ r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </motion.div>
        </>
      )}
    </div>
  );
};

export default Analytics;

