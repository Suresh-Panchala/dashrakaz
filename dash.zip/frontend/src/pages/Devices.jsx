import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Trash2, Edit, MapPin, Activity, X, Save, Radio } from 'lucide-react';
import toast from 'react-hot-toast';
import { devicesAPI } from '../services/api';
import { format } from 'date-fns';

const Devices = () => {
  const [devices, setDevices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    deviceId: '',
    name: '',
    location: '',
    latitude: '',
    longitude: '',
    description: ''
  });

  useEffect(() => {
    fetchDevices();
  }, []);

  const fetchDevices = async () => {
    try {
      setLoading(true);
      const response = await devicesAPI.getAll();
      if (response.data.success) {
        setDevices(response.data.data);
      }
    } catch (error) {
      console.error('Error fetching devices:', error);
      toast.error('Failed to fetch devices');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.deviceId || !formData.name || !formData.location) {
      toast.error('Please fill in all required fields');
      return;
    }

    try {
      const deviceData = {
        deviceId: formData.deviceId,
        name: formData.name,
        location: formData.location,
        coordinates: {
          latitude: parseFloat(formData.latitude) || null,
          longitude: parseFloat(formData.longitude) || null
        },
        metadata: {
          description: formData.description
        }
      };

      const response = await devicesAPI.create(deviceData);
      
      if (response.data.success) {
        toast.success('Device added successfully!');
        setShowModal(false);
        setFormData({
          deviceId: '',
          name: '',
          location: '',
          latitude: '',
          longitude: '',
          description: ''
        });
        fetchDevices();
      }
    } catch (error) {
      console.error('Error creating device:', error);
      toast.error(error.response?.data?.message || 'Failed to create device');
    }
  };

  const handleDelete = async (deviceId, deviceName) => {
    if (!confirm(`Are you sure you want to delete "${deviceName}"?`)) {
      return;
    }

    try {
      const response = await devicesAPI.delete(deviceId);
      
      if (response.data.success) {
        toast.success(`Device "${deviceName}" deleted successfully!`);
        // Immediately update the local state to remove the device
        setDevices(devices.filter(d => d.deviceId !== deviceId));
      }
    } catch (error) {
      console.error('Error deleting device:', error);
      toast.error(error.response?.data?.message || 'Failed to delete device');
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'online':
        return 'text-success-600 bg-success-100 dark:bg-success-900/20';
      case 'offline':
        return 'text-gray-600 bg-gray-100 dark:bg-gray-800';
      case 'maintenance':
        return 'text-warning-600 bg-warning-100 dark:bg-warning-900/20';
      case 'pending':
        return 'text-primary-600 bg-primary-100 dark:bg-primary-900/20';
      default:
        return 'text-gray-600 bg-gray-100';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="spinner" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Device Management
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            Add, edit, and manage IoT devices
          </p>
        </div>

        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => setShowModal(true)}
          className="btn-primary flex items-center gap-2"
        >
          <Plus className="w-5 h-5" />
          Add Device
        </motion.button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { label: 'Total Devices', value: devices.length, color: 'primary', icon: Activity },
          { label: 'Online', value: devices.filter(d => d.status === 'online').length, color: 'success', icon: Radio },
          { label: 'Pending', value: devices.filter(d => d.status === 'pending').length, color: 'primary', icon: Activity },
          { label: 'Offline', value: devices.filter(d => d.status === 'offline').length, color: 'gray', icon: Activity }
        ].map((stat, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="card p-6"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">{stat.label}</p>
                <p className="text-3xl font-bold text-gray-900 dark:text-white mt-1">
                  {stat.value}
                </p>
              </div>
              <stat.icon className={`w-10 h-10 text-${stat.color}-600 opacity-20`} />
            </div>
          </motion.div>
        ))}
      </div>

      {/* Devices Grid */}
      {devices.length === 0 ? (
        <div className="card p-12 text-center">
          <Activity className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
            No devices found
          </h3>
          <p className="text-gray-600 dark:text-gray-400 mb-4">
            Get started by adding your first IoT device
          </p>
          <button
            onClick={() => setShowModal(true)}
            className="btn-primary inline-flex items-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Add First Device
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {devices.map((device, index) => (
            <motion.div
              key={device._id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.05 }}
              whileHover={{ y: -5 }}
              className="card p-6 relative overflow-hidden group"
            >
              {/* Status Indicator */}
              <div className="absolute top-0 right-0 w-32 h-32 -mt-16 -mr-16">
                <div className={`w-full h-full rounded-full ${
                  device.status === 'online' 
                    ? 'bg-success-500/10' 
                    : device.status === 'pending'
                    ? 'bg-primary-500/10'
                    : 'bg-gray-500/10'
                } group-hover:scale-150 transition-transform duration-500`} />
              </div>

              {/* Device Header */}
              <div className="flex items-start justify-between mb-4 relative z-10">
                <div className="flex items-center gap-3">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                    device.status === 'online' 
                      ? 'bg-gradient-to-br from-success-400 to-success-600' 
                      : device.status === 'pending'
                      ? 'bg-gradient-to-br from-primary-400 to-primary-600'
                      : 'bg-gray-400'
                  }`}>
                    <Activity className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 dark:text-white">
                      {device.name}
                    </h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      {device.deviceId}
                    </p>
                  </div>
                </div>

                <span className={`badge ${getStatusColor(device.status)} capitalize`}>
                  {device.status}
                </span>
              </div>

              {/* Device Info */}
              <div className="space-y-3 mb-4">
                <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                  <MapPin className="w-4 h-4" />
                  <span>{device.location}</span>
                </div>

                {device.lastSeen && (
                  <div className="text-sm text-gray-500 dark:text-gray-400">
                    Last seen: {format(new Date(device.lastSeen), 'PPp')}
                  </div>
                )}

                {device.metadata?.description && (
                  <p className="text-sm text-gray-600 dark:text-gray-400 line-clamp-2">
                    {device.metadata.description}
                  </p>
                )}
              </div>

              {/* Actions */}
              <div className="flex gap-2 pt-4 border-t border-gray-200 dark:border-gray-700">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="flex-1 btn-secondary text-sm"
                >
                  <Edit className="w-4 h-4 mr-2" />
                  Edit
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => handleDelete(device.deviceId, device.name)}
                  className="btn text-sm bg-danger-100 dark:bg-danger-900/20 text-danger-600 hover:bg-danger-200 dark:hover:bg-danger-900/30"
                >
                  <Trash2 className="w-4 h-4" />
                </motion.button>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {/* Add Device Modal */}
      <AnimatePresence>
        {showModal && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="glass card p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                  Add New Device
                </h2>
                <button
                  onClick={() => setShowModal(false)}
                  className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                {/* Device ID */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Device ID <span className="text-danger-600">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.deviceId}
                    onChange={(e) => setFormData({ ...formData, deviceId: e.target.value })}
                    className="input"
                    placeholder="StromWater_Device_2"
                    required
                  />
                </div>

                {/* Device Name */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Device Name <span className="text-danger-600">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="input"
                    placeholder="StormWater Pump Station 2"
                    required
                  />
                </div>

                {/* Location */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Location <span className="text-danger-600">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    className="input"
                    placeholder="Dubai Marina"
                    required
                  />
                </div>

                {/* Coordinates */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Latitude
                    </label>
                    <input
                      type="number"
                      step="any"
                      value={formData.latitude}
                      onChange={(e) => setFormData({ ...formData, latitude: e.target.value })}
                      className="input"
                      placeholder="25.0772"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Longitude
                    </label>
                    <input
                      type="number"
                      step="any"
                      value={formData.longitude}
                      onChange={(e) => setFormData({ ...formData, longitude: e.target.value })}
                      className="input"
                      placeholder="55.1286"
                    />
                  </div>
                </div>

                {/* Description */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Description
                  </label>
                  <textarea
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    className="input"
                    rows="3"
                    placeholder="Enter device description..."
                  />
                </div>

                {/* Actions */}
                <div className="flex gap-3 pt-4">
                  <button
                    type="button"
                    onClick={() => setShowModal(false)}
                    className="flex-1 btn-secondary"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 btn-primary flex items-center justify-center gap-2"
                  >
                    <Save className="w-5 h-5" />
                    Add Device
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Devices;

