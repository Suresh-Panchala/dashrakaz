import { useState } from 'react';
import { motion } from 'framer-motion';
import { AlertCircle, CheckCircle, Clock, Filter } from 'lucide-react';
import { useAlerts } from '../hooks/useAlerts';
import { format } from 'date-fns';

const Alerts = () => {
  const [filter, setFilter] = useState('all');
  const { alerts, stats, loading, acknowledgeAlert } = useAlerts();

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'critical':
        return 'danger';
      case 'warning':
        return 'warning';
      case 'info':
        return 'info';
      default:
        return 'gray';
    }
  };

  const getSeverityIcon = (severity) => {
    switch (severity) {
      case 'critical':
        return '🚨';
      case 'warning':
        return '⚠️';
      case 'info':
        return 'ℹ️';
      default:
        return '📢';
    }
  };

  const filteredAlerts = alerts.filter((alert) => {
    if (filter === 'all') return true;
    return alert.severity === filter;
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="spinner" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Alerts
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            Monitor and manage system alerts
          </p>
        </div>
      </div>

      {/* Stats Cards */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="card p-6"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Total Alerts</p>
                <p className="text-3xl font-bold text-gray-900 dark:text-white mt-1">
                  {stats.total}
                </p>
              </div>
              <AlertCircle className="w-10 h-10 text-primary-600 opacity-20" />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="card p-6 bg-danger-50 dark:bg-danger-900/20"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-danger-600">Critical</p>
                <p className="text-3xl font-bold text-danger-600 mt-1">
                  {stats.bySeverity?.critical || 0}
                </p>
              </div>
              <div className="text-4xl">🚨</div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="card p-6 bg-warning-50 dark:bg-warning-900/20"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-warning-600">Warning</p>
                <p className="text-3xl font-bold text-warning-600 mt-1">
                  {stats.bySeverity?.warning || 0}
                </p>
              </div>
              <div className="text-4xl">⚠️</div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="card p-6 bg-primary-50 dark:bg-primary-900/20"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-primary-600">Unacknowledged</p>
                <p className="text-3xl font-bold text-primary-600 mt-1">
                  {stats.unacknowledged}
                </p>
              </div>
              <Clock className="w-10 h-10 text-primary-600 opacity-50" />
            </div>
          </motion.div>
        </div>
      )}

      {/* Filter */}
      <div className="card p-4">
        <div className="flex items-center gap-3">
          <Filter className="w-5 h-5 text-gray-500" />
          <span className="text-sm text-gray-600 dark:text-gray-400">Filter:</span>
          {['all', 'critical', 'warning', 'info'].map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-3 py-1 rounded-lg text-sm font-medium transition-colors ${
                filter === f
                  ? 'bg-primary-600 text-white'
                  : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-gray-600'
              }`}
            >
              {f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Alerts List */}
      <div className="space-y-4">
        {filteredAlerts.length === 0 ? (
          <div className="card p-12 text-center">
            <CheckCircle className="w-16 h-16 text-success-500 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
              No alerts found
            </h3>
            <p className="text-gray-600 dark:text-gray-400">
              All systems are operating normally
            </p>
          </div>
        ) : (
          filteredAlerts.map((alert, index) => {
            const severityColor = getSeverityColor(alert.severity);
            const severityIcon = getSeverityIcon(alert.severity);

            return (
              <motion.div
                key={alert._id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className={`card p-6 border-l-4 border-${severityColor}-500 bg-${severityColor}-50 dark:bg-${severityColor}-900/20`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-4 flex-1">
                    <div className="text-3xl">{severityIcon}</div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                          {alert.alertType}
                        </h3>
                        <span className={`badge badge-${severityColor}`}>
                          {alert.severity}
                        </span>
                      </div>
                      <p className="text-gray-700 dark:text-gray-300 mb-2">
                        {alert.message}
                      </p>
                      <div className="flex items-center gap-4 text-sm text-gray-500 dark:text-gray-400">
                        <span>Device: {alert.deviceId}</span>
                        <span>•</span>
                        <span>{format(new Date(alert.createdAt), 'PPp')}</span>
                        {alert.value !== null && (
                          <>
                            <span>•</span>
                            <span>Value: {alert.value}</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {!alert.acknowledged && (
                    <button
                      onClick={() => acknowledgeAlert(alert._id)}
                      className="btn-primary flex items-center gap-2"
                    >
                      <CheckCircle className="w-4 h-4" />
                      Acknowledge
                    </button>
                  )}
                </div>
              </motion.div>
            );
          })
        )}
      </div>
    </div>
  );
};

export default Alerts;

