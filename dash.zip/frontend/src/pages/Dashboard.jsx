import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Download, Calendar, RefreshCw, Droplet } from 'lucide-react';
import toast from 'react-hot-toast';
import { useDevices, useDeviceData } from '../hooks/useDeviceData';
import { dataAPI } from '../services/api';
import WaterTank from '../components/WaterTank';
import PumpStatus from '../components/PumpStatus';
import ParameterCards from '../components/ParameterCards';

const Dashboard = () => {
  const { devices, loading: devicesLoading } = useDevices();
  const [selectedDevice, setSelectedDevice] = useState(null);
  const [chartData, setChartData] = useState([]);
  const [period, setPeriod] = useState('24h');
  const [exporting, setExporting] = useState(false);

  const { latestData, loading: dataLoading } = useDeviceData(selectedDevice?.deviceId);

  useEffect(() => {
    if (devices.length > 0 && !selectedDevice) {
      setSelectedDevice(devices[0]);
    }
  }, [devices, selectedDevice]);

  useEffect(() => {
    if (selectedDevice) {
      fetchChartData();
    }
  }, [selectedDevice, period]);

  const fetchChartData = async () => {
    if (!selectedDevice) return;

    try {
      const response = await dataAPI.getChartData(selectedDevice.deviceId, { period });
      if (response.data.success) {
        setChartData(response.data.data);
      }
    } catch (error) {
      console.error('Error fetching chart data:', error);
    }
  };

  const handleExport = async (format) => {
    if (!selectedDevice) return;

    setExporting(true);
    try {
      // Get last 24 hours of data
      const endDate = new Date();
      const startDate = new Date(endDate.getTime() - 24 * 60 * 60 * 1000);

      const response = format === 'csv' 
        ? await dataAPI.exportCSV(selectedDevice.deviceId, {
            startDate: startDate.toISOString(),
            endDate: endDate.toISOString()
          })
        : await dataAPI.exportPDF(selectedDevice.deviceId, {
            startDate: startDate.toISOString(),
            endDate: endDate.toISOString()
          });

      if (!response.data || response.data.size === 0) {
        toast.error('No data available to export');
        return;
      }

      const blob = new Blob([response.data], { 
        type: format === 'csv' ? 'text/csv' : 'application/pdf' 
      });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${selectedDevice.deviceId}_${Date.now()}.${format}`;
      document.body.appendChild(link);
      link.click();
      
      setTimeout(() => {
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
      }, 100);

      toast.success(`Exported ${format.toUpperCase()} successfully`);
    } catch (error) {
      console.error('Export error:', error);
      const errorMessage = error.response?.data?.message || error.message || 'Failed to export data';
      toast.error(errorMessage);
    } finally {
      setExporting(false);
    }
  };

  if (devicesLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="spinner" />
      </div>
    );
  }

  if (devices.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500 dark:text-gray-400">No devices found</p>
      </div>
    );
  }

  const data = latestData?.data || {};

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Dashboard
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            Real-time monitoring and analytics
          </p>
        </div>

        <div className="flex items-center gap-3">
          {/* Device Selector */}
          <select
            value={selectedDevice?.deviceId || ''}
            onChange={(e) => {
              const device = devices.find(d => d.deviceId === e.target.value);
              setSelectedDevice(device);
            }}
            className="input"
          >
            {devices.map((device) => (
              <option key={device.deviceId} value={device.deviceId}>
                {device.name || device.deviceId}
              </option>
            ))}
          </select>

          {/* Export Dropdown */}
          <div className="relative group">
            <button
              disabled={exporting}
              className="btn-secondary flex items-center gap-2"
            >
              <Download className="w-4 h-4" />
              Export
            </button>
            <div className="absolute right-0 mt-2 w-48 glass rounded-lg shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-10">
              <button
                onClick={() => handleExport('csv')}
                className="w-full px-4 py-2 text-left text-sm hover:bg-gray-100 dark:hover:bg-gray-700 rounded-t-lg"
              >
                Export as CSV
              </button>
              <button
                onClick={() => handleExport('pdf')}
                className="w-full px-4 py-2 text-left text-sm hover:bg-gray-100 dark:hover:bg-gray-700 rounded-b-lg"
              >
                Export as PDF
              </button>
            </div>
          </div>

          {/* Refresh */}
          <button
            onClick={fetchChartData}
            className="btn-secondary"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Device Info */}
      <div className="card p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
              {selectedDevice?.name || selectedDevice?.deviceId}
            </h2>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Location: {selectedDevice?.location || 'Unknown'}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <div className={`w-3 h-3 rounded-full ${
              selectedDevice?.status === 'online' ? 'bg-success-500 animate-pulse' : 'bg-gray-400'
            }`} />
            <span className={`text-sm font-medium ${
              selectedDevice?.status === 'online' ? 'text-success-600' : 'text-gray-500'
            }`}>
              {selectedDevice?.status || 'Unknown'}
            </span>
          </div>
        </div>
      </div>

      {/* Alerts Summary */}
      {(data.DryRunAlert === 1 || data.HighLevelFloatAlert === 1) && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="card p-4 bg-danger-50 dark:bg-danger-900/20 border-l-4 border-danger-500"
        >
          <div className="flex items-center gap-3">
            <div className="text-danger-600">
              {data.DryRunAlert === 1 && <p className="font-medium">⚠️ Dry Run Alert Active</p>}
              {data.HighLevelFloatAlert === 1 && <p className="font-medium">⚠️ High Level Float Alert Active</p>}
            </div>
          </div>
        </motion.div>
      )}

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Water Tank */}
        <div className="card p-6">
          <WaterTank level={data.Hydrostatic_Value || 0} maxLevel={100} />
        </div>

        {/* Pump Status Cards */}
        <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-6">
          <PumpStatus pumpNumber={1} data={data} />
          <PumpStatus pumpNumber={2} data={data} />
        </div>
      </div>

      {/* Electrical Parameters - Both Pumps Side by Side */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Pump 1 */}
        <ParameterCards pumpNumber={1} data={data} columns={3} />
        
        {/* Pump 2 */}
        <ParameterCards pumpNumber={2} data={data} columns={3} />
      </div>

      {/* Last Update */}
      {latestData?.timestamp && (
        <div className="text-center text-sm text-gray-500 dark:text-gray-400">
          Last updated: {new Date(latestData.timestamp).toLocaleString()}
        </div>
      )}
    </div>
  );
};

export default Dashboard;

