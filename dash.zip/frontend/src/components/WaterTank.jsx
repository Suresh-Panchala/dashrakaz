import { motion } from 'framer-motion';
import { Droplet, TrendingUp, TrendingDown } from 'lucide-react';

const WaterTank = ({ level = 0, maxLevel = 100 }) => {
  const percentage = Math.min(Math.max((level / maxLevel) * 100, 0), 100);
  
  const getStatus = () => {
    if (percentage < 20) return { 
      color: '#ef4444', 
      gradient: 'from-red-500 to-red-700',
      label: 'Critical Low', 
      bg: 'bg-red-50 dark:bg-red-950/30',
      text: 'text-red-700 dark:text-red-300'
    };
    if (percentage < 50) return { 
      color: '#f59e0b', 
      gradient: 'from-orange-500 to-orange-700',
      label: 'Low', 
      bg: 'bg-orange-50 dark:bg-orange-950/30',
      text: 'text-orange-700 dark:text-orange-300'
    };
    if (percentage < 80) return { 
      color: '#3b82f6', 
      gradient: 'from-blue-500 to-blue-700',
      label: 'Normal', 
      bg: 'bg-blue-50 dark:bg-blue-950/30',
      text: 'text-blue-700 dark:text-blue-300'
    };
    return { 
      color: '#10b981', 
      gradient: 'from-green-500 to-green-700',
      label: 'Optimal', 
      bg: 'bg-green-50 dark:bg-green-950/30',
      text: 'text-green-700 dark:text-green-300'
    };
  };

  const status = getStatus();

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className={`card p-6 ${status.bg} border-l-4 border-${status.gradient.split('-')[1]}-500`}
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className={`p-3 rounded-xl bg-gradient-to-br ${status.gradient} shadow-lg`}>
            <Droplet className="w-6 h-6 text-white" fill="white" />
          </div>
          <div>
            <h3 className="text-lg font-black text-gray-900 dark:text-white">
              Water Level
            </h3>
            <p className={`text-sm font-bold ${status.text}`}>
              {status.label}
            </p>
          </div>
        </div>
      </div>

      {/* Visual Tank & Stats Grid */}
      <div className="grid grid-cols-2 gap-6">
        {/* Compact Tank Visual */}
        <div className="relative">
          <svg viewBox="0 0 120 180" className="w-full h-auto">
            {/* Tank Outline */}
            <path
              d="M 30 30 L 30 150 Q 30 165 45 165 L 75 165 Q 90 165 90 150 L 90 30 Q 90 15 75 15 L 45 15 Q 30 15 30 30"
              fill="none"
              stroke="currentColor"
              strokeWidth="3"
              className="text-gray-300 dark:text-gray-600"
            />
            {/* Water Fill */}
            <motion.path
              initial={{ d: "M 30 150 L 30 150 Q 30 165 45 165 L 75 165 Q 90 165 90 150 L 90 150" }}
              animate={{
                d: `M 30 ${150 - (percentage * 1.35)} L 30 150 Q 30 165 45 165 L 75 165 Q 90 165 90 150 L 90 ${150 - (percentage * 1.35)}`
              }}
              transition={{ duration: 1.5, ease: "easeOut" }}
              fill={status.color}
              opacity="0.4"
            />
            {/* Water Surface Wave */}
            <motion.path
              animate={{
                d: [
                  `M 30 ${150 - (percentage * 1.35)} Q 60 ${148 - (percentage * 1.35)} 90 ${150 - (percentage * 1.35)}`,
                  `M 30 ${150 - (percentage * 1.35)} Q 60 ${152 - (percentage * 1.35)} 90 ${150 - (percentage * 1.35)}`,
                  `M 30 ${150 - (percentage * 1.35)} Q 60 ${148 - (percentage * 1.35)} 90 ${150 - (percentage * 1.35)}`
                ]
              }}
              transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
              fill="none"
              stroke={status.color}
              strokeWidth="3"
            />
          </svg>
        </div>

        {/* Stats */}
        <div className="flex flex-col justify-center space-y-4">
          {/* Current Level */}
          <div>
            <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">
              Current
            </p>
            <div className="flex items-baseline gap-2">
              <motion.p 
                initial={{ scale: 0.8 }}
                animate={{ scale: 1 }}
                className="text-5xl font-black"
                style={{ color: status.color }}
              >
                {level.toFixed(0)}
              </motion.p>
              <span className="text-lg font-bold text-gray-500 dark:text-gray-400">
                units
              </span>
            </div>
          </div>

          {/* Percentage */}
          <div>
            <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">
              Fill Level
            </p>
            <div className="flex items-center gap-2">
              <div className="flex-1 h-3 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${percentage}%` }}
                  transition={{ duration: 1, ease: "easeOut" }}
                  className={`h-full bg-gradient-to-r ${status.gradient}`}
                />
              </div>
              <span className={`text-2xl font-black ${status.text} tabular-nums`}>
                {percentage.toFixed(0)}%
              </span>
            </div>
          </div>

          {/* Max Capacity */}
          <div className="pt-3 border-t border-gray-200 dark:border-gray-700">
            <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">
              Capacity
            </p>
            <p className="text-xl font-bold text-gray-700 dark:text-gray-300">
              {maxLevel} units
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default WaterTank;

