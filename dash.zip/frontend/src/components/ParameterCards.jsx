import { motion } from 'framer-motion';
import { 
  Zap, 
  Activity, 
  TrendingUp, 
  Lightbulb,
  Radio,
  Gauge,
  BatteryCharging,
  Circle
} from 'lucide-react';

const ParameterCard = ({ label, value, unit, icon: Icon, color = 'primary', phase = '' }) => {
  // Get phase-specific styling
  const getPhaseStyles = () => {
    if (phase === 'R') {
      return {
        dotColor: 'bg-red-500',
        badgeBg: 'bg-red-50 dark:bg-red-900/20',
        badgeText: 'text-red-700 dark:text-red-300',
        borderHover: 'hover:border-red-300 dark:hover:border-red-700',
        gradientFrom: 'from-red-400',
        gradientTo: 'to-red-600',
        iconBg: 'from-red-500 to-red-700'
      };
    }
    if (phase === 'Y') {
      return {
        dotColor: 'bg-yellow-500',
        badgeBg: 'bg-yellow-50 dark:bg-yellow-900/20',
        badgeText: 'text-yellow-700 dark:text-yellow-300',
        borderHover: 'hover:border-yellow-300 dark:hover:border-yellow-700',
        gradientFrom: 'from-yellow-400',
        gradientTo: 'to-yellow-600',
        iconBg: 'from-yellow-500 to-yellow-700'
      };
    }
    if (phase === 'B') {
      // B Phase has distinct dark gradient design
      return {
        dotColor: 'bg-blue-500',
        badgeBg: 'bg-gradient-to-r from-blue-500 to-indigo-600',
        badgeText: 'text-white font-bold',
        borderHover: 'hover:border-blue-400 dark:hover:border-blue-600 hover:shadow-lg hover:shadow-blue-500/50',
        gradientFrom: 'from-blue-500',
        gradientTo: 'to-indigo-600',
        iconBg: 'from-blue-600 to-indigo-700',
        cardBg: 'bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950/30 dark:to-indigo-950/30'
      };
    }
    return {
      dotColor: 'bg-gray-500',
      badgeBg: 'bg-gray-100 dark:bg-gray-800',
      badgeText: 'text-gray-700 dark:text-gray-300',
      borderHover: 'hover:border-primary-300',
      gradientFrom: 'from-primary-400',
      gradientTo: 'to-primary-600',
      iconBg: 'from-primary-500 to-primary-700'
    };
  };

  const styles = getPhaseStyles();
  const isBluePhase = phase === 'B';

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -5, scale: 1.05 }}
      transition={{ duration: 0.25, ease: "easeOut" }}
      className={`card p-3 relative overflow-hidden group cursor-pointer border-2 border-transparent ${styles.borderHover} ${isBluePhase ? styles.cardBg : ''}`}
    >
      {/* Background Gradient - stronger for B phase */}
      <div className={`absolute top-0 right-0 w-28 h-28 -mt-14 -mr-14 bg-gradient-to-br ${styles.gradientFrom} ${styles.gradientTo} ${isBluePhase ? 'opacity-20' : 'opacity-10'} rounded-full group-hover:scale-150 transition-transform duration-500`} />
      
      {/* Content */}
      <div className="relative z-10">
        {/* Icon and Phase Badge - horizontal layout for compact design */}
        <div className="flex items-center justify-between mb-2">
          <div className={`p-2 rounded-lg bg-gradient-to-br ${styles.iconBg} shadow-md group-hover:shadow-lg transition-all`}>
            <Icon className="w-4 h-4 text-white" strokeWidth={2.5} />
          </div>
          {phase && (
            <div className={`flex items-center gap-1 px-2 py-0.5 rounded-full ${styles.badgeBg} ${isBluePhase ? 'shadow-md' : ''}`}>
              <div className={`w-1.5 h-1.5 rounded-full ${styles.dotColor} ${isBluePhase ? 'animate-pulse' : ''}`} />
              <span className={`text-xs font-extrabold ${styles.badgeText}`}>{phase}</span>
            </div>
          )}
        </div>
        
        {/* Label - smaller, compact */}
        <p className="text-[10px] font-semibold text-gray-500 dark:text-gray-400 mb-1.5 uppercase tracking-wider truncate">
          {label}
        </p>
        
        {/* Value - MUCH LARGER */}
        <div className="flex items-end gap-1.5">
          <p className={`text-4xl font-black ${isBluePhase ? 'text-blue-700 dark:text-blue-300' : 'text-gray-900 dark:text-white'} tabular-nums leading-none`}>
            {typeof value === 'number' ? value.toFixed(1) : value || '--'}
          </p>
          {unit && (
            <span className={`text-base font-bold ${isBluePhase ? 'text-blue-600 dark:text-blue-400' : 'text-gray-500 dark:text-gray-400'} mb-0.5`}>
              {unit}
            </span>
          )}
        </div>
      </div>

      {/* Bottom accent line - thicker for B phase */}
      <div className={`absolute bottom-0 left-0 right-0 ${isBluePhase ? 'h-1.5' : 'h-1'} bg-gradient-to-r ${styles.gradientFrom} ${styles.gradientTo} transform scale-x-0 group-hover:scale-x-100 transition-transform duration-400 ${isBluePhase ? 'shadow-lg shadow-blue-500/50' : ''}`} />
      
      {/* Corner accent for B phase */}
      {isBluePhase && (
        <div className="absolute top-0 right-0 w-12 h-12">
          <div className="absolute top-0 right-0 w-0 h-0 border-t-[20px] border-r-[20px] border-t-blue-500/20 border-r-transparent" />
        </div>
      )}
    </motion.div>
  );
};

const ParameterCards = ({ pumpNumber, data, columns = 6 }) => {
  const parameterGroups = [
    {
      title: '⚡ Voltage (VRMS)',
      icon: Zap,
      params: [
        {
          label: 'R Phase',
          value: data[`VRMS_${pumpNumber}_R`],
          unit: 'V',
          icon: Zap,
          color: 'danger',
          phase: 'R'
        },
        {
          label: 'Y Phase',
          value: data[`VRMS_${pumpNumber}_Y`],
          unit: 'V',
          icon: Zap,
          color: 'warning',
          phase: 'Y'
        },
        {
          label: 'B Phase',
          value: data[`VRMS_${pumpNumber}_B`],
          unit: 'V',
          icon: Zap,
          color: 'primary',
          phase: 'B'
        },
      ]
    },
    {
      title: '🔌 Current (IRMS)',
      icon: Activity,
      params: [
        {
          label: 'R Phase',
          value: data[`IRMS_${pumpNumber}_R`],
          unit: 'A',
          icon: Activity,
          color: 'danger',
          phase: 'R'
        },
        {
          label: 'Y Phase',
          value: data[`IRMS_${pumpNumber}_Y`],
          unit: 'A',
          icon: Activity,
          color: 'warning',
          phase: 'Y'
        },
        {
          label: 'B Phase',
          value: data[`IRMS_${pumpNumber}_B`],
          unit: 'A',
          icon: Activity,
          color: 'primary',
          phase: 'B'
        },
      ]
    },
    {
      title: '💡 Power',
      icon: Lightbulb,
      params: [
        {
          label: 'R Phase',
          value: data[`POWER_${pumpNumber}_R`],
          unit: 'W',
          icon: Lightbulb,
          color: 'danger',
          phase: 'R'
        },
        {
          label: 'Y Phase',
          value: data[`POWER_${pumpNumber}_Y`],
          unit: 'W',
          icon: Lightbulb,
          color: 'warning',
          phase: 'Y'
        },
        {
          label: 'B Phase',
          value: data[`POWER_${pumpNumber}_B`],
          unit: 'W',
          icon: Lightbulb,
          color: 'primary',
          phase: 'B'
        },
      ]
    },
    {
      title: '🔋 Energy (VAHR)',
      icon: BatteryCharging,
      params: [
        {
          label: 'R Phase',
          value: data[`VAHR_${pumpNumber}_R`],
          unit: 'VAh',
          icon: BatteryCharging,
          color: 'danger',
          phase: 'R'
        },
        {
          label: 'Y Phase',
          value: data[`VAHR_${pumpNumber}_Y`],
          unit: 'VAh',
          icon: BatteryCharging,
          color: 'warning',
          phase: 'Y'
        },
        {
          label: 'B Phase',
          value: data[`VAHR_${pumpNumber}_B`],
          unit: 'VAh',
          icon: BatteryCharging,
          color: 'primary',
          phase: 'B'
        },
      ]
    },
    {
      title: '📡 Frequency',
      icon: Radio,
      params: [
        {
          label: 'R Phase',
          value: data[`FREQ_${pumpNumber}_R`],
          unit: 'Hz',
          icon: Radio,
          color: 'danger',
          phase: 'R'
        },
        {
          label: 'Y Phase',
          value: data[`FREQ_${pumpNumber}_Y`],
          unit: 'Hz',
          icon: Radio,
          color: 'warning',
          phase: 'Y'
        },
        {
          label: 'B Phase',
          value: data[`FREQ_${pumpNumber}_B`],
          unit: 'Hz',
          icon: Radio,
          color: 'primary',
          phase: 'B'
        },
      ]
    },
  ];

  return (
    <div className="space-y-6">
      {/* Modern Header with Glassmorphism */}
      <div className="card p-4 bg-gradient-to-r from-primary-500/10 via-primary-600/10 to-indigo-600/10 border-l-4 border-primary-500">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-gradient-to-br from-primary-500 to-indigo-600 shadow-lg">
            <Gauge className="w-5 h-5 text-white" strokeWidth={2.5} />
          </div>
          <div>
            <h2 className="text-xl font-black text-gray-900 dark:text-white tracking-tight">
              Pump {pumpNumber} Electrical Parameters
            </h2>
            <p className="text-xs text-gray-600 dark:text-gray-400 font-medium">
              Real-time 3-phase monitoring
            </p>
          </div>
        </div>
      </div>

      {/* Parameter Groups */}
      {parameterGroups.map((group, groupIndex) => (
        <motion.div
          key={groupIndex}
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: groupIndex * 0.08, duration: 0.4 }}
          className="space-y-3"
        >
          {/* Modern Group Title */}
          <div className="flex items-center gap-2 px-3 py-2 bg-gradient-to-r from-gray-100 to-gray-50 dark:from-gray-800 dark:to-gray-900 rounded-lg">
            <div className="w-1 h-5 bg-gradient-to-b from-primary-500 to-indigo-600 rounded-full" />
            <h3 className="text-sm font-black text-gray-800 dark:text-gray-200 uppercase tracking-wide">
              {group.title}
            </h3>
            <div className="flex-1 h-px bg-gradient-to-r from-gray-300 to-transparent dark:from-gray-700" />
          </div>

          {/* Compact Parameter Cards Grid */}
          <div className={`grid gap-2.5 ${
            columns === 3 
              ? 'grid-cols-2 sm:grid-cols-3 md:grid-cols-3' 
              : 'grid-cols-2 sm:grid-cols-3 md:grid-cols-6'
          }`}>
            {group.params.map((param, index) => (
              <ParameterCard
                key={index}
                label={param.label}
                value={param.value}
                unit={param.unit}
                icon={param.icon}
                color={param.color}
                phase={param.phase}
              />
            ))}
          </div>
        </motion.div>
      ))}
    </div>
  );
};

export default ParameterCards;

