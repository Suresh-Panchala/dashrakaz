import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { motion } from 'framer-motion';

const PowerMetrics = ({ pumpNumber, data, chartData = [] }) => {
  const phases = ['R', 'Y', 'B'];

  const metrics = [
    {
      title: 'Voltage (V)',
      field: 'VRMS',
      color: '#3b82f6',
      data: phases.map(phase => ({
        phase,
        value: data?.[`VRMS_${pumpNumber}_${phase}`] || 0
      }))
    },
    {
      title: 'Current (A)',
      field: 'IRMS',
      color: '#f59e0b',
      data: phases.map(phase => ({
        phase,
        value: data?.[`IRMS_${pumpNumber}_${phase}`] || 0
      }))
    },
    {
      title: 'Frequency (Hz)',
      field: 'FREQ',
      color: '#10b981',
      data: phases.map(phase => ({
        phase,
        value: data?.[`FREQ_${pumpNumber}_${phase}`] || 0
      }))
    }
  ];

  return (
    <div className="card p-6">
      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-6">
        Pump {pumpNumber} - Power Metrics
      </h3>

      {/* Current Values Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        {metrics.map((metric, idx) => (
          <motion.div
            key={metric.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className="p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg"
          >
            <h4 className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-3">
              {metric.title}
            </h4>
            <div className="grid grid-cols-3 gap-2">
              {metric.data.map(({ phase, value }) => (
                <div key={phase} className="text-center">
                  <p className="text-xs text-gray-500 dark:text-gray-400 mb-1">
                    {phase}
                  </p>
                  <p
                    className="text-lg font-bold"
                    style={{ color: metric.color }}
                  >
                    {value.toFixed(1)}
                  </p>
                </div>
              ))}
            </div>
          </motion.div>
        ))}
      </div>

      {/* Voltage Chart */}
      {chartData.length > 0 && (
        <div className="mt-6">
          <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
            Voltage Trend
          </h4>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" opacity={0.2} />
              <XAxis
                dataKey="timestamp"
                tickFormatter={(value) => {
                  const date = new Date(value);
                  return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
                }}
                stroke="#9ca3af"
                fontSize={12}
              />
              <YAxis stroke="#9ca3af" fontSize={12} />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#1f2937',
                  border: 'none',
                  borderRadius: '8px',
                  color: '#fff'
                }}
              />
              <Legend />
              <Line
                type="monotone"
                dataKey={`avgVoltage${pumpNumber}R`}
                stroke="#ef4444"
                name="Phase R"
                strokeWidth={2}
                dot={false}
              />
              <Line
                type="monotone"
                dataKey={`avgVoltage${pumpNumber}Y`}
                stroke="#f59e0b"
                name="Phase Y"
                strokeWidth={2}
                dot={false}
              />
              <Line
                type="monotone"
                dataKey={`avgVoltage${pumpNumber}B`}
                stroke="#3b82f6"
                name="Phase B"
                strokeWidth={2}
                dot={false}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Energy Consumption */}
      <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
        <h4 className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-3">
          Energy Consumption (VAh)
        </h4>
        <div className="grid grid-cols-3 gap-4">
          {phases.map((phase) => {
            const value = data?.[`VAHR_${pumpNumber}_${phase}`] || 0;
            return (
              <div key={phase} className="text-center p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                <p className="text-xs text-gray-500 dark:text-gray-400 mb-1">
                  Phase {phase}
                </p>
                <p className="text-xl font-bold text-primary-600">
                  {value.toLocaleString()}
                </p>
                <p className="text-xs text-gray-500 dark:text-gray-400">VAh</p>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default PowerMetrics;

