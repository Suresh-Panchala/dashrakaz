import { motion } from 'framer-motion';
import { Power, ShieldAlert, Hand, Zap, Clock } from 'lucide-react';

const PumpStatus = ({ pumpNumber, data }) => {
  const isManual = data?.[`Pump_${pumpNumber}_Manual`] === 1;
  const isAuto = data?.[`Pump_${pumpNumber}_Auto`] === 1;
  const isProtection = data?.[`Pump_${pumpNumber}_Protection`] === 1;
  const contactorFeedback = data?.[`Pump_${pumpNumber}_Contactor_Feedback`] === 1;
  const rhs = data?.[`RHS_${pumpNumber}`];

  // Determine MODE: AUTO or MANUAL (only these two options)
  const mode = isAuto ? 'AUTO' : 'MANUAL';
  
  // Determine STATE: ON or OFF (based on contactor feedback)
  const state = contactorFeedback ? 'ON' : 'OFF';
  const isRunning = contactorFeedback;

  const getStatusStyle = () => {
    if (isProtection) return {
      gradient: 'from-red-500 to-red-700',
      bg: 'bg-red-50 dark:bg-red-950/30',
      text: 'text-red-700 dark:text-red-300',
      border: 'border-red-500',
      label: 'Protection Active',
      dotColor: 'bg-red-500',
      icon: ShieldAlert
    };
    if (isRunning) return {
      gradient: 'from-green-500 to-green-700',
      bg: 'bg-green-50 dark:bg-green-950/30',
      text: 'text-green-700 dark:text-green-300',
      border: 'border-green-500',
      label: 'Running',
      dotColor: 'bg-green-500',
      icon: Power
    };
    return {
      gradient: 'from-gray-500 to-gray-700',
      bg: 'bg-gray-50 dark:bg-gray-900/30',
      text: 'text-gray-700 dark:text-gray-300',
      border: 'border-gray-500',
      label: 'Stopped',
      dotColor: 'bg-gray-500',
      icon: Power
    };
  };

  const status = getStatusStyle();
  const StatusIcon = status.icon;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className={`card p-6 ${status.bg} border-l-4 ${status.border}`}
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <motion.div
            animate={isRunning ? {
              scale: [1, 1.1, 1],
              rotate: [0, 360]
            } : {}}
            transition={{
              duration: 2,
              repeat: isRunning ? Infinity : 0,
              ease: "linear"
            }}
            className={`p-3 rounded-xl bg-gradient-to-br ${status.gradient} shadow-lg`}
          >
            <StatusIcon className="w-6 h-6 text-white" />
          </motion.div>
          <div>
            <h3 className="text-lg font-black text-gray-900 dark:text-white">
              Pump {pumpNumber}
            </h3>
            <div className="flex items-center gap-2">
              <motion.div
                animate={isRunning ? { scale: [1, 1.3, 1] } : {}}
                transition={{ duration: 1, repeat: Infinity }}
                className={`w-2 h-2 rounded-full ${status.dotColor}`}
              />
              <p className={`text-sm font-bold ${status.text}`}>
                {status.label}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Mode & State */}
      <div className="grid grid-cols-2 gap-3 mb-6">
        {/* Mode: AUTO/MANUAL */}
        <div className={`card p-4 bg-gradient-to-br ${
          isAuto 
            ? 'from-blue-50 to-blue-100 dark:from-blue-950/30 dark:to-blue-900/20 border border-blue-200 dark:border-blue-800'
            : 'from-orange-50 to-orange-100 dark:from-orange-950/30 dark:to-orange-900/20 border border-orange-200 dark:border-orange-800'
        }`}>
          <div className="flex items-center gap-2 mb-2">
            {isAuto ? (
              <Zap className="w-5 h-5 text-blue-600 dark:text-blue-400" />
            ) : (
              <Hand className="w-5 h-5 text-orange-600 dark:text-orange-400" />
            )}
            <p className="text-xs font-bold text-gray-600 dark:text-gray-400 uppercase tracking-wide">
              Mode
            </p>
          </div>
          <p className={`text-3xl font-black ${
            isAuto 
              ? 'text-blue-700 dark:text-blue-300' 
              : 'text-orange-700 dark:text-orange-300'
          }`}>
            {mode}
          </p>
        </div>

        {/* State: ON/OFF */}
        <div className={`card p-4 bg-gradient-to-br ${
          state === 'ON' 
            ? 'from-green-50 to-green-100 dark:from-green-950/30 dark:to-green-900/20 border border-green-200 dark:border-green-800' 
            : 'from-gray-50 to-gray-100 dark:from-gray-900/30 dark:to-gray-800/20 border border-gray-200 dark:border-gray-700'
        }`}>
          <div className="flex items-center gap-2 mb-2">
            <Power className={`w-5 h-5 ${state === 'ON' ? 'text-green-600 dark:text-green-400' : 'text-gray-400'}`} />
            <p className="text-xs font-bold text-gray-600 dark:text-gray-400 uppercase tracking-wide">
              State
            </p>
          </div>
          <div className="flex items-center gap-2">
            <motion.div
              animate={state === 'ON' ? { scale: [1, 1.3, 1] } : {}}
              transition={{ duration: 1, repeat: Infinity }}
              className={`w-3 h-3 rounded-full ${state === 'ON' ? 'bg-green-500 shadow-lg shadow-green-500/50' : 'bg-gray-400'}`}
            />
            <p className={`text-3xl font-black ${
              state === 'ON' 
                ? 'text-green-700 dark:text-green-300' 
                : 'text-gray-500 dark:text-gray-400'
            }`}>
              {state}
            </p>
          </div>
        </div>
      </div>

      {/* Protection Alert */}
      {isProtection && (
        <motion.div
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          className="mb-6 p-3 bg-red-100 dark:bg-red-900/40 border-l-4 border-red-600 rounded-lg"
        >
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-red-600 dark:text-red-400" />
            <span className="text-sm font-bold text-red-700 dark:text-red-300">
              ⚠️ Protection Active
            </span>
          </div>
        </motion.div>
      )}

      {/* Power Metrics */}
      <div className="grid grid-cols-3 gap-3 mb-4">
        <div className="text-center">
          <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase mb-1">
            Voltage
          </p>
          <p className="text-2xl font-black text-gray-900 dark:text-white tabular-nums">
            {data?.[`VRMS_${pumpNumber}_R`] || 0}
          </p>
          <p className="text-xs font-bold text-gray-500 dark:text-gray-400">
            Volts
          </p>
        </div>
        <div className="text-center">
          <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase mb-1">
            Current
          </p>
          <p className="text-2xl font-black text-gray-900 dark:text-white tabular-nums">
            {data?.[`IRMS_${pumpNumber}_R`] || 0}
          </p>
          <p className="text-xs font-bold text-gray-500 dark:text-gray-400">
            Amps
          </p>
        </div>
        <div className="text-center">
          <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase mb-1">
            Freq
          </p>
          <p className="text-2xl font-black text-gray-900 dark:text-white tabular-nums">
            {data?.[`FREQ_${pumpNumber}_R`] || 0}
          </p>
          <p className="text-xs font-bold text-gray-500 dark:text-gray-400">
            Hz
          </p>
        </div>
      </div>

      {/* Total Running Hours */}
      <div className="pt-4 border-t-2 border-gray-200 dark:border-gray-700">
        <div className="flex items-center justify-between p-3 bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-950/30 dark:to-purple-950/30 rounded-lg border border-indigo-200 dark:border-indigo-800">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg shadow-lg">
              <Clock className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="text-xs font-bold text-gray-600 dark:text-gray-400 uppercase tracking-wide">
                Total Running Hours
              </p>
              <p className="text-xs text-gray-500 dark:text-gray-500">
                Cumulative runtime
              </p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-3xl font-black text-indigo-700 dark:text-indigo-300 tabular-nums">
              {rhs || 0}
            </p>
            <p className="text-xs font-bold text-indigo-600 dark:text-indigo-400">
              hours
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default PumpStatus;

