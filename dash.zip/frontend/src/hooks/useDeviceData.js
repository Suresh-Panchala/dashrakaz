import { useState, useEffect } from 'react';
import { devicesAPI } from '../services/api';
import socketService from '../services/socket';
import toast from 'react-hot-toast';

export const useDeviceData = (deviceId) => {
  const [latestData, setLatestData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!deviceId) return;

    let mounted = true;

    const fetchLatestData = async () => {
      try {
        setLoading(true);
        const response = await devicesAPI.getLatest(deviceId);
        if (mounted && response.data.success) {
          setLatestData(response.data.data);
          setError(null);
        }
      } catch (err) {
        if (mounted) {
          console.error('Error fetching device data:', err);
          setError(err.message);
          toast.error('Failed to fetch device data');
        }
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    };

    fetchLatestData();

    // Connect to socket for real-time updates
    socketService.connect();
    socketService.subscribe(deviceId);

    const handleDeviceData = (payload) => {
      if (payload.deviceId === deviceId) {
        setLatestData(payload.data);
      }
    };

    socketService.on('deviceData', handleDeviceData);

    // Cleanup
    return () => {
      mounted = false;
      socketService.unsubscribe(deviceId);
      socketService.off('deviceData', handleDeviceData);
    };
  }, [deviceId]);

  return { latestData, loading, error };
};

export const useDevices = () => {
  const [devices, setDevices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    let mounted = true;

    const fetchDevices = async () => {
      try {
        setLoading(true);
        const response = await devicesAPI.getAll();
        if (mounted && response.data.success) {
          setDevices(response.data.data);
          setError(null);
        }
      } catch (err) {
        if (mounted) {
          console.error('Error fetching devices:', err);
          setError(err.message);
          toast.error('Failed to fetch devices');
        }
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    };

    fetchDevices();

    // Listen for device status updates
    socketService.connect();
    
    const handleDeviceStatus = (payload) => {
      setDevices(prevDevices => 
        prevDevices.map(device => 
          device.deviceId === payload.deviceId 
            ? { ...device, status: payload.status, lastSeen: new Date() }
            : device
        )
      );
    };

    socketService.on('deviceStatus', handleDeviceStatus);

    return () => {
      mounted = false;
      socketService.off('deviceStatus', handleDeviceStatus);
    };
  }, []);

  const refetch = async () => {
    try {
      const response = await devicesAPI.getAll();
      if (response.data.success) {
        setDevices(response.data.data);
      }
    } catch (err) {
      console.error('Error refetching devices:', err);
    }
  };

  return { devices, loading, error, refetch };
};

