import { useState, useEffect } from 'react';
import { alertsAPI } from '../services/api';
import socketService from '../services/socket';
import toast from 'react-hot-toast';

export const useAlerts = (deviceId = null, autoRefresh = true) => {
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [stats, setStats] = useState(null);

  const fetchAlerts = async () => {
    try {
      setLoading(true);
      const params = { limit: 50, acknowledged: false };
      if (deviceId) params.deviceId = deviceId;

      const response = await alertsAPI.getAll(params);
      if (response.data.success) {
        setAlerts(response.data.data);
        setError(null);
      }
    } catch (err) {
      console.error('Error fetching alerts:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const params = {};
      if (deviceId) params.deviceId = deviceId;

      const response = await alertsAPI.getStats(params);
      if (response.data.success) {
        setStats(response.data.data);
      }
    } catch (err) {
      console.error('Error fetching alert stats:', err);
    }
  };

  useEffect(() => {
    fetchAlerts();
    fetchStats();

    if (autoRefresh) {
      // Connect to socket for real-time alert updates
      socketService.connect();

      const handleNewAlert = () => {
        fetchAlerts();
        fetchStats();
        toast.error('New alert received!', {
          icon: '🚨',
        });
      };

      socketService.on('newAlert', handleNewAlert);

      // Refresh every 30 seconds
      const interval = setInterval(() => {
        fetchAlerts();
        fetchStats();
      }, 30000);

      return () => {
        socketService.off('newAlert', handleNewAlert);
        clearInterval(interval);
      };
    }
  }, [deviceId, autoRefresh]);

  const acknowledgeAlert = async (alertId) => {
    try {
      const response = await alertsAPI.acknowledge(alertId);
      if (response.data.success) {
        setAlerts(prevAlerts => 
          prevAlerts.filter(alert => alert._id !== alertId)
        );
        toast.success('Alert acknowledged');
        fetchStats();
      }
    } catch (err) {
      toast.error('Failed to acknowledge alert');
      console.error('Error acknowledging alert:', err);
    }
  };

  return { 
    alerts, 
    stats,
    loading, 
    error, 
    refetch: fetchAlerts,
    acknowledgeAlert 
  };
};

