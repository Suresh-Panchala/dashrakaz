// API Service for Backend Communication

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

class APIService {
  constructor() {
    this.baseUrl = API_BASE_URL;
  }

  // Helper method for API calls
  async request(endpoint, options = {}) {
    const url = `${this.baseUrl}${endpoint}`;
    
    try {
      const response = await fetch(url, {
        ...options,
        headers: {
          'Content-Type': 'application/json',
          ...options.headers,
        },
      });

      if (!response.ok) {
        throw new Error(`API Error: ${response.statusText}`);
      }

      // Check if response is JSON
      const contentType = response.headers.get('content-type');
      if (contentType && contentType.includes('application/json')) {
        return await response.json();
      }

      return response;
    } catch (error) {
      console.error('API Request Error:', error);
      throw error;
    }
  }

  // Get latest data for a device
  async getLatestData(deviceId, limit = 1) {
    return this.request(`/data/latest/${deviceId}?limit=${limit}`);
  }

  // Get historical data with pagination
  async getHistoricalData(deviceId, page = 1, limit = 100, filters = {}) {
    let query = `/data/history/${deviceId}?page=${page}&limit=${limit}`;
    
    if (filters.startDate) {
      query += `&startDate=${filters.startDate}`;
    }
    if (filters.endDate) {
      query += `&endDate=${filters.endDate}`;
    }

    return this.request(query);
  }

  // Get statistics
  async getStatistics(deviceId, hours = 24) {
    return this.request(`/data/stats/${deviceId}?hours=${hours}`);
  }

  // Get data for specific date range
  async getDateRangeData(deviceId, startDate, endDate, interval = null) {
    let query = `/data/range/${deviceId}?startDate=${startDate}&endDate=${endDate}`;
    
    if (interval) {
      query += `&interval=${interval}`;
    }

    return this.request(query);
  }

  // Export data as CSV
  async exportCSV(deviceId, startDate = null, endDate = null) {
    let query = `/data/export/csv/${deviceId}`;
    const params = [];
    
    if (startDate) params.push(`startDate=${startDate}`);
    if (endDate) params.push(`endDate=${endDate}`);
    
    if (params.length > 0) {
      query += `?${params.join('&')}`;
    }

    const response = await fetch(`${this.baseUrl}${query}`);
    
    if (!response.ok) {
      throw new Error('Failed to export CSV');
    }

    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `stormwater_data_${deviceId}_${Date.now()}.csv`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  }

  // Export data as PDF
  async exportPDF(deviceId, startDate = null, endDate = null) {
    let query = `/data/export/pdf/${deviceId}`;
    const params = [];
    
    if (startDate) params.push(`startDate=${startDate}`);
    if (endDate) params.push(`endDate=${endDate}`);
    
    if (params.length > 0) {
      query += `?${params.join('&')}`;
    }

    const response = await fetch(`${this.baseUrl}${query}`);
    
    if (!response.ok) {
      throw new Error('Failed to export PDF');
    }

    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `stormwater_report_${deviceId}_${Date.now()}.pdf`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  }

  // Get all devices
  async getAllDevices() {
    return this.request('/data/devices');
  }

  // Get device info
  async getDeviceInfo(deviceId) {
    return this.request(`/data/device/${deviceId}`);
  }

  // Health check
  async healthCheck() {
    return this.request('/health');
  }
}

export default new APIService();

