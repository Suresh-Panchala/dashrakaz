import React, { createContext, useState, useContext, useEffect } from 'react';

const UserContext = createContext();

export const useUsers = () => {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error('useUsers must be used within a UserProvider');
  }
  return context;
};

export const UserProvider = ({ children }) => {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    // Load users from localStorage
    const savedUsers = localStorage.getItem('stormwater_users');
    if (savedUsers) {
      setUsers(JSON.parse(savedUsers));
    } else {
      // Initialize with default admin user
      const defaultUsers = [
        {
          id: '1',
          name: 'Admin User',
          email: 'admin@stormwater.com',
          role: 'admin',
          status: 'active',
          createdAt: new Date().toISOString(),
        }
      ];
      setUsers(defaultUsers);
      localStorage.setItem('stormwater_users', JSON.stringify(defaultUsers));
    }
  }, []);

  const addUser = (userData) => {
    const newUser = {
      id: Date.now().toString(),
      ...userData,
      status: 'active',
      createdAt: new Date().toISOString(),
    };
    const updatedUsers = [...users, newUser];
    setUsers(updatedUsers);
    localStorage.setItem('stormwater_users', JSON.stringify(updatedUsers));
    return newUser;
  };

  const updateUser = (userId, userData) => {
    const updatedUsers = users.map(user =>
      user.id === userId ? { ...user, ...userData } : user
    );
    setUsers(updatedUsers);
    localStorage.setItem('stormwater_users', JSON.stringify(updatedUsers));
  };

  const deleteUser = (userId) => {
    const updatedUsers = users.filter(user => user.id !== userId);
    setUsers(updatedUsers);
    localStorage.setItem('stormwater_users', JSON.stringify(updatedUsers));
  };

  const toggleUserStatus = (userId) => {
    const updatedUsers = users.map(user =>
      user.id === userId
        ? { ...user, status: user.status === 'active' ? 'inactive' : 'active' }
        : user
    );
    setUsers(updatedUsers);
    localStorage.setItem('stormwater_users', JSON.stringify(updatedUsers));
  };

  return (
    <UserContext.Provider value={{ users, addUser, updateUser, deleteUser, toggleUserStatus }}>
      {children}
    </UserContext.Provider>
  );
};
