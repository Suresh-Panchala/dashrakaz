import React, { createContext, useState, useContext, useEffect } from 'react';

const DeviceContext = createContext();

export const useDevices = () => {
  const context = useContext(DeviceContext);
  if (!context) {
    throw new Error('useDevices must be used within a DeviceProvider');
  }
  return context;
};

export const DeviceProvider = ({ children }) => {
  const [devices, setDevices] = useState([]);
  const [selectedDevice, setSelectedDevice] = useState(null);

  useEffect(() => {
    // Load devices from localStorage
    const savedDevices = localStorage.getItem('stormwater_devices');
    if (savedDevices) {
      const parsedDevices = JSON.parse(savedDevices);
      setDevices(parsedDevices);
      if (parsedDevices.length > 0) {
        setSelectedDevice(parsedDevices[0]);
      }
    } else {
      // Add default device
      const defaultDevice = {
        id: 'default-1',
        name: 'Khusam Station',
        deviceId: 'StromWater_Device_1',
        location: 'Khusam',
        topic: 'stromwater/khusam/device1/data',
        brokerUrl: 'ws://43.205.194.142/mqtt',
        mqttUsername: 'mqtt_user',
        mqttPassword: 'mqtt123',
        createdAt: new Date().toISOString(),
      };
      setDevices([defaultDevice]);
      setSelectedDevice(defaultDevice);
      localStorage.setItem('stormwater_devices', JSON.stringify([defaultDevice]));
    }
  }, []);

  const addDevice = (deviceData) => {
    const newDevice = {
      id: `device-${Date.now()}`,
      ...deviceData,
      createdAt: new Date().toISOString(),
    };
    const updatedDevices = [...devices, newDevice];
    setDevices(updatedDevices);
    localStorage.setItem('stormwater_devices', JSON.stringify(updatedDevices));
    return newDevice;
  };

  const updateDevice = (deviceId, updates) => {
    const updatedDevices = devices.map(device =>
      device.id === deviceId ? { ...device, ...updates } : device
    );
    setDevices(updatedDevices);
    localStorage.setItem('stormwater_devices', JSON.stringify(updatedDevices));

    if (selectedDevice?.id === deviceId) {
      setSelectedDevice({ ...selectedDevice, ...updates });
    }
  };

  const deleteDevice = (deviceId) => {
    const updatedDevices = devices.filter(device => device.id !== deviceId);
    setDevices(updatedDevices);
    localStorage.setItem('stormwater_devices', JSON.stringify(updatedDevices));

    if (selectedDevice?.id === deviceId) {
      setSelectedDevice(updatedDevices.length > 0 ? updatedDevices[0] : null);
    }
  };

  const selectDevice = (device) => {
    setSelectedDevice(device);
  };

  return (
    <DeviceContext.Provider
      value={{
        devices,
        selectedDevice,
        addDevice,
        updateDevice,
        deleteDevice,
        selectDevice
      }}
    >
      {children}
    </DeviceContext.Provider>
  );
};
