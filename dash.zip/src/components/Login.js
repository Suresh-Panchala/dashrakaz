import React, { useState } from 'react';
import './Login.css';

const Login = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    // Simulate API call delay
    setTimeout(() => {
      const result = onLogin(email, password);
      if (!result.success) {
        setError(result.error || 'Login failed');
      }
      setIsLoading(false);
    }, 800);
  };

  return (
    <div className="login-container">
      {/* Left Side - Login Form */}
      <div className="login-left">
        <div className="login-form-wrapper">
          <div className="login-header">
            <div className="logo-container">
              <svg width="50" height="50" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="25" cy="25" r="23" fill="url(#gradient)" opacity="0.2"/>
                <path d="M25 8C25 8 17 15 17 23C17 27.9706 20.5294 32 25 32C29.4706 32 33 27.9706 33 23C33 15 25 8 25 8Z"
                      fill="url(#gradient)" stroke="#667eea" strokeWidth="2"/>
                <circle cx="25" cy="38" r="2.5" fill="#667eea"/>
                <defs>
                  <linearGradient id="gradient" x1="25" y1="8" x2="25" y2="42" gradientUnits="userSpaceOnUse">
                    <stop stopColor="#667eea"/>
                    <stop offset="1" stopColor="#764ba2"/>
                  </linearGradient>
                </defs>
              </svg>
            </div>
            <h1>Welcome Back</h1>
            <p>Sign in to your account</p>
          </div>

          <form onSubmit={handleSubmit} className="login-form">
            <div className="form-group">
              <label htmlFor="email">Email Address</label>
              <div className="input-wrapper">
                <svg className="input-icon" width="20" height="20" viewBox="0 0 20 20" fill="none">
                  <path d="M3 6L10 11L17 6M3 6V14C3 14.5523 3.44772 15 4 15H16C16.5523 15 17 14.5523 17 14V6M3 6C3 5.44772 3.44772 5 4 5H16C16.5523 5 17 5.44772 17 6"
                        stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                </svg>
                <input
                  id="email"
                  type="email"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="form-group">
              <label htmlFor="password">Password</label>
              <div className="input-wrapper">
                <svg className="input-icon" width="20" height="20" viewBox="0 0 20 20" fill="none">
                  <rect x="5" y="9" width="10" height="7" rx="1" stroke="currentColor" strokeWidth="2"/>
                  <path d="M7 9V6C7 4.34315 8.34315 3 10 3C11.6569 3 13 4.34315 13 6V9"
                        stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                </svg>
                <input
                  id="password"
                  type="password"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
            </div>

            {error && (
              <div className="error-message">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                  <circle cx="8" cy="8" r="7" stroke="currentColor" strokeWidth="2"/>
                  <path d="M8 4V8M8 11H8.01" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                </svg>
                {error}
              </div>
            )}

            <button type="submit" className="login-button" disabled={isLoading}>
              {isLoading ? (
                <>
                  <span className="button-spinner"></span>
                  Signing in...
                </>
              ) : (
                'Sign In'
              )}
            </button>
          </form>

          <div className="login-footer">
            <p>© 2024 StormWater Monitoring System</p>
          </div>
        </div>
      </div>

      {/* Right Side - Animation */}
      <div className="login-right">
        <div className="animation-container">
          <div className="floating-circle circle-1"></div>
          <div className="floating-circle circle-2"></div>
          <div className="floating-circle circle-3"></div>
          
          <div className="content-wrapper">
            <div className="animated-logo">
              <svg width="120" height="120" viewBox="0 0 120 120" fill="none">
                <circle cx="60" cy="60" r="55" stroke="url(#grad1)" strokeWidth="3" opacity="0.3"/>
                <circle cx="60" cy="60" r="45" stroke="url(#grad1)" strokeWidth="3" opacity="0.5"/>
                <path className="water-drop" d="M60 25C60 25 40 40 40 55C40 66.0457 49.0457 75 60 75C70.9543 75 80 66.0457 80 55C80 40 60 25 60 25Z"
                      fill="url(#grad1)" stroke="white" strokeWidth="3"/>
                <circle className="ripple ripple-1" cx="60" cy="95" r="5" fill="white" opacity="0.8"/>
                <circle className="ripple ripple-2" cx="60" cy="95" r="5" fill="white" opacity="0.6"/>
                <circle className="ripple ripple-3" cx="60" cy="95" r="5" fill="white" opacity="0.4"/>
                <defs>
                  <linearGradient id="grad1" x1="60" y1="25" x2="60" y2="95">
                    <stop offset="0%" stopColor="#ffffff" stopOpacity="0.9"/>
                    <stop offset="100%" stopColor="#ffffff" stopOpacity="0.6"/>
                  </linearGradient>
                </defs>
              </svg>
            </div>
            
            <h2>StormWater Monitoring</h2>
            <p>Real-time monitoring and analytics for your storm water management system</p>
            
            <div className="features">
              <div className="feature-item">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                  <path d="M9 12L11 14L15 10M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z" 
                        stroke="white" strokeWidth="2" strokeLinecap="round"/>
                </svg>
                <span>Real-time Data Monitoring</span>
              </div>
              <div className="feature-item">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                  <path d="M9 19V6L3 8M9 19L15 21M9 19L15 17M15 8V17M15 8L21 6V17L15 17" 
                        stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
                <span>Historical Analytics</span>
              </div>
              <div className="feature-item">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                  <path d="M12 15V17M6 21H18C19.1046 21 20 20.1046 20 19V13C20 11.8954 19.1046 11 18 11H6C4.89543 11 4 11.8954 4 13V19C4 20.1046 4.89543 21 6 21ZM16 11V7C16 4.79086 14.2091 3 12 3C9.79086 3 8 4.79086 8 7V11H16Z" 
                        stroke="white" strokeWidth="2" strokeLinecap="round"/>
                </svg>
                <span>Secure & Reliable</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
