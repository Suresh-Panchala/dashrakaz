import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useDevices } from '../context/DeviceContext';
import { useTheme } from '../context/ThemeContext';
import DeviceManager from './DeviceManager';
import './TopBar.css';

const TopBar = ({ isConnected, currentView }) => {
  const { user, logout } = useAuth();
  const { selectedDevice, devices, selectDevice } = useDevices();
  const { theme, toggleTheme } = useTheme();
  const [showDeviceManager, setShowDeviceManager] = useState(false);
  const [showDeviceDropdown, setShowDeviceDropdown] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [currentDateTime, setCurrentDateTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentDateTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const viewTitles = {
    dashboard: 'Dashboard',
    reports: 'Reports',
    analytics: 'Analytics',
    devices: 'Devices',
    alerts: 'Alerts',
    users: 'Users',
    settings: 'Settings',
  };

  return (
    <>
      <header className="top-bar">
        <div className="top-bar-container">
          <div className="top-bar-left">
            <div className="breadcrumb">
              <span className="breadcrumb-home">Home</span>
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                <path d="M6 4L10 8L6 12" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <span className="breadcrumb-current">{viewTitles[currentView]}</span>
            </div>
            {selectedDevice && (
              <div className="device-selector-compact">
                <button
                  className="device-selector-btn"
                  onClick={() => setShowDeviceDropdown(!showDeviceDropdown)}
                >
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                    <rect x="3" y="2" width="10" height="12" rx="1.5" stroke="currentColor" strokeWidth="1.3"/>
                    <circle cx="8" cy="11" r="0.8" fill="currentColor"/>
                    <path d="M5 5H11" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/>
                  </svg>
                  <span>{selectedDevice.name}</span>
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                    <path d="M4 6L7 9L10 6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </button>

                {showDeviceDropdown && (
                  <div className="device-dropdown-compact">
                    {devices.map((device) => (
                      <button
                        key={device.id}
                        className={`device-dropdown-item-compact ${selectedDevice?.id === device.id ? 'active' : ''}`}
                        onClick={() => {
                          selectDevice(device);
                          setShowDeviceDropdown(false);
                        }}
                      >
                        <div className="device-info-dropdown">
                          <span className="device-name-dropdown">{device.name}</span>
                          <span className="device-location-dropdown">{device.location}</span>
                        </div>
                        {selectedDevice?.id === device.id && (
                          <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                            <path d="M3 7L6 10L11 3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                          </svg>
                        )}
                      </button>
                    ))}
                    <div className="dropdown-divider"></div>
                    <button
                      className="device-dropdown-item-compact manage"
                      onClick={() => {
                        setShowDeviceManager(true);
                        setShowDeviceDropdown(false);
                      }}
                    >
                      <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                        <path d="M7 3V11M3 7H11" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                      </svg>
                      Manage Devices
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="top-bar-right">
            <div className="datetime-display">
              <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                <circle cx="9" cy="9" r="7.5" stroke="currentColor" strokeWidth="1.3"/>
                <path d="M9 4.5V9L11.5 11.5" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/>
              </svg>
              <div className="datetime-text">
                <span className="datetime-combined">
                  {currentDateTime.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })} • {currentDateTime.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                </span>
              </div>
            </div>

            <button className="theme-toggle-btn" onClick={toggleTheme} title={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}>
              {theme === 'light' ? (
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                  <path d="M9 1.5V3M9 15V16.5M16.5 9H15M3 9H1.5M14.5 3.5L13.5 4.5M4.5 13.5L3.5 14.5M14.5 14.5L13.5 13.5M4.5 4.5L3.5 3.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                  <circle cx="9" cy="9" r="3.5" stroke="currentColor" strokeWidth="1.5"/>
                </svg>
              ) : (
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                  <path d="M16 10.5C15.2 11.5 13.8 12 12 12C8.7 12 6 9.3 6 6C6 4.2 6.5 2.8 7.5 2C4.5 2.5 2 5 2 8C2 11.3 4.7 14 8 14C11 14 13.5 11.5 16 10.5Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              )}
            </button>

            <div className="connection-status-compact">
              <div className={`status-dot-compact ${isConnected ? 'connected' : 'disconnected'}`}></div>
              <span className="status-text-compact">{isConnected ? 'Online' : 'Offline'}</span>
            </div>

            <button className="icon-btn-compact" onClick={() => setShowDeviceManager(true)}>
              <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                <rect x="2" y="3" width="14" height="12" rx="1.5" stroke="currentColor" strokeWidth="1.3"/>
                <path d="M6 7H12M6 10H9" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/>
              </svg>
            </button>

            <button className="icon-btn-compact">
              <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                <path d="M9 15C9.82843 15 10.5 14.3284 10.5 13.5C10.5 12.6716 9.82843 12 9 12C8.17157 12 7.5 12.6716 7.5 13.5C7.5 14.3284 8.17157 15 9 15Z" stroke="currentColor" strokeWidth="1.3"/>
                <path d="M9 3V11M9 11L13 7M9 11L5 7" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </button>

            <div className="user-menu-compact">
              <button
                className="user-avatar-compact"
                onClick={() => setShowUserMenu(!showUserMenu)}
              >
                <div className="avatar-circle-compact">
                  {user?.name?.charAt(0).toUpperCase() || 'U'}
                </div>
              </button>

              {showUserMenu && (
                <div className="user-dropdown-compact">
                  <div className="user-dropdown-header-compact">
                    <div className="avatar-circle-compact large">
                      {user?.name?.charAt(0).toUpperCase() || 'U'}
                    </div>
                    <div className="user-info-dropdown">
                      <span className="user-name-dropdown">{user?.name}</span>
                      <span className="user-email-dropdown">{user?.email}</span>
                    </div>
                  </div>
                  <div className="dropdown-divider"></div>
                  <button className="user-dropdown-item-compact" onClick={logout}>
                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                      <path d="M5 12H3C2.44772 12 2 11.5523 2 11V3C2 2.44772 2.44772 2 3 2H5M9 10L12 7M12 7L9 4M12 7H5"
                            stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                    Logout
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {showDeviceManager && <DeviceManager onClose={() => setShowDeviceManager(false)} />}
    </>
  );
};

export default TopBar;
