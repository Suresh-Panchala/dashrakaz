import React, { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { useTheme } from '../context/ThemeContext';
import { useDevice } from '../context/DeviceContext';
import apiService from '../services/api';
import './HistoricalData.css';

const HistoricalData = () => {
  const { theme } = useTheme();
  const { selectedDevice } = useDevice();
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [interval, setInterval] = useState('');
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState([]);
  const [stats, setStats] = useState(null);
  const [error, setError] = useState('');

  const chartColors = {
    grid: theme === 'dark' ? '#374151' : '#f0f0f0',
    axis: theme === 'dark' ? '#4b5563' : '#e5e7eb',
    text: theme === 'dark' ? '#9ca3af' : '#6b7280',
  };

  const fetchHistoricalData = async () => {
    if (!startDate || !endDate) {
      setError('Please select both start and end dates');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const deviceId = selectedDevice?.id || 'device1';
      
      // Fetch data
      const response = await apiService.getDateRangeData(
        deviceId,
        new Date(startDate).toISOString(),
        new Date(endDate).toISOString(),
        interval
      );

      if (response.success && response.data) {
        // Transform data for charts
        const transformedData = response.data.map(item => ({
          time: new Date(item.timestamp || item._id?.timestamp).toLocaleString(),
          VR: item.voltageR || item.avgVoltageR || 0,
          VY: item.voltageY || item.avgVoltageY || 0,
          VB: item.voltageB || item.avgVoltageB || 0,
          CR: item.currentR || item.avgCurrentR || 0,
          CY: item.currentY || item.avgCurrentY || 0,
          CB: item.currentB || item.avgCurrentB || 0,
          KW: item.kw || item.avgKW || 0,
          KVA: item.kva || item.avgKVA || 0,
          PF: item.powerFactor || item.avgPF || 0,
        }));

        setData(transformedData);

        // Calculate stats
        if (transformedData.length > 0) {
          const avgVR = (transformedData.reduce((sum, d) => sum + d.VR, 0) / transformedData.length).toFixed(2);
          const avgKW = (transformedData.reduce((sum, d) => sum + d.KW, 0) / transformedData.length).toFixed(2);
          const maxKW = Math.max(...transformedData.map(d => d.KW)).toFixed(2);
          const minKW = Math.min(...transformedData.map(d => d.KW)).toFixed(2);

          setStats({
            avgVR,
            avgKW,
            maxKW,
            minKW,
            totalRecords: transformedData.length
          });
        }
      } else {
        setError('No data found for the selected date range');
      }
    } catch (err) {
      console.error('Error fetching historical data:', err);
      setError('Failed to fetch historical data. Make sure the backend server is running.');
    } finally {
      setLoading(false);
    }
  };

  const handleExportCSV = async () => {
    try {
      const deviceId = selectedDevice?.id || 'device1';
      await apiService.exportCSV(
        deviceId,
        startDate ? new Date(startDate).toISOString() : null,
        endDate ? new Date(endDate).toISOString() : null
      );
    } catch (err) {
      console.error('Error exporting CSV:', err);
      alert('Failed to export CSV');
    }
  };

  const handleExportPDF = async () => {
    try {
      const deviceId = selectedDevice?.id || 'device1';
      await apiService.exportPDF(
        deviceId,
        startDate ? new Date(startDate).toISOString() : null,
        endDate ? new Date(endDate).toISOString() : null
      );
    } catch (err) {
      console.error('Error exporting PDF:', err);
      alert('Failed to export PDF');
    }
  };

  return (
    <div className="historical-data-container">
      <div className="historical-header">
        <h2>Historical Data Analysis</h2>
        <p>View and analyze historical sensor data from the database</p>
      </div>

      {/* Filters Section */}
      <div className="historical-filters">
        <div className="filter-group">
          <label>Start Date & Time</label>
          <input
            type="datetime-local"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
          />
        </div>

        <div className="filter-group">
          <label>End Date & Time</label>
          <input
            type="datetime-local"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
          />
        </div>

        <div className="filter-group">
          <label>Interval (Optional)</label>
          <select value={interval} onChange={(e) => setInterval(e.target.value)}>
            <option value="">No Aggregation</option>
            <option value="hour">Hourly Average</option>
            <option value="day">Daily Average</option>
            <option value="month">Monthly Average</option>
          </select>
        </div>

        <div className="filter-actions">
          <button onClick={fetchHistoricalData} disabled={loading} className="btn-primary">
            {loading ? 'Loading...' : 'Fetch Data'}
          </button>
        </div>
      </div>

      {error && (
        <div className="error-message">
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
            <circle cx="10" cy="10" r="9" stroke="currentColor" strokeWidth="2"/>
            <path d="M10 6V10M10 14H10.01" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
          </svg>
          {error}
        </div>
      )}

      {/* Statistics */}
      {stats && (
        <div className="stats-cards">
          <div className="stat-card">
            <div className="stat-label">Total Records</div>
            <div className="stat-value">{stats.totalRecords}</div>
          </div>
          <div className="stat-card">
            <div className="stat-label">Avg Voltage R</div>
            <div className="stat-value">{stats.avgVR} V</div>
          </div>
          <div className="stat-card">
            <div className="stat-label">Avg Power</div>
            <div className="stat-value">{stats.avgKW} KW</div>
          </div>
          <div className="stat-card">
            <div className="stat-label">Max Power</div>
            <div className="stat-value">{stats.maxKW} KW</div>
          </div>
          <div className="stat-card">
            <div className="stat-label">Min Power</div>
            <div className="stat-value">{stats.minKW} KW</div>
          </div>
        </div>
      )}

      {/* Export Buttons */}
      {data.length > 0 && (
        <div className="export-actions">
          <button onClick={handleExportCSV} className="btn-export">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
              <path d="M6 2H14L18 6V18H2V2H6Z" stroke="currentColor" strokeWidth="2"/>
              <path d="M6 10H14M6 14H14" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
            </svg>
            Export CSV
          </button>
          <button onClick={handleExportPDF} className="btn-export">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
              <path d="M6 2H14L18 6V18H2V2H6Z" stroke="currentColor" strokeWidth="2"/>
              <circle cx="10" cy="12" r="3" stroke="currentColor" strokeWidth="2"/>
            </svg>
            Export PDF
          </button>
        </div>
      )}

      {/* Charts */}
      {data.length > 0 && (
        <div className="charts-section">
          {/* Voltage Chart */}
          <div className="chart-box">
            <h3>Voltage (V)</h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" stroke={chartColors.grid} />
                <XAxis 
                  dataKey="time" 
                  tick={{ fontSize: 11, fill: chartColors.text }}
                  tickLine={false}
                  axisLine={{ stroke: chartColors.axis }}
                />
                <YAxis 
                  tick={{ fontSize: 11, fill: chartColors.text }}
                  tickLine={false}
                  axisLine={{ stroke: chartColors.axis }}
                />
                <Tooltip contentStyle={{ backgroundColor: theme === 'dark' ? '#1f2937' : '#fff' }} />
                <Legend />
                <Line type="monotone" dataKey="VR" stroke="#ef4444" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="VY" stroke="#eab308" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="VB" stroke="#3b82f6" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Current Chart */}
          <div className="chart-box">
            <h3>Current (A)</h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" stroke={chartColors.grid} />
                <XAxis 
                  dataKey="time" 
                  tick={{ fontSize: 11, fill: chartColors.text }}
                  tickLine={false}
                  axisLine={{ stroke: chartColors.axis }}
                />
                <YAxis 
                  tick={{ fontSize: 11, fill: chartColors.text }}
                  tickLine={false}
                  axisLine={{ stroke: chartColors.axis }}
                />
                <Tooltip contentStyle={{ backgroundColor: theme === 'dark' ? '#1f2937' : '#fff' }} />
                <Legend />
                <Line type="monotone" dataKey="CR" stroke="#ef4444" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="CY" stroke="#eab308" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="CB" stroke="#3b82f6" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Power Chart */}
          <div className="chart-box">
            <h3>Power</h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" stroke={chartColors.grid} />
                <XAxis 
                  dataKey="time" 
                  tick={{ fontSize: 11, fill: chartColors.text }}
                  tickLine={false}
                  axisLine={{ stroke: chartColors.axis }}
                />
                <YAxis 
                  tick={{ fontSize: 11, fill: chartColors.text }}
                  tickLine={false}
                  axisLine={{ stroke: chartColors.axis }}
                />
                <Tooltip contentStyle={{ backgroundColor: theme === 'dark' ? '#1f2937' : '#fff' }} />
                <Legend />
                <Line type="monotone" dataKey="KW" stroke="#10b981" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="KVA" stroke="#8b5cf6" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="PF" stroke="#f59e0b" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {loading && (
        <div className="loading-state">
          <div className="spinner"></div>
          <p>Loading historical data...</p>
        </div>
      )}
    </div>
  );
};

export default HistoricalData;

