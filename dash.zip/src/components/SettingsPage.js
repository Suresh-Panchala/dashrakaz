import React from 'react';
import { useTheme } from '../context/ThemeContext';
import { useAuth } from '../context/AuthContext';
import './SettingsPage.css';

const SettingsPage = () => {
  const { theme, toggleTheme } = useTheme();
  const { user } = useAuth();

  return (
    <div className="settings-page">
      <div className="settings-header">
        <h2>Settings</h2>
        <p className="settings-subtitle">Manage your application preferences and configurations</p>
      </div>

      <div className="settings-content">
        {/* Appearance Section */}
        <div className="settings-section">
          <div className="section-header">
            <div className="section-icon appearance">
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                <path d="M10 2V4M10 16V18M4 10H2M18 10H16M15.657 15.657L14.243 14.243M15.657 4.343L14.243 5.757M4.343 15.657L5.757 14.243M4.343 4.343L5.757 5.757" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                <circle cx="10" cy="10" r="4" stroke="currentColor" strokeWidth="1.5"/>
              </svg>
            </div>
            <div>
              <h3>Appearance</h3>
              <p>Customize the look and feel of your dashboard</p>
            </div>
          </div>

          <div className="setting-item">
            <div className="setting-info">
              <label>Theme</label>
              <span className="setting-description">Choose between light and dark theme</span>
            </div>
            <button className="theme-toggle" onClick={toggleTheme}>
              <div className={`toggle-track ${theme}`}>
                <div className="toggle-thumb">
                  {theme === 'light' ? (
                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                      <circle cx="7" cy="7" r="3" stroke="currentColor" strokeWidth="1.5"/>
                      <path d="M7 1V2M7 12V13M2 7H1M13 7H12M11.071 11.071L10.364 10.364M11.071 2.929L10.364 3.636M2.929 11.071L3.636 10.364M2.929 2.929L3.636 3.636" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                    </svg>
                  ) : (
                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                      <path d="M7 1C4.23858 1 2 3.23858 2 6C2 8.76142 4.23858 11 7 11C9.76142 11 12 8.76142 12 6C12 5.21207 11.8126 4.46789 11.4793 3.80861C10.8293 4.07654 10.1158 4.22222 9.37037 4.22222C6.93502 4.22222 4.96296 2.24142 4.96296 0C3.21207 0.791667 2 2.77083 2 5C2 7.76142 4.23858 10 7 10C9.76142 10 12 7.76142 12 5C12 3.89543 11.5786 2.89543 10.8943 2.10861" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                    </svg>
                  )}
                </div>
              </div>
              <span className="toggle-label">{theme === 'light' ? 'Light' : 'Dark'}</span>
            </button>
          </div>
        </div>

        {/* Profile Section */}
        <div className="settings-section">
          <div className="section-header">
            <div className="section-icon profile">
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                <circle cx="10" cy="7" r="3" stroke="currentColor" strokeWidth="1.5"/>
                <path d="M4 17C4 13.6863 6.68629 11 10 11C13.3137 11 16 13.6863 16 17" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
              </svg>
            </div>
            <div>
              <h3>Profile Information</h3>
              <p>Your account details</p>
            </div>
          </div>

          <div className="profile-info">
            <div className="profile-item">
              <span className="profile-label">Name</span>
              <span className="profile-value">{user?.name || 'N/A'}</span>
            </div>
            <div className="profile-item">
              <span className="profile-label">Email</span>
              <span className="profile-value">{user?.email || 'N/A'}</span>
            </div>
            <div className="profile-item">
              <span className="profile-label">Role</span>
              <span className={`role-badge-settings ${user?.role}`}>
                {user?.role === 'admin' ? 'Administrator' : 'User'}
              </span>
            </div>
          </div>
        </div>

        {/* System Information */}
        <div className="settings-section">
          <div className="section-header">
            <div className="section-icon system">
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                <rect x="3" y="3" width="14" height="14" rx="2" stroke="currentColor" strokeWidth="1.5"/>
                <path d="M7 7H13M7 10H11" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
              </svg>
            </div>
            <div>
              <h3>System Information</h3>
              <p>Application details</p>
            </div>
          </div>

          <div className="system-info">
            <div className="info-item">
              <span className="info-label">Version</span>
              <span className="info-value">1.0.0</span>
            </div>
            <div className="info-item">
              <span className="info-label">Platform</span>
              <span className="info-value">StormWater Monitoring</span>
            </div>
            <div className="info-item">
              <span className="info-label">Build</span>
              <span className="info-value">2025.01</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;
