import React from 'react';
import './ParameterCard.css';

const ParameterCard = ({ title, value, unit, icon, color = 'blue', phase, pump }) => {
  const colorClasses = {
    blue: 'param-card-blue',
    green: 'param-card-green',
    orange: 'param-card-orange',
    red: 'param-card-red',
    purple: 'param-card-purple',
    yellow: 'param-card-yellow',
  };

  const getPhaseColor = (phase) => {
    if (phase === 'R') return '#ef4444';
    if (phase === 'Y') return '#f59e0b';
    if (phase === 'B') return '#3b82f6';
    return '#6b7280';
  };

  return (
    <div className={`parameter-card ${colorClasses[color]}`}>
      {phase && (
        <div className="phase-indicator" style={{ backgroundColor: getPhaseColor(phase) }}>
          {phase}
        </div>
      )}
      <div className="parameter-card-content">
        <div className="parameter-info">
          <div className="parameter-title">{title}</div>
          <div className="parameter-value-row">
            <span className="parameter-value">
              {typeof value === 'number' ? Math.round(value) : value}
            </span>
            <span className="parameter-unit">{unit}</span>
          </div>
          {pump && (
            <div className="parameter-meta">
              <span className="parameter-pump">Pump {pump}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ParameterCard;
