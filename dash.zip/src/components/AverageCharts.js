import React, { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { useTheme } from '../context/ThemeContext';
import './AverageCharts.css';

const AverageCharts = ({ message }) => {
  const { theme } = useTheme();
  const [voltageData, setVoltageData] = useState([]);
  const [currentData, setCurrentData] = useState([]);
  const [powerData, setPowerData] = useState([]);
  const maxDataPoints = 20;

  // Theme-aware colors
  const chartColors = {
    grid: theme === 'dark' ? '#374151' : '#f0f0f0',
    axis: theme === 'dark' ? '#4b5563' : '#e5e7eb',
    text: theme === 'dark' ? '#9ca3af' : '#6b7280',
  };

  useEffect(() => {
    if (!message || !message.data) return;

    const timestamp = new Date().toLocaleTimeString();

    // Calculate averages for each parameter
    const avgVoltage = (
      (message.data.VRMS_1_R || 0) +
      (message.data.VRMS_1_Y || 0) +
      (message.data.VRMS_1_B || 0) +
      (message.data.VRMS_2_R || 0) +
      (message.data.VRMS_2_Y || 0) +
      (message.data.VRMS_2_B || 0)
    ) / 6;

    const avgCurrent = (
      (message.data.IRMS_1_R || 0) +
      (message.data.IRMS_1_Y || 0) +
      (message.data.IRMS_1_B || 0) +
      (message.data.IRMS_2_R || 0) +
      (message.data.IRMS_2_Y || 0) +
      (message.data.IRMS_2_B || 0)
    ) / 6;

    const avgPower = (
      (message.data.POWER_1_R || 0) +
      (message.data.POWER_1_Y || 0) +
      (message.data.POWER_1_B || 0) +
      (message.data.POWER_2_R || 0) +
      (message.data.POWER_2_Y || 0) +
      (message.data.POWER_2_B || 0)
    ) / 6;

    // Update voltage data
    setVoltageData(prev => {
      const newData = [...prev, {
        time: timestamp,
        pump1: ((message.data.VRMS_1_R || 0) + (message.data.VRMS_1_Y || 0) + (message.data.VRMS_1_B || 0)) / 3,
        pump2: ((message.data.VRMS_2_R || 0) + (message.data.VRMS_2_Y || 0) + (message.data.VRMS_2_B || 0)) / 3,
        average: avgVoltage,
      }];
      return newData.slice(-maxDataPoints);
    });

    // Update current data
    setCurrentData(prev => {
      const newData = [...prev, {
        time: timestamp,
        pump1: ((message.data.IRMS_1_R || 0) + (message.data.IRMS_1_Y || 0) + (message.data.IRMS_1_B || 0)) / 3,
        pump2: ((message.data.IRMS_2_R || 0) + (message.data.IRMS_2_Y || 0) + (message.data.IRMS_2_B || 0)) / 3,
        average: avgCurrent,
      }];
      return newData.slice(-maxDataPoints);
    });

    // Update power data
    setPowerData(prev => {
      const newData = [...prev, {
        time: timestamp,
        pump1: ((message.data.POWER_1_R || 0) + (message.data.POWER_1_Y || 0) + (message.data.POWER_1_B || 0)) / 3,
        pump2: ((message.data.POWER_2_R || 0) + (message.data.POWER_2_Y || 0) + (message.data.POWER_2_B || 0)) / 3,
        average: avgPower,
      }];
      return newData.slice(-maxDataPoints);
    });
  }, [message]);

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="custom-tooltip">
          <p className="tooltip-label">{label}</p>
          {payload.map((entry, index) => (
            <p key={index} style={{ color: entry.color, margin: '4px 0' }}>
              <strong>{entry.name}:</strong> {entry.value.toFixed(2)}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  if (!message || !message.data) {
    return (
      <div className="charts-container">
        <div className="charts-header">
          <h3>Average Trends</h3>
          <p className="charts-subtitle">Real-time average values across all phases</p>
        </div>
        <div className="no-chart-data">
          <svg width="60" height="60" viewBox="0 0 60 60" fill="none">
            <path d="M10 50V30M25 50V20M40 50V10" stroke="#d1d5db" strokeWidth="3" strokeLinecap="round"/>
          </svg>
          <p>Waiting for data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="charts-container">
      <div className="charts-header">
        <h3>Average Trends</h3>
        <p className="charts-subtitle">Real-time average values across all phases</p>
      </div>

      <div className="charts-grid">
        {/* Voltage Chart */}
        <div className="chart-card">
          <div className="chart-card-header">
            <div className="chart-icon voltage">
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                <path d="M10 2L3 10H10L9 18L17 10H10L10 2Z" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <div>
              <h4>Average Voltage</h4>
              <p className="chart-subtitle">Volts (V)</p>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={voltageData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke={chartColors.grid} />
              <XAxis
                dataKey="time"
                tick={{ fontSize: 11, fill: chartColors.text }}
                tickLine={false}
                axisLine={{ stroke: chartColors.axis }}
              />
              <YAxis
                tick={{ fontSize: 11, fill: chartColors.text }}
                tickLine={false}
                axisLine={{ stroke: chartColors.axis }}
                domain={['auto', 'auto']}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend
                wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }}
                iconType="line"
              />
              <Line
                type="monotone"
                dataKey="pump1"
                stroke="#ef4444"
                strokeWidth={2}
                name="Pump 1"
                dot={false}
                activeDot={{ r: 4 }}
              />
              <Line
                type="monotone"
                dataKey="pump2"
                stroke="#3b82f6"
                strokeWidth={2}
                name="Pump 2"
                dot={false}
                activeDot={{ r: 4 }}
              />
              <Line
                type="monotone"
                dataKey="average"
                stroke="#10b981"
                strokeWidth={2}
                strokeDasharray="5 5"
                name="Average"
                dot={false}
                activeDot={{ r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Current Chart */}
        <div className="chart-card">
          <div className="chart-card-header">
            <div className="chart-icon current">
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                <circle cx="10" cy="10" r="7" stroke="white" strokeWidth="1.5"/>
                <path d="M10 6V10L13 13" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
              </svg>
            </div>
            <div>
              <h4>Average Current</h4>
              <p className="chart-subtitle">Amperes (A)</p>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={currentData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke={chartColors.grid} />
              <XAxis
                dataKey="time"
                tick={{ fontSize: 11, fill: chartColors.text }}
                tickLine={false}
                axisLine={{ stroke: chartColors.axis }}
              />
              <YAxis
                tick={{ fontSize: 11, fill: chartColors.text }}
                tickLine={false}
                axisLine={{ stroke: chartColors.axis }}
                domain={['auto', 'auto']}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend
                wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }}
                iconType="line"
              />
              <Line
                type="monotone"
                dataKey="pump1"
                stroke="#ef4444"
                strokeWidth={2}
                name="Pump 1"
                dot={false}
                activeDot={{ r: 4 }}
              />
              <Line
                type="monotone"
                dataKey="pump2"
                stroke="#3b82f6"
                strokeWidth={2}
                name="Pump 2"
                dot={false}
                activeDot={{ r: 4 }}
              />
              <Line
                type="monotone"
                dataKey="average"
                stroke="#10b981"
                strokeWidth={2}
                strokeDasharray="5 5"
                name="Average"
                dot={false}
                activeDot={{ r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Power Chart */}
        <div className="chart-card">
          <div className="chart-card-header">
            <div className="chart-icon power">
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                <path d="M3 10H7L10 3L13 17L16 10H17" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <div>
              <h4>Average Power</h4>
              <p className="chart-subtitle">Watts (W)</p>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={powerData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke={chartColors.grid} />
              <XAxis
                dataKey="time"
                tick={{ fontSize: 11, fill: chartColors.text }}
                tickLine={false}
                axisLine={{ stroke: chartColors.axis }}
              />
              <YAxis
                tick={{ fontSize: 11, fill: chartColors.text }}
                tickLine={false}
                axisLine={{ stroke: chartColors.axis }}
                domain={['auto', 'auto']}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend
                wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }}
                iconType="line"
              />
              <Line
                type="monotone"
                dataKey="pump1"
                stroke="#ef4444"
                strokeWidth={2}
                name="Pump 1"
                dot={false}
                activeDot={{ r: 4 }}
              />
              <Line
                type="monotone"
                dataKey="pump2"
                stroke="#3b82f6"
                strokeWidth={2}
                name="Pump 2"
                dot={false}
                activeDot={{ r: 4 }}
              />
              <Line
                type="monotone"
                dataKey="average"
                stroke="#10b981"
                strokeWidth={2}
                strokeDasharray="5 5"
                name="Average"
                dot={false}
                activeDot={{ r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default AverageCharts;
