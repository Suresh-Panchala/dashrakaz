import React, { useState } from 'react';
import { useDevices } from '../context/DeviceContext';
import { useAuth } from '../context/AuthContext';
import './DeviceManager.css';

const DeviceManager = ({ onClose }) => {
  const { user } = useAuth();
  const { devices, addDevice, deleteDevice, selectDevice, selectedDevice } = useDevices();
  const isAdmin = user?.role === 'admin';
  const [showAddForm, setShowAddForm] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    deviceId: '',
    location: '',
    topic: '',
    brokerUrl: 'wss://broker.hivemq.com:8884/mqtt',
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    addDevice(formData);
    setFormData({
      name: '',
      deviceId: '',
      location: '',
      topic: '',
      brokerUrl: 'wss://broker.hivemq.com:8884/mqtt',
    });
    setShowAddForm(false);
  };

  const handleDelete = (deviceId) => {
    if (window.confirm('Are you sure you want to delete this device?')) {
      deleteDevice(deviceId);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <div>
            <h2>Device Management</h2>
            <p style={{ margin: '4px 0 0 0', fontSize: '13px', color: '#6b7280' }}>
              {isAdmin
                ? 'Manage and configure your connected devices'
                : 'View devices (Admin access required to add/edit)'}
            </p>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            {!isAdmin && (
              <div style={{
                padding: '4px 12px',
                background: '#fef3c7',
                color: '#92400e',
                borderRadius: '6px',
                fontSize: '11px',
                fontWeight: '600',
                display: 'flex',
                alignItems: 'center',
                gap: '6px'
              }}>
                <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                  <circle cx="6" cy="4" r="2" stroke="currentColor" strokeWidth="1.2"/>
                  <path d="M2 10C2 8.34315 4.68629 7 6 7C7.31371 7 10 8.34315 10 10" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"/>
                </svg>
                User Access
              </div>
            )}
            <button className="close-button" onClick={onClose}>
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
              </svg>
            </button>
          </div>
        </div>

        <div className="modal-body">
          <div className="devices-list">
            {devices.map((device) => (
              <div
                key={device.id}
                className={`device-card ${selectedDevice?.id === device.id ? 'selected' : ''}`}
              >
                <div className="device-info" onClick={() => selectDevice(device)}>
                  <div className="device-header">
                    <h3>{device.name}</h3>
                    <span className="device-badge">{device.location}</span>
                  </div>
                  <p className="device-id">ID: {device.deviceId}</p>
                  <p className="device-topic">Topic: {device.topic}</p>
                </div>
                {isAdmin && (
                  <button
                    className="delete-button"
                    onClick={() => handleDelete(device.id)}
                    disabled={devices.length === 1}
                  >
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                      <path d="M7 4V3C7 2.44772 7.44772 2 8 2H12C12.5523 2 13 2.44772 13 3V4M4 4H16M15 4V15C15 15.5523 14.5523 16 14 16H6C5.44772 16 5 15.5523 5 15V4"
                            stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                    </svg>
                  </button>
                )}
              </div>
            ))}
          </div>

          {isAdmin && !showAddForm ? (
            <button className="add-device-button" onClick={() => setShowAddForm(true)}>
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                <path d="M10 5V15M5 10H15" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
              </svg>
              Add New Device
            </button>
          ) : isAdmin && showAddForm ? (
            <form onSubmit={handleSubmit} className="add-device-form">
              <h3>Add New Device</h3>

              <div className="form-row">
                <div className="form-field">
                  <label>Device Name</label>
                  <input
                    type="text"
                    name="name"
                    placeholder="e.g., Khusam Station"
                    value={formData.name}
                    onChange={handleInputChange}
                    required
                  />
                </div>

                <div className="form-field">
                  <label>Location</label>
                  <input
                    type="text"
                    name="location"
                    placeholder="e.g., Khusam"
                    value={formData.location}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </div>

              <div className="form-field">
                <label>Device ID</label>
                <input
                  type="text"
                  name="deviceId"
                  placeholder="e.g., StromWater_Device_1"
                  value={formData.deviceId}
                  onChange={handleInputChange}
                  required
                />
              </div>

              <div className="form-field">
                <label>MQTT Topic</label>
                <input
                  type="text"
                  name="topic"
                  placeholder="e.g., stromwater/khusam/device1/data"
                  value={formData.topic}
                  onChange={handleInputChange}
                  required
                />
              </div>

              <div className="form-field">
                <label>Broker URL</label>
                <input
                  type="text"
                  name="brokerUrl"
                  placeholder="wss://broker.hivemq.com:8884/mqtt"
                  value={formData.brokerUrl}
                  onChange={handleInputChange}
                  required
                />
              </div>

              <div className="form-actions">
                <button type="button" className="cancel-button" onClick={() => setShowAddForm(false)}>
                  Cancel
                </button>
                <button type="submit" className="submit-button">
                  Add Device
                </button>
              </div>
            </form>
          ) : null}
        </div>
      </div>
    </div>
  );
};

export default DeviceManager;
