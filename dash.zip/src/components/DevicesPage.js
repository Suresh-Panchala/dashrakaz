import React, { useState } from 'react';
import { useDevices } from '../context/DeviceContext';
import { useAuth } from '../context/AuthContext';
import './DevicesPage.css';

const DevicesPage = () => {
  const { user } = useAuth();
  const { devices, selectedDevice, addDevice, updateDevice, deleteDevice, selectDevice } = useDevices();
  const [isAddingDevice, setIsAddingDevice] = useState(false);
  const [editingDevice, setEditingDevice] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    deviceId: '',
    location: '',
    topic: '',
    brokerUrl: 'wss://broker.hivemq.com:8884/mqtt',
  });

  const isAdmin = user?.role === 'admin';

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingDevice) {
      updateDevice(editingDevice.id, formData);
      setEditingDevice(null);
    } else {
      addDevice(formData);
      setIsAddingDevice(false);
    }
    setFormData({
      name: '',
      deviceId: '',
      location: '',
      topic: '',
      brokerUrl: 'wss://broker.hivemq.com:8884/mqtt',
    });
  };

  const handleEdit = (device) => {
    setEditingDevice(device);
    setFormData({
      name: device.name,
      deviceId: device.deviceId,
      location: device.location,
      topic: device.topic,
      brokerUrl: device.brokerUrl,
    });
    setIsAddingDevice(true);
  };

  const handleCancel = () => {
    setIsAddingDevice(false);
    setEditingDevice(null);
    setFormData({
      name: '',
      deviceId: '',
      location: '',
      topic: '',
      brokerUrl: 'wss://broker.hivemq.com:8884/mqtt',
    });
  };

  const handleDelete = (deviceId) => {
    if (window.confirm('Are you sure you want to delete this device?')) {
      deleteDevice(deviceId);
    }
  };

  return (
    <div className="devices-page">
      <div className="devices-page-header">
        <div>
          <h2>Device Management</h2>
          <p className="devices-subtitle">
            {isAdmin
              ? 'Manage and configure your connected IoT devices'
              : 'View your connected IoT devices (Admin access required to add/edit devices)'
            }
          </p>
        </div>
        <div className="header-actions">
          {!isAdmin && (
            <div className="role-badge-page user">
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                <circle cx="7" cy="5" r="2.5" stroke="currentColor" strokeWidth="1.5"/>
                <path d="M2 12C2 9.79086 4.68629 8 7 8C9.31371 8 12 9.79086 12 12" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
              </svg>
              User Access
            </div>
          )}
          {isAdmin && !isAddingDevice && (
            <button className="btn-add-device" onClick={() => setIsAddingDevice(true)}>
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                <path d="M8 3V13M3 8H13" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
              </svg>
              Add Device
            </button>
          )}
        </div>
      </div>

      {isAddingDevice && (
        <div className="device-form-section">
          <div className="form-header">
            <h3>{editingDevice ? 'Edit Device' : 'Add New Device'}</h3>
            <p>Fill in the device information below</p>
          </div>
          <form onSubmit={handleSubmit} className="device-form">
            <div className="form-grid">
              <div className="form-field">
                <label htmlFor="name">Device Name *</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  placeholder="e.g., Khusam Station"
                  required
                />
              </div>

              <div className="form-field">
                <label htmlFor="location">Location *</label>
                <input
                  type="text"
                  id="location"
                  name="location"
                  value={formData.location}
                  onChange={handleInputChange}
                  placeholder="e.g., Khusam"
                  required
                />
              </div>

              <div className="form-field">
                <label htmlFor="deviceId">Device ID *</label>
                <input
                  type="text"
                  id="deviceId"
                  name="deviceId"
                  value={formData.deviceId}
                  onChange={handleInputChange}
                  placeholder="e.g., StormWater_Device_1"
                  required
                />
              </div>

              <div className="form-field">
                <label htmlFor="topic">MQTT Topic *</label>
                <input
                  type="text"
                  id="topic"
                  name="topic"
                  value={formData.topic}
                  onChange={handleInputChange}
                  placeholder="e.g., stromwater/khusam/device1/data"
                  required
                />
              </div>

              <div className="form-field full-width">
                <label htmlFor="brokerUrl">Broker URL *</label>
                <input
                  type="text"
                  id="brokerUrl"
                  name="brokerUrl"
                  value={formData.brokerUrl}
                  onChange={handleInputChange}
                  placeholder="wss://broker.hivemq.com:8884/mqtt"
                  required
                />
              </div>
            </div>

            <div className="form-actions">
              <button type="button" className="btn-cancel" onClick={handleCancel}>
                Cancel
              </button>
              <button type="submit" className="btn-submit">
                {editingDevice ? 'Update Device' : 'Add Device'}
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="devices-grid-page">
        {devices.length === 0 ? (
          <div className="no-devices-page">
            <svg width="80" height="80" viewBox="0 0 80 80" fill="none">
              <rect x="20" y="10" width="40" height="60" rx="6" stroke="#d1d5db" strokeWidth="2"/>
              <circle cx="40" cy="58" r="4" fill="#d1d5db"/>
              <path d="M30 24H50M30 34H50" stroke="#d1d5db" strokeWidth="2" strokeLinecap="round"/>
            </svg>
            <h3>No Devices Configured</h3>
            <p>{isAdmin ? 'Click "Add Device" to get started' : 'Contact your administrator to add devices'}</p>
          </div>
        ) : (
          devices.map(device => (
            <div
              key={device.id}
              className={`device-card-page ${selectedDevice?.id === device.id ? 'selected' : ''}`}
            >
              <div className="device-card-header-page">
                <div className="device-icon-page">
                  <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
                    <rect x="7" y="3" width="14" height="22" rx="2" stroke="currentColor" strokeWidth="2"/>
                    <circle cx="14" cy="20" r="1.5" fill="currentColor"/>
                    <path d="M10 8H18M10 12H18" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
                  </svg>
                </div>
                <div className="device-info-page">
                  <h3>{device.name}</h3>
                  <span className="device-location-badge">{device.location}</span>
                </div>
                {selectedDevice?.id === device.id && (
                  <div className="active-badge-page">
                    <div className="active-dot"></div>
                    Active
                  </div>
                )}
              </div>

              <div className="device-details-page">
                <div className="detail-item">
                  <span className="detail-label">Device ID</span>
                  <span className="detail-value">{device.deviceId}</span>
                </div>
                <div className="detail-item">
                  <span className="detail-label">Broker</span>
                  <span className="detail-value">{device.brokerUrl}</span>
                </div>
                <div className="detail-item">
                  <span className="detail-label">Topic</span>
                  <span className="detail-value topic-value">{device.topic}</span>
                </div>
              </div>

              <div className="device-actions-page">
                <button
                  className={`btn-select-page ${selectedDevice?.id === device.id ? 'selected' : ''}`}
                  onClick={() => selectDevice(device.id)}
                  disabled={selectedDevice?.id === device.id}
                >
                  {selectedDevice?.id === device.id ? (
                    <>
                      <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                        <path d="M3 7L6 10L11 3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                      Selected
                    </>
                  ) : (
                    'Select Device'
                  )}
                </button>
                {isAdmin && (
                  <div className="admin-actions">
                    <button className="btn-icon-action" onClick={() => handleEdit(device)} title="Edit">
                      <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                        <path d="M11.5 2L14 4.5L6 12.5H3.5V10L11.5 2Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    </button>
                    <button className="btn-icon-action danger" onClick={() => handleDelete(device.id)} title="Delete">
                      <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                        <path d="M3 4H13M5 4V3C5 2.44772 5.44772 2 6 2H10C10.5523 2 11 2.44772 11 3V4M6.5 7V11M9.5 7V11M4 4H12V13C12 13.5523 11.5523 14 11 14H5C4.44772 14 4 13.5523 4 13V4Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default DevicesPage;
