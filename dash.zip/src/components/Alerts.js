import React from 'react';
import './Alerts.css';

const Alerts = ({ message }) => {
  if (!message || !message.data) {
    return (
      <div className="alerts-container">
        <div className="alerts-header">
          <h2>System Alerts</h2>
          <p className="alerts-subtitle">Real-time system notifications and warnings</p>
        </div>
        <div className="no-alerts-state">
          <svg width="80" height="80" viewBox="0 0 80 80" fill="none">
            <circle cx="40" cy="40" r="38" stroke="#e5e7eb" strokeWidth="2"/>
            <path d="M40 20V44M40 56H40.02" stroke="#9ca3af" strokeWidth="3" strokeLinecap="round"/>
          </svg>
          <h3>No Data Available</h3>
          <p>Waiting for device connection to display alerts...</p>
        </div>
      </div>
    );
  }

  const dryRunAlert = message.data?.DryRunAlert || 0;
  const highLevelFloat = message.data?.HighLevelFloatAlert || 0;

  const alerts = [
    {
      id: 'dry-run',
      title: 'Dry Run Alert',
      description: 'Indicates if pump is running without sufficient water supply',
      active: dryRunAlert === 1,
      severity: 'critical',
      icon: (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
          <path d="M12 2L3 10H12L11 20L21 12H12L12 2Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      ),
      timestamp: new Date().toLocaleString()
    },
    {
      id: 'high-level',
      title: 'High Level Float Alert',
      description: 'Water level has reached the high level float threshold',
      active: highLevelFloat === 1,
      severity: 'warning',
      icon: (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
          <path d="M12 3C12 3 8 9 8 13C8 16.3137 10.6863 19 14 19C17.3137 19 20 16.3137 20 13C20 9 12 3 12 3Z"
                stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      ),
      timestamp: new Date().toLocaleString()
    }
  ];

  const activeAlerts = alerts.filter(alert => alert.active);
  const inactiveAlerts = alerts.filter(alert => !alert.active);

  return (
    <div className="alerts-container">
      <div className="alerts-header">
        <h2>System Alerts</h2>
        <p className="alerts-subtitle">Real-time system notifications and warnings</p>
        <div className="alerts-stats">
          <div className="alert-stat">
            <span className="stat-value">{activeAlerts.length}</span>
            <span className="stat-label">Active</span>
          </div>
          <div className="alert-stat">
            <span className="stat-value">{alerts.length}</span>
            <span className="stat-label">Total</span>
          </div>
        </div>
      </div>

      {activeAlerts.length > 0 && (
        <div className="alerts-section">
          <h3 className="section-title">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <circle cx="8" cy="8" r="7" stroke="#dc2626" strokeWidth="1.5"/>
              <path d="M8 4V8M8 11H8.01" stroke="#dc2626" strokeWidth="1.5" strokeLinecap="round"/>
            </svg>
            Active Alerts
          </h3>
          <div className="alerts-grid">
            {activeAlerts.map(alert => (
              <div key={alert.id} className={`alert-card active ${alert.severity}`}>
                <div className="alert-icon">
                  {alert.icon}
                </div>
                <div className="alert-content">
                  <div className="alert-header-row">
                    <h4 className="alert-title">{alert.title}</h4>
                    <span className={`alert-badge ${alert.severity}`}>
                      {alert.severity === 'critical' ? 'CRITICAL' : 'WARNING'}
                    </span>
                  </div>
                  <p className="alert-description">{alert.description}</p>
                  <div className="alert-meta">
                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                      <circle cx="7" cy="7" r="6" stroke="currentColor" strokeWidth="1.5"/>
                      <path d="M7 3.5V7L9.5 9.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                    </svg>
                    <span>{alert.timestamp}</span>
                  </div>
                </div>
                <div className="alert-pulse"></div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="alerts-section">
        <h3 className="section-title">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
            <circle cx="8" cy="8" r="7" stroke="#10b981" strokeWidth="1.5"/>
            <path d="M5 8L7 10L11 6" stroke="#10b981" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          {activeAlerts.length === 0 ? 'All Systems Normal' : 'Inactive Alerts'}
        </h3>
        <div className="alerts-grid">
          {inactiveAlerts.map(alert => (
            <div key={alert.id} className="alert-card inactive">
              <div className="alert-icon">
                {alert.icon}
              </div>
              <div className="alert-content">
                <div className="alert-header-row">
                  <h4 className="alert-title">{alert.title}</h4>
                  <span className="alert-badge inactive">NORMAL</span>
                </div>
                <p className="alert-description">{alert.description}</p>
                <div className="alert-meta">
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                    <circle cx="7" cy="7" r="6" stroke="currentColor" strokeWidth="1.5"/>
                    <path d="M5 7L7 9L11 5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                  <span>No issues detected</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Alerts;
