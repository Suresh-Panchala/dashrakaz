import React from 'react';
import { RadialBarChart, RadialBar, Legend, ResponsiveContainer } from 'recharts';

const RadialGauge = ({ value, max = 100, min = 0, label = 'Value', unit = '' }) => {
  const percentage = ((value - min) / (max - min)) * 100;

  const data = [
    {
      name: label,
      value: percentage,
      fill: percentage > 80 ? '#ef4444' : percentage > 60 ? '#f59e0b' : '#10b981',
    },
  ];

  return (
    <div style={{ width: '100%', height: 250, position: 'relative' }}>
      <ResponsiveContainer>
        <RadialBarChart
          cx="50%"
          cy="50%"
          innerRadius="60%"
          outerRadius="90%"
          barSize={20}
          data={data}
          startAngle={180}
          endAngle={0}
        >
          <RadialBar
            background
            dataKey="value"
            cornerRadius={10}
          />
        </RadialBarChart>
      </ResponsiveContainer>
      <div style={{
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        textAlign: 'center',
      }}>
        <div style={{ fontSize: '32px', fontWeight: 'bold', color: '#1f2937' }}>
          {value.toFixed(1)}{unit}
        </div>
        <div style={{ fontSize: '14px', color: '#6b7280', marginTop: '4px' }}>
          {label}
        </div>
      </div>
    </div>
  );
};

export default RadialGauge;
