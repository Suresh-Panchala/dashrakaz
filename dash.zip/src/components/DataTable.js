import React from 'react';
import './DataTable.css';

const DataTable = ({ data, title = "Recent Data" }) => {
  const formatValue = (value) => {
    if (typeof value === 'number') {
      return value.toFixed(2);
    }
    return value;
  };

  const getStatusBadge = (value) => {
    if (value === 1) {
      return <span className="status-badge active">Active</span>;
    } else if (value === 0) {
      return <span className="status-badge inactive">Inactive</span>;
    }
    return formatValue(value);
  };

  if (!data || !data.data) {
    return null;
  }

  const entries = Object.entries(data.data).slice(0, 10);

  return (
    <div className="data-table-container">
      <div className="data-table-header">
        <h3>{title}</h3>
        <span className="data-timestamp">
          {data.timestamp ? new Date(data.timestamp).toLocaleString() : 'N/A'}
        </span>
      </div>
      <div className="data-table-wrapper">
        <table className="data-table">
          <thead>
            <tr>
              <th>Parameter</th>
              <th>Value</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {entries.map(([key, value], index) => (
              <tr key={index}>
                <td className="param-name">{key.replace(/_/g, ' ')}</td>
                <td className="param-value">{formatValue(value)}</td>
                <td className="param-status">
                  {(key.includes('Alert') || key.includes('Manual') || key.includes('Auto'))
                    ? getStatusBadge(value)
                    : '—'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default DataTable;
