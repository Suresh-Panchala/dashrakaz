import React from 'react';
import './StatsCard.css';

const StatsCard = ({ title, value, unit, icon, trend, trendValue, color = 'blue' }) => {
  const colorClasses = {
    blue: 'stats-card-blue',
    green: 'stats-card-green',
    orange: 'stats-card-orange',
    red: 'stats-card-red',
    purple: 'stats-card-purple',
  };

  return (
    <div className={`stats-card ${colorClasses[color]}`}>
      <div className="stats-card-header">
        <div className="stats-card-icon">
          {icon}
        </div>
        {trend && (
          <div className={`stats-card-trend ${trend === 'up' ? 'trend-up' : 'trend-down'}`}>
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
              {trend === 'up' ? (
                <path d="M2 9L6 5L10 9" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              ) : (
                <path d="M2 3L6 7L10 3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              )}
            </svg>
            <span>{trendValue}</span>
          </div>
        )}
      </div>
      <div className="stats-card-content">
        <div className="stats-card-value">
          {value}
          {unit && <span className="stats-card-unit">{unit}</span>}
        </div>
        <div className="stats-card-title">{title}</div>
      </div>
    </div>
  );
};

export default StatsCard;
