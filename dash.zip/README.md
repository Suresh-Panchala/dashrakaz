# 🌊 StormWater Monitoring Dashboard

A modern, real-time IoT monitoring dashboard for stormwater management systems with MQTT integration, historical data storage, and analytics.

![Dashboard](https://img.shields.io/badge/React-18.x-blue)
![Node.js](https://img.shields.io/badge/Node.js-18.x-green)
![MongoDB](https://img.shields.io/badge/MongoDB-6.x-success)
![MQTT](https://img.shields.io/badge/MQTT-Mosquitto-orange)

## ✨ Features

### 📊 Real-Time Monitoring
- Live MQTT data streaming
- Real-time parameter updates
- Voltage, Current, Power monitoring
- Pump status tracking
- Running hours display

### 🎨 Modern UI/UX
- **Dark/Light Theme** - Seamless theme switching
- **Responsive Design** - Works on all devices (Desktop, Tablet, Mobile)
- **Professional Pump Cards** - Animated, eye-catching status indicators
- **Interactive Charts** - Real-time trend visualization
- **Smooth Animations** - Modern transitions and effects

### 📈 Analytics & Historical Data
- Historical data viewing with date range selection
- Statistical analysis (averages, min/max values)
- Interactive charts for trends analysis
- Data aggregation by hour/day/month

### 📥 Data Export
- **CSV Export** - Export raw data for analysis
- **PDF Reports** - Generate professional reports
- Custom date range selection for exports

### 🔐 User Management
- Multi-user support
- Role-based access control
- Device management
- Settings configuration

### 🗄️ Database Integration
- MongoDB for historical data storage
- Automatic MQTT data logging
- Efficient data querying
- Data retention management

## 🏗️ System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     Frontend (React)                         │
│  - Dashboard View      - Historical Data View                │
│  - Analytics View      - Device Management                   │
│  - Reports & Exports   - User Management                     │
└─────────────────────────────────────────────────────────────┘
                            ↓ ↑
                         REST API
                            ↓ ↑
┌─────────────────────────────────────────────────────────────┐
│                  Backend (Node.js/Express)                   │
│  - REST API Server     - MQTT Subscriber                     │
│  - Data Processing     - Export Services                     │
│  - Authentication      - Statistics Engine                   │
└─────────────────────────────────────────────────────────────┘
        ↓ ↑                              ↓ ↑
   MQTT Messages                    Database Queries
        ↓ ↑                              ↓ ↑
┌──────────────────┐          ┌──────────────────────┐
│    Mosquitto     │          │      MongoDB         │
│   MQTT Broker    │          │  Historical Data     │
│   Port: 1883     │          │   Port: 27017        │
└──────────────────┘          └──────────────────────┘
        ↑
        │
   IoT Devices
```

## 🚀 Quick Start

### Prerequisites
- Node.js 16 or higher
- MongoDB installed and running
- Mosquitto MQTT broker installed and running

### Frontend Setup

```bash
# Install dependencies
npm install

# Start development server
npm start

# Build for production
npm run build
```

The app will open at `http://localhost:3000`

### Backend Setup

```bash
# Navigate to backend directory
cd backend

# Install dependencies
npm install

# Configure environment
cp config.example.env .env
nano .env

# Start development server
npm run dev

# Start production server
npm start
```

The API will run at `http://localhost:5000`

### Environment Configuration

**Frontend (.env in root):**
```env
REACT_APP_API_URL=http://localhost:5000/api
```

**Backend (backend/.env):**
```env
PORT=5000
NODE_ENV=development
MONGODB_URI=mongodb://localhost:27017/stormwater
MQTT_BROKER_URL=mqtt://localhost:1883
MQTT_TOPIC=stromwater/khusam/device1/data
FRONTEND_URL=http://localhost:3000
```

## 📦 Installation & Deployment

For detailed deployment instructions on Ubuntu VPS, see:
- **[Complete Deployment Guide](DEPLOYMENT_GUIDE.md)** - Step-by-step VPS deployment
- **[Backend README](backend/README.md)** - Backend-specific documentation

## 📱 Responsive Design

The dashboard is fully responsive and optimized for:
- **Desktop** - Full feature set with multi-column layouts
- **Tablets** - Optimized 2-column layouts
- **Mobile Phones** - Single column, touch-friendly interface
- **Small Devices** - Compact UI with essential features

## 🎨 Theme Support

Automatic dark/light theme switching with:
- CSS variables for consistent theming
- Theme-aware charts and graphs
- Smooth transitions
- User preference persistence

## 📊 API Endpoints

### Health & Info
- `GET /api/health` - System health check
- `GET /` - API information

### Data Retrieval
- `GET /api/data/latest/:deviceId` - Latest data points
- `GET /api/data/history/:deviceId` - Paginated historical data
- `GET /api/data/stats/:deviceId` - Statistical summaries
- `GET /api/data/range/:deviceId` - Date range queries

### Export
- `GET /api/data/export/csv/:deviceId` - Export as CSV
- `GET /api/data/export/pdf/:deviceId` - Export as PDF

### Device Management
- `GET /api/data/devices` - List all devices
- `GET /api/data/device/:deviceId` - Device information

## 🔧 Technology Stack

### Frontend
- **React 18** - UI framework
- **Recharts** - Chart library
- **CSS Variables** - Theming system
- **Context API** - State management

### Backend
- **Node.js** - Runtime
- **Express** - Web framework
- **Mongoose** - MongoDB ODM
- **MQTT.js** - MQTT client
- **PDFKit** - PDF generation
- **json2csv** - CSV export

### Infrastructure
- **MongoDB** - Database
- **Mosquitto** - MQTT broker
- **PM2** - Process manager
- **Nginx** - Web server (production)

## 📁 Project Structure

```
stormwater-dashboard/
├── public/              # Static files
├── src/
│   ├── components/      # React components
│   ├── context/         # React contexts
│   ├── hooks/           # Custom hooks
│   ├── services/        # API services
│   └── App.js          # Main app component
├── backend/
│   ├── config/         # Configuration
│   ├── controllers/    # Route controllers
│   ├── models/         # MongoDB models
│   ├── routes/         # API routes
│   ├── services/       # Business logic
│   ├── utils/          # Utilities
│   └── server.js       # Server entry point
├── DEPLOYMENT_GUIDE.md  # Deployment instructions
└── package.json
```

## 🎯 Key Features Explained

### Real-Time Dashboard
- Live parameter cards with phase indicators
- Animated pump status cards with rotating icons
- Running/Stopped state visualization
- Real-time charts with configurable data points

### Historical Data Analysis
- Date range selection
- Time interval aggregation (hourly, daily, monthly)
- Interactive trend charts
- Statistical summaries

### Professional Pump Cards
- Rotating icons for active pumps
- Pulsing status indicators
- Performance progress bars
- Mode indicators (Manual/Auto/Off)
- Running hours tracking

### Data Export
- Customizable date ranges
- CSV format for spreadsheet analysis
- PDF reports with statistics
- Automatic file download

## 🔐 Security Features

- Rate limiting on API endpoints
- CORS configuration
- Helmet.js security headers
- Optional MQTT authentication
- Optional MongoDB authentication

## 📈 Performance Optimizations

- Efficient MongoDB indexing
- Data pagination
- Query result limits
- Response compression
- Optimized chart rendering

## 🐛 Troubleshooting

### Frontend Issues
```bash
# Clear cache and reinstall
rm -rf node_modules package-lock.json
npm install

# Check for build errors
npm run build
```

### Backend Issues
```bash
# Check services
sudo systemctl status mongodb
sudo systemctl status mosquitto

# View backend logs
pm2 logs stormwater-backend

# Test API
curl http://localhost:5000/api/health
```

### MQTT Connection Issues
```bash
# Test MQTT broker
mosquitto_sub -h localhost -t "test" -v

# Check Mosquitto logs
sudo journalctl -u mosquitto -f
```

## 📝 Data Format

Expected MQTT message format:
```json
{
  "VR": 230.5,
  "VY": 231.2,
  "VB": 229.8,
  "CR": 12.5,
  "CY": 13.1,
  "CB": 12.8,
  "KW": 8.5,
  "KVA": 9.2,
  "KVAR": 3.1,
  "PF": 0.92,
  "F": 50.0,
  "P1M": 0,
  "P1A": 1,
  "P1RHS": 1250,
  ...
}
```

## 🤝 Contributing

Contributions are welcome! Please:
1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License.

## 🙏 Acknowledgments

- React team for the amazing framework
- Recharts for beautiful charts
- MQTT.js for MQTT client
- PDFKit for PDF generation

## 📞 Support

For issues and questions:
- Check the [Deployment Guide](DEPLOYMENT_GUIDE.md)
- Review backend logs: `pm2 logs stormwater-backend`
- Check service status: `systemctl status mongodb mosquitto`

## 🎉 Credits

Built with ❤️ for efficient stormwater monitoring and management.

---

**Happy Monitoring! 🌊📊**
