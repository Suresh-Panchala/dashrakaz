# 🚀 StormWater Monitoring System - Complete Deployment Guide

This guide will help you deploy the complete StormWater Monitoring System on your Ubuntu VPS.

## 📋 System Architecture

```
┌─────────────────┐         ┌──────────────────┐         ┌──────────────────┐
│   React App     │────────▶│   Backend API    │────────▶│    MongoDB       │
│  (Frontend)     │◀────────│  (Node.js/Express)│◀────────│   Database       │
│  Port: 3000     │         │   Port: 5000     │         │  Port: 27017     │
└─────────────────┘         └──────────────────┘         └──────────────────┘
                                     ▲
                                     │
                                     ▼
                            ┌──────────────────┐
                            │   Mosquitto      │
                            │   MQTT Broker    │
                            │   Port: 1883     │
                            └──────────────────┘
```

## 🎯 Prerequisites

- Ubuntu 20.04 or 22.04 VPS
- Root or sudo access
- At least 2GB RAM
- 20GB disk space
- Domain name (optional but recommended)

## 📦 Part 1: System Preparation

### 1. Update System

```bash
sudo apt update && sudo apt upgrade -y
```

### 2. Install Essential Tools

```bash
sudo apt install -y curl wget git build-essential
```

## 🗄️ Part 2: Install MongoDB

### Method 1: Standard Installation

```bash
# Install MongoDB
sudo apt install -y mongodb

# Start and enable MongoDB
sudo systemctl start mongodb
sudo systemctl enable mongodb

# Check status
sudo systemctl status mongodb
```

### Method 2: Latest MongoDB Community Edition

```bash
# Import MongoDB GPG key
wget -qO - https://www.mongodb.org/static/pgp/server-6.0.asc | sudo apt-key add -

# Add MongoDB repository
echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu focal/mongodb-org/6.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-6.0.list

# Install MongoDB
sudo apt update
sudo apt install -y mongodb-org

# Start and enable
sudo systemctl start mongod
sudo systemctl enable mongod
```

### Verify MongoDB

```bash
mongosh --version
# or
mongo --version
```

## 📡 Part 3: Configure Mosquitto MQTT Broker

### Install Mosquitto

```bash
sudo apt install -y mosquitto mosquitto-clients

# Start and enable
sudo systemctl start mosquitto
sudo systemctl enable mosquitto

# Check status
sudo systemctl status mosquitto
```

### Configure Mosquitto (Optional - for security)

```bash
# Create password file
sudo mosquitto_passwd -c /etc/mosquitto/passwd your_username

# Edit config
sudo nano /etc/mosquitto/mosquitto.conf
```

Add these lines:
```
listener 1883
allow_anonymous false
password_file /etc/mosquitto/passwd
```

Restart Mosquitto:
```bash
sudo systemctl restart mosquitto
```

### Test MQTT

```bash
# Subscribe to test topic
mosquitto_sub -h localhost -t "test/topic" -v

# In another terminal, publish
mosquitto_pub -h localhost -t "test/topic" -m "Hello MQTT"
```

## 🖥️ Part 4: Install Node.js

```bash
# Install Node.js 18.x LTS
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Verify installation
node --version  # Should be v18.x
npm --version   # Should be 9.x or higher
```

## 🔧 Part 5: Deploy Backend

### 1. Create Project Directory

```bash
sudo mkdir -p /var/www/stormwater
sudo chown $USER:$USER /var/www/stormwater
cd /var/www/stormwater
```

### 2. Upload Backend Files

Upload your `backend` folder to `/var/www/stormwater/backend`

Or if using Git:
```bash
git clone <your-repo-url> .
```

### 3. Install Backend Dependencies

```bash
cd /var/www/stormwater/backend
npm install --production
```

### 4. Configure Backend Environment

```bash
cp config.example.env .env
nano .env
```

Update with your settings:
```env
PORT=5000
NODE_ENV=production
MONGODB_URI=mongodb://localhost:27017/stormwater
MQTT_BROKER_URL=mqtt://localhost:1883
MQTT_TOPIC=stromwater/khusam/device1/data
FRONTEND_URL=http://your-vps-ip:3000
```

If you configured MQTT authentication:
```env
MQTT_USERNAME=your_username
MQTT_PASSWORD=your_password
```

### 5. Install PM2 Process Manager

```bash
sudo npm install -g pm2
```

### 6. Start Backend with PM2

```bash
cd /var/www/stormwater/backend
pm2 start server.js --name stormwater-backend

# Save PM2 configuration
pm2 save

# Enable PM2 to start on boot
pm2 startup
# Follow the instruction shown
```

### 7. Verify Backend is Running

```bash
# Check PM2 status
pm2 status

# Check logs
pm2 logs stormwater-backend

# Test API
curl http://localhost:5000/api/health
```

## 🎨 Part 6: Deploy Frontend

### 1. Install Frontend Dependencies

```bash
cd /var/www/stormwater
npm install
```

### 2. Configure Frontend Environment

Create `.env` file in the root directory:

```bash
nano .env
```

Add:
```env
REACT_APP_API_URL=http://your-vps-ip:5000/api
```

For production with domain:
```env
REACT_APP_API_URL=https://api.your-domain.com/api
```

### 3. Build Frontend

```bash
npm run build
```

### 4. Serve Frontend with PM2

```bash
# Install serve
npm install -g serve

# Start with PM2
pm2 serve build 3000 --name stormwater-frontend --spa

# Save configuration
pm2 save
```

## 🌐 Part 7: Configure Nginx (Recommended)

### 1. Install Nginx

```bash
sudo apt install -y nginx
```

### 2. Create Nginx Configuration

```bash
sudo nano /etc/nginx/sites-available/stormwater
```

Add this configuration:

```nginx
# Backend API
server {
    listen 80;
    server_name api.your-domain.com;  # Or your-vps-ip

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_cache_bypass $http_upgrade;
    }
}

# Frontend
server {
    listen 80;
    server_name your-domain.com www.your-domain.com;  # Or your-vps-ip

    root /var/www/stormwater/build;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    # Enable gzip compression
    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;
}
```

### 3. Enable Site

```bash
sudo ln -s /etc/nginx/sites-available/stormwater /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

## 🔒 Part 8: Configure Firewall

```bash
# Allow SSH
sudo ufw allow OpenSSH

# Allow HTTP and HTTPS
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

# Allow backend API (if not using Nginx)
sudo ufw allow 5000/tcp

# Allow frontend (if not using Nginx)
sudo ufw allow 3000/tcp

# Enable firewall
sudo ufw enable

# Check status
sudo ufw status
```

## 🔐 Part 9: SSL Certificate (Optional but Recommended)

### Using Let's Encrypt (Free SSL)

```bash
# Install Certbot
sudo apt install -y certbot python3-certbot-nginx

# Get SSL certificate
sudo certbot --nginx -d your-domain.com -d www.your-domain.com -d api.your-domain.com

# Auto-renewal is configured automatically
# Test renewal
sudo certbot renew --dry-run
```

## 🎯 Part 10: Final Configuration

### Update Frontend .env for Production

```bash
cd /var/www/stormwater
nano .env
```

Update to use your domain:
```env
REACT_APP_API_URL=https://api.your-domain.com/api
```

Rebuild frontend:
```bash
npm run build
pm2 restart stormwater-frontend
```

## ✅ Part 11: Verification

### 1. Check All Services

```bash
# MongoDB
sudo systemctl status mongodb

# Mosquitto
sudo systemctl status mosquitto

# PM2 processes
pm2 status

# Nginx
sudo systemctl status nginx
```

### 2. Test API

```bash
curl https://api.your-domain.com/api/health
```

### 3. Access Frontend

Open browser and visit:
- `https://your-domain.com`

## 📊 Part 12: Monitoring and Maintenance

### View Logs

```bash
# Backend logs
pm2 logs stormwater-backend

# Frontend logs
pm2 logs stormwater-frontend

# Nginx access logs
sudo tail -f /var/log/nginx/access.log

# Nginx error logs
sudo tail -f /var/log/nginx/error.log
```

### Restart Services

```bash
# Restart backend
pm2 restart stormwater-backend

# Restart frontend
pm2 restart stormwater-frontend

# Restart Nginx
sudo systemctl restart nginx

# Restart MongoDB
sudo systemctl restart mongodb

# Restart Mosquitto
sudo systemctl restart mosquitto
```

### Backup Database

Create backup script:

```bash
nano /home/$USER/backup-mongodb.sh
```

Add:
```bash
#!/bin/bash
BACKUP_DIR="/backup/mongodb"
DATE=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DIR
mongodump --db stormwater --out $BACKUP_DIR/$DATE

# Keep only last 7 days
find $BACKUP_DIR -type d -mtime +7 -exec rm -rf {} +
```

Make executable and add to cron:
```bash
chmod +x /home/$USER/backup-mongodb.sh
crontab -e

# Add this line for daily backup at 2 AM
0 2 * * * /home/$USER/backup-mongodb.sh
```

## 🔧 Troubleshooting

### Backend not starting

```bash
pm2 logs stormwater-backend
# Check for port conflicts
sudo netstat -tulpn | grep 5000
```

### Frontend not loading

```bash
# Check build
ls -la /var/www/stormwater/build

# Check Nginx config
sudo nginx -t

# Check Nginx logs
sudo tail -f /var/log/nginx/error.log
```

### MQTT connection issues

```bash
# Check Mosquitto
sudo systemctl status mosquitto

# Test MQTT
mosquitto_sub -h localhost -t "stromwater/khusam/device1/data" -v
```

### MongoDB issues

```bash
# Check MongoDB
sudo systemctl status mongodb

# Check MongoDB logs
sudo tail -f /var/log/mongodb/mongodb.log
```

## 🎉 Success!

Your StormWater Monitoring System should now be fully deployed and accessible at:

- **Frontend**: `https://your-domain.com`
- **Backend API**: `https://api.your-domain.com/api`
- **Health Check**: `https://api.your-domain.com/api/health`

## 📞 Next Steps

1. Configure your IoT devices to publish to your MQTT broker
2. Set up monitoring and alerts
3. Configure regular backups
4. Set up log rotation
5. Configure user management and authentication

## 🔗 Quick Reference

### Important Directories
- Frontend: `/var/www/stormwater`
- Backend: `/var/www/stormwater/backend`
- Nginx config: `/etc/nginx/sites-available/stormwater`
- MongoDB data: `/var/lib/mongodb`

### Important Commands
```bash
# View all PM2 processes
pm2 status

# Restart all services
pm2 restart all

# View backend logs
pm2 logs stormwater-backend

# Test API
curl http://localhost:5000/api/health

# Check MongoDB
mongosh stormwater --eval "db.stats()"
```

