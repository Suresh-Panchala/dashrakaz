#!/bin/bash

# StormWater Backend Setup Script
# This script helps set up the backend on Ubuntu

set -e

echo "================================================"
echo "  StormWater Monitoring Backend Setup"
echo "================================================"
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if running on Ubuntu
if [ ! -f /etc/os-release ]; then
    echo -e "${RED}Error: Cannot detect OS${NC}"
    exit 1
fi

source /etc/os-release
if [ "$ID" != "ubuntu" ]; then
    echo -e "${YELLOW}Warning: This script is designed for Ubuntu${NC}"
fi

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Check Node.js
echo -e "${YELLOW}Checking Node.js...${NC}"
if command_exists node; then
    NODE_VERSION=$(node --version)
    echo -e "${GREEN}✓ Node.js $NODE_VERSION is installed${NC}"
else
    echo -e "${RED}✗ Node.js is not installed${NC}"
    echo "Please install Node.js 16 or higher"
    echo "Run: curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -"
    echo "     sudo apt install -y nodejs"
    exit 1
fi

# Check MongoDB
echo -e "${YELLOW}Checking MongoDB...${NC}"
if command_exists mongod || command_exists mongodb; then
    echo -e "${GREEN}✓ MongoDB is installed${NC}"
    
    # Check if MongoDB is running
    if systemctl is-active --quiet mongod || systemctl is-active --quiet mongodb; then
        echo -e "${GREEN}✓ MongoDB is running${NC}"
    else
        echo -e "${YELLOW}⚠ MongoDB is not running${NC}"
        echo "Starting MongoDB..."
        sudo systemctl start mongod || sudo systemctl start mongodb
    fi
else
    echo -e "${RED}✗ MongoDB is not installed${NC}"
    echo "Please install MongoDB"
    echo "Run: sudo apt install -y mongodb"
    exit 1
fi

# Check Mosquitto
echo -e "${YELLOW}Checking Mosquitto...${NC}"
if command_exists mosquitto; then
    echo -e "${GREEN}✓ Mosquitto is installed${NC}"
    
    # Check if Mosquitto is running
    if systemctl is-active --quiet mosquitto; then
        echo -e "${GREEN}✓ Mosquitto is running${NC}"
    else
        echo -e "${YELLOW}⚠ Mosquitto is not running${NC}"
        echo "Starting Mosquitto..."
        sudo systemctl start mosquitto
    fi
else
    echo -e "${RED}✗ Mosquitto is not installed${NC}"
    echo "Please install Mosquitto"
    echo "Run: sudo apt install -y mosquitto mosquitto-clients"
    exit 1
fi

# Install dependencies
echo ""
echo -e "${YELLOW}Installing npm dependencies...${NC}"
npm install

# Check if .env exists
echo ""
if [ ! -f .env ]; then
    echo -e "${YELLOW}Creating .env file from template...${NC}"
    if [ -f config.example.env ]; then
        cp config.example.env .env
        echo -e "${GREEN}✓ .env file created${NC}"
        echo -e "${YELLOW}⚠ Please edit .env file with your configuration${NC}"
        echo "  nano .env"
    else
        echo -e "${RED}✗ config.example.env not found${NC}"
    fi
else
    echo -e "${GREEN}✓ .env file already exists${NC}"
fi

# Check PM2
echo ""
echo -e "${YELLOW}Checking PM2...${NC}"
if command_exists pm2; then
    echo -e "${GREEN}✓ PM2 is installed${NC}"
else
    echo -e "${YELLOW}PM2 is not installed${NC}"
    read -p "Do you want to install PM2? (y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        sudo npm install -g pm2
        echo -e "${GREEN}✓ PM2 installed${NC}"
    fi
fi

echo ""
echo "================================================"
echo -e "${GREEN}Setup completed!${NC}"
echo "================================================"
echo ""
echo "Next steps:"
echo "1. Edit .env file: nano .env"
echo "2. Start the server:"
echo "   - Development: npm run dev"
echo "   - Production: npm start"
echo "   - With PM2: pm2 start server.js --name stormwater-backend"
echo ""
echo "For deployment guide, see: README.md"
echo ""

