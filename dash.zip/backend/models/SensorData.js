const mongoose = require('mongoose');

const sensorDataSchema = new mongoose.Schema({
  // Device Information
  deviceId: {
    type: String,
    required: true,
    index: true
  },
  deviceName: {
    type: String,
    required: true
  },
  
  // Timestamp
  timestamp: {
    type: Date,
    default: Date.now,
    index: true
  },
  
  // Phase Voltages
  voltageR: {
    type: Number,
    required: true
  },
  voltageY: {
    type: Number,
    required: true
  },
  voltageB: {
    type: Number,
    required: true
  },
  
  // Phase Currents
  currentR: {
    type: Number,
    required: true
  },
  currentY: {
    type: Number,
    required: true
  },
  currentB: {
    type: Number,
    required: true
  },
  
  // Power Parameters
  kw: {
    type: Number,
    required: true
  },
  kva: {
    type: Number,
    required: true
  },
  kvar: {
    type: Number,
    required: true
  },
  powerFactor: {
    type: Number,
    required: true
  },
  frequency: {
    type: Number,
    required: true
  },
  
  // Pump Status
  pump1: {
    manual: { type: Number, default: 0 },
    auto: { type: Number, default: 0 },
    rhs: { type: Number, default: 0 }
  },
  pump2: {
    manual: { type: Number, default: 0 },
    auto: { type: Number, default: 0 },
    rhs: { type: Number, default: 0 }
  },
  pump3: {
    manual: { type: Number, default: 0 },
    auto: { type: Number, default: 0 },
    rhs: { type: Number, default: 0 }
  },
  pump4: {
    manual: { type: Number, default: 0 },
    auto: { type: Number, default: 0 },
    rhs: { type: Number, default: 0 }
  }
}, {
  timestamps: true,  // Adds createdAt and updatedAt fields
  collection: 'sensorData'
});

// Indexes for better query performance
sensorDataSchema.index({ deviceId: 1, timestamp: -1 });
sensorDataSchema.index({ timestamp: -1 });
sensorDataSchema.index({ deviceId: 1, createdAt: -1 });

// TTL Index - Optional: Auto-delete data older than 90 days
// Uncomment if you want automatic data cleanup
// sensorDataSchema.index({ timestamp: 1 }, { expireAfterSeconds: 7776000 }); // 90 days

const SensorData = mongoose.model('SensorData', sensorDataSchema);

module.exports = SensorData;

