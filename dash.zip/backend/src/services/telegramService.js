import axios from 'axios';

export const sendTelegramAlert = async (alert) => {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;

  if (!token || !chatId) {
    console.log('Telegram notifications not configured');
    return false;
  }

  try {
    const severityEmoji = {
      info: 'ℹ️',
      warning: '⚠️',
      critical: '🚨'
    };

    const message = `
${severityEmoji[alert.severity]} *StormWater Alert*

*Device:* ${alert.deviceId}
*Type:* ${alert.alertType}
*Severity:* ${alert.severity.toUpperCase()}
*Message:* ${alert.message}
${alert.value ? `*Value:* ${alert.value}` : ''}
*Time:* ${new Date(alert.createdAt).toLocaleString()}
    `.trim();

    const url = `https://api.telegram.org/bot${token}/sendMessage`;
    
    await axios.post(url, {
      chat_id: chatId,
      text: message,
      parse_mode: 'Markdown'
    });

    // Update alert to mark Telegram notification as sent
    alert.notificationSent.telegram = true;
    await alert.save();

    console.log('✅ Telegram alert sent');
    return true;
  } catch (error) {
    console.error('❌ Error sending Telegram alert:', error.message);
    return false;
  }
};

export const sendTelegramMessage = async (message) => {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;

  if (!token || !chatId) {
    return false;
  }

  try {
    const url = `https://api.telegram.org/bot${token}/sendMessage`;
    
    await axios.post(url, {
      chat_id: chatId,
      text: message,
      parse_mode: 'Markdown'
    });

    return true;
  } catch (error) {
    console.error('Error sending Telegram message:', error.message);
    return false;
  }
};








