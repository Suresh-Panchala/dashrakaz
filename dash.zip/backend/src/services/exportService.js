import { Parser } from 'json2csv';
import PDFDocument from 'pdfkit';
import DeviceData from '../models/DeviceData.js';
import Device from '../models/Device.js';

export const exportToCSV = async (deviceId, startDate, endDate) => {
  try {
    const query = { deviceId };

    if (startDate || endDate) {
      query.timestamp = {};
      if (startDate) query.timestamp.$gte = new Date(startDate);
      if (endDate) query.timestamp.$lte = new Date(endDate);
    }

    const data = await DeviceData.find(query)
      .sort({ timestamp: 1 })
      .lean();

    if (data.length === 0) {
      throw new Error('No data found for the specified criteria');
    }

    // Flatten the data structure for CSV
    const flattenedData = data.map(item => ({
      deviceId: item.deviceId,
      location: item.location,
      timestamp: item.timestamp,
      Hydrostatic_Value: item.data.Hydrostatic_Value,
      DryRunAlert: item.data.DryRunAlert,
      HighLevelFloatAlert: item.data.HighLevelFloatAlert,
      Pump_1_Manual: item.data.Pump_1_Manual,
      Pump_2_Manual: item.data.Pump_2_Manual,
      Pump_1_Auto: item.data.Pump_1_Auto,
      Pump_2_Auto: item.data.Pump_2_Auto,
      Pump_1_Protection: item.data.Pump_1_Protection,
      Pump_2_Protection: item.data.Pump_2_Protection,
      Pump_1_Contactor_Feedback: item.data.Pump_1_Contactor_Feedback,
      Pump_2_Contactor_Feedback: item.data.Pump_2_Contactor_Feedback,
      POWER_1_R: item.data.POWER_1_R,
      POWER_1_Y: item.data.POWER_1_Y,
      POWER_1_B: item.data.POWER_1_B,
      IRMS_1_R: item.data.IRMS_1_R,
      IRMS_1_Y: item.data.IRMS_1_Y,
      IRMS_1_B: item.data.IRMS_1_B,
      POWER_2_R: item.data.POWER_2_R,
      POWER_2_Y: item.data.POWER_2_Y,
      POWER_2_B: item.data.POWER_2_B,
      IRMS_2_R: item.data.IRMS_2_R,
      IRMS_2_Y: item.data.IRMS_2_Y,
      IRMS_2_B: item.data.IRMS_2_B,
      VRMS_1_R: item.data.VRMS_1_R,
      VRMS_1_Y: item.data.VRMS_1_Y,
      VRMS_1_B: item.data.VRMS_1_B,
      VRMS_2_R: item.data.VRMS_2_R,
      VRMS_2_Y: item.data.VRMS_2_Y,
      VRMS_2_B: item.data.VRMS_2_B,
      VAHR_1_R: item.data.VAHR_1_R,
      VAHR_1_Y: item.data.VAHR_1_Y,
      VAHR_1_B: item.data.VAHR_1_B,
      VAHR_2_R: item.data.VAHR_2_R,
      VAHR_2_Y: item.data.VAHR_2_Y,
      VAHR_2_B: item.data.VAHR_2_B,
      FREQ_1_R: item.data.FREQ_1_R,
      FREQ_1_Y: item.data.FREQ_1_Y,
      FREQ_1_B: item.data.FREQ_1_B,
      FREQ_2_R: item.data.FREQ_2_R,
      FREQ_2_Y: item.data.FREQ_2_Y,
      FREQ_2_B: item.data.FREQ_2_B,
      RHS_1: item.data.RHS_1,
      RHS_2: item.data.RHS_2
    }));

    const parser = new Parser();
    const csv = parser.parse(flattenedData);

    return csv;
  } catch (error) {
    console.error('Error exporting to CSV:', error);
    throw error;
  }
};

export const exportToPDF = async (deviceId, startDate, endDate) => {
  try {
    const device = await Device.findOne({ deviceId });
    
    const query = { deviceId };

    if (startDate || endDate) {
      query.timestamp = {};
      if (startDate) query.timestamp.$gte = new Date(startDate);
      if (endDate) query.timestamp.$lte = new Date(endDate);
    }

    const data = await DeviceData.find(query)
      .sort({ timestamp: -1 })
      .limit(50) // Limit for PDF to avoid huge files
      .lean();

    if (data.length === 0) {
      throw new Error('No data found for the specified criteria');
    }

    return new Promise((resolve, reject) => {
      const doc = new PDFDocument({ margin: 30, size: 'A4', layout: 'landscape' });
      const chunks = [];

      doc.on('data', chunk => chunks.push(chunk));
      doc.on('end', () => resolve(Buffer.concat(chunks)));
      doc.on('error', reject);

      // Helper function to draw table
      const drawTable = (headers, rows, startY) => {
        const tableTop = startY;
        const colWidth = (doc.page.width - 60) / headers.length;
        const rowHeight = 20;
        let currentY = tableTop;

        // Draw header
        doc.font('Helvetica-Bold').fontSize(8);
        headers.forEach((header, i) => {
          doc.rect(30 + (i * colWidth), currentY, colWidth, rowHeight).stroke();
          doc.text(header, 32 + (i * colWidth), currentY + 5, {
            width: colWidth - 4,
            align: 'center',
            ellipsis: true
          });
        });

        currentY += rowHeight;

        // Draw rows
        doc.font('Helvetica').fontSize(7);
        rows.forEach((row, rowIndex) => {
          // Check if we need a new page
          if (currentY > doc.page.height - 50) {
            doc.addPage({ size: 'A4', layout: 'landscape', margin: 30 });
            currentY = 30;
            // Redraw header
            doc.font('Helvetica-Bold').fontSize(8);
            headers.forEach((header, i) => {
              doc.rect(30 + (i * colWidth), currentY, colWidth, rowHeight).stroke();
              doc.text(header, 32 + (i * colWidth), currentY + 5, {
                width: colWidth - 4,
                align: 'center',
                ellipsis: true
              });
            });
            currentY += rowHeight;
            doc.font('Helvetica').fontSize(7);
          }

          row.forEach((cell, colIndex) => {
            doc.rect(30 + (colIndex * colWidth), currentY, colWidth, rowHeight).stroke();
            doc.text(String(cell || '--'), 32 + (colIndex * colWidth), currentY + 5, {
              width: colWidth - 4,
              align: 'center',
              ellipsis: true
            });
          });
          currentY += rowHeight;
        });

        return currentY;
      };

      // Header
      doc.font('Helvetica-Bold').fontSize(18).text('StormWater Device Report', { align: 'center' });
      doc.moveDown(0.5);
      doc.fontSize(10).text(`Device: ${deviceId} | Location: ${device?.location || 'Unknown'}`, { align: 'center' });
      doc.text(`Report Generated: ${new Date().toLocaleString()}`, { align: 'center' });
      
      if (startDate && endDate) {
        doc.text(`Period: ${new Date(startDate).toLocaleString()} - ${new Date(endDate).toLocaleString()}`, { align: 'center' });
      }
      
      doc.text(`Total Records: ${data.length}`, { align: 'center' });
      doc.moveDown();

      // Create table data
      const headers = [
        'Timestamp',
        'Water Level',
        'V1-R', 'V1-Y', 'V1-B',
        'I1-R', 'I1-Y', 'I1-B',
        'V2-R', 'V2-Y', 'V2-B',
        'I2-R', 'I2-Y', 'I2-B',
        'RHS-1', 'RHS-2'
      ];

      const rows = data.map(item => [
        new Date(item.timestamp).toLocaleString('en-US', { 
          month: '2-digit', 
          day: '2-digit', 
          hour: '2-digit', 
          minute: '2-digit' 
        }),
        item.data.Hydrostatic_Value?.toFixed(1) || '--',
        item.data.VRMS_1_R?.toFixed(0) || '--',
        item.data.VRMS_1_Y?.toFixed(0) || '--',
        item.data.VRMS_1_B?.toFixed(0) || '--',
        item.data.IRMS_1_R?.toFixed(1) || '--',
        item.data.IRMS_1_Y?.toFixed(1) || '--',
        item.data.IRMS_1_B?.toFixed(1) || '--',
        item.data.VRMS_2_R?.toFixed(0) || '--',
        item.data.VRMS_2_Y?.toFixed(0) || '--',
        item.data.VRMS_2_B?.toFixed(0) || '--',
        item.data.IRMS_2_R?.toFixed(1) || '--',
        item.data.IRMS_2_Y?.toFixed(1) || '--',
        item.data.IRMS_2_B?.toFixed(1) || '--',
        item.data.RHS_1 || '--',
        item.data.RHS_2 || '--'
      ]);

      // Draw the main data table
      drawTable(headers, rows, doc.y);

      doc.end();
    });
  } catch (error) {
    console.error('Error exporting to PDF:', error);
    throw error;
  }
};

const calculateAverage = (data, fields) => {
  let sum = 0;
  let count = 0;

  data.forEach(item => {
    fields.forEach(field => {
      const value = item.data[field];
      if (value && !isNaN(value)) {
        sum += value;
        count++;
      }
    });
  });

  return count > 0 ? sum / count : 0;
};





