import Alert from '../models/Alert.js';
import { sendTelegramAlert } from './telegramService.js';
import { sendEmailAlert } from './emailService.js';

// Track last alert time to prevent spam
const lastAlertTime = new Map();
const ALERT_COOLDOWN = 5 * 60 * 1000; // 5 minutes

export const checkAlerts = async (deviceId, data) => {
  const alerts = [];

  // Check Dry Run Alert
  if (process.env.ALERT_DRY_RUN_ENABLED === 'true' && data.DryRunAlert === 1) {
    if (shouldSendAlert(deviceId, 'DryRunAlert')) {
      alerts.push({
        deviceId,
        alertType: 'DryRunAlert',
        severity: 'critical',
        message: 'Dry run detected! Pump running without water.',
        value: data.DryRunAlert
      });
    }
  }

  // Check High Level Float Alert
  if (process.env.ALERT_HIGH_LEVEL_ENABLED === 'true' && data.HighLevelFloatAlert === 1) {
    if (shouldSendAlert(deviceId, 'HighLevelFloatAlert')) {
      alerts.push({
        deviceId,
        alertType: 'HighLevelFloatAlert',
        severity: 'warning',
        message: 'High water level detected!',
        value: data.HighLevelFloatAlert
      });
    }
  }

  // Check Pump 1 Protection
  if (data.Pump_1_Protection === 1) {
    if (shouldSendAlert(deviceId, 'Pump_1_Protection')) {
      alerts.push({
        deviceId,
        alertType: 'Pump_1_Protection',
        severity: 'critical',
        message: 'Pump 1 protection activated!',
        value: data.Pump_1_Protection
      });
    }
  }

  // Check Pump 2 Protection
  if (data.Pump_2_Protection === 1) {
    if (shouldSendAlert(deviceId, 'Pump_2_Protection')) {
      alerts.push({
        deviceId,
        alertType: 'Pump_2_Protection',
        severity: 'critical',
        message: 'Pump 2 protection activated!',
        value: data.Pump_2_Protection
      });
    }
  }

  // Check voltage levels
  const voltages = [
    data.VRMS_1_R, data.VRMS_1_Y, data.VRMS_1_B,
    data.VRMS_2_R, data.VRMS_2_Y, data.VRMS_2_B
  ];

  const lowThreshold = parseFloat(process.env.ALERT_VOLTAGE_LOW_THRESHOLD) || 200;
  const highThreshold = parseFloat(process.env.ALERT_VOLTAGE_HIGH_THRESHOLD) || 250;

  voltages.forEach((voltage, index) => {
    if (voltage && (voltage < lowThreshold || voltage > highThreshold)) {
      const phase = ['1_R', '1_Y', '1_B', '2_R', '2_Y', '2_B'][index];
      if (shouldSendAlert(deviceId, `Voltage_${phase}`)) {
        alerts.push({
          deviceId,
          alertType: voltage < lowThreshold ? 'VoltageLow' : 'VoltageHigh',
          severity: 'warning',
          message: `Voltage ${voltage < lowThreshold ? 'low' : 'high'} on phase ${phase}: ${voltage}V`,
          value: voltage
        });
      }
    }
  });

  // Check current levels
  const currentThreshold = parseFloat(process.env.ALERT_CURRENT_HIGH_THRESHOLD) || 10;
  const currents = [
    { name: '1_R', value: data.IRMS_1_R },
    { name: '1_Y', value: data.IRMS_1_Y },
    { name: '1_B', value: data.IRMS_1_B },
    { name: '2_R', value: data.IRMS_2_R },
    { name: '2_Y', value: data.IRMS_2_Y },
    { name: '2_B', value: data.IRMS_2_B }
  ];

  currents.forEach(({ name, value }) => {
    if (value && value > currentThreshold) {
      if (shouldSendAlert(deviceId, `Current_${name}`)) {
        alerts.push({
          deviceId,
          alertType: 'CurrentHigh',
          severity: 'warning',
          message: `High current on phase ${name}: ${value}A`,
          value
        });
      }
    }
  });

  // Save and send alerts
  for (const alertData of alerts) {
    try {
      const alert = new Alert(alertData);
      await alert.save();

      // Send notifications
      await sendNotifications(alert);
      
      console.log(`🚨 Alert created: ${alertData.alertType} for device ${deviceId}`);
    } catch (error) {
      console.error('Error saving alert:', error);
    }
  }
};

const shouldSendAlert = (deviceId, alertType) => {
  const key = `${deviceId}_${alertType}`;
  const now = Date.now();
  const lastTime = lastAlertTime.get(key) || 0;

  if (now - lastTime > ALERT_COOLDOWN) {
    lastAlertTime.set(key, now);
    return true;
  }

  return false;
};

const sendNotifications = async (alert) => {
  try {
    // Send Telegram notification
    if (process.env.TELEGRAM_BOT_TOKEN) {
      await sendTelegramAlert(alert);
    }

    // Send Email notification
    if (process.env.EMAIL_ENABLED === 'true') {
      await sendEmailAlert(alert);
    }
  } catch (error) {
    console.error('Error sending notifications:', error);
  }
};

export const getAlerts = async (filters = {}) => {
  const query = {};

  if (filters.deviceId) {
    query.deviceId = filters.deviceId;
  }

  if (filters.acknowledged !== undefined) {
    query.acknowledged = filters.acknowledged;
  }

  if (filters.severity) {
    query.severity = filters.severity;
  }

  if (filters.startDate || filters.endDate) {
    query.createdAt = {};
    if (filters.startDate) {
      query.createdAt.$gte = new Date(filters.startDate);
    }
    if (filters.endDate) {
      query.createdAt.$lte = new Date(filters.endDate);
    }
  }

  const alerts = await Alert.find(query)
    .sort({ createdAt: -1 })
    .limit(filters.limit || 100);

  return alerts;
};

export const acknowledgeAlert = async (alertId, userId) => {
  const alert = await Alert.findByIdAndUpdate(
    alertId,
    {
      acknowledged: true,
      acknowledgedBy: userId,
      acknowledgedAt: new Date()
    },
    { new: true }
  );

  return alert;
};








