import nodemailer from 'nodemailer';

let transporter = null;

const initTransporter = () => {
  if (process.env.EMAIL_ENABLED !== 'true') {
    return null;
  }

  if (!transporter) {
    transporter = nodemailer.createTransport({
      host: process.env.EMAIL_HOST,
      port: parseInt(process.env.EMAIL_PORT),
      secure: process.env.EMAIL_SECURE === 'true',
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASSWORD
      }
    });
  }

  return transporter;
};

export const sendEmailAlert = async (alert) => {
  const mailer = initTransporter();
  
  if (!mailer) {
    console.log('Email notifications not configured');
    return false;
  }

  try {
    const severityColor = {
      info: '#3b82f6',
      warning: '#f59e0b',
      critical: '#ef4444'
    };

    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: ${severityColor[alert.severity]}; color: white; padding: 20px; border-radius: 5px 5px 0 0; }
          .content { background: #f9f9f9; padding: 20px; border-radius: 0 0 5px 5px; }
          .detail { margin: 10px 0; }
          .label { font-weight: bold; color: #555; }
          .footer { margin-top: 20px; font-size: 12px; color: #888; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h2>StormWater System Alert</h2>
          </div>
          <div class="content">
            <div class="detail">
              <span class="label">Device:</span> ${alert.deviceId}
            </div>
            <div class="detail">
              <span class="label">Alert Type:</span> ${alert.alertType}
            </div>
            <div class="detail">
              <span class="label">Severity:</span> ${alert.severity.toUpperCase()}
            </div>
            <div class="detail">
              <span class="label">Message:</span> ${alert.message}
            </div>
            ${alert.value ? `
            <div class="detail">
              <span class="label">Value:</span> ${alert.value}
            </div>
            ` : ''}
            <div class="detail">
              <span class="label">Time:</span> ${new Date(alert.createdAt).toLocaleString()}
            </div>
          </div>
          <div class="footer">
            This is an automated alert from the StormWater IoT Monitoring System.
          </div>
        </div>
      </body>
      </html>
    `;

    await mailer.sendMail({
      from: process.env.EMAIL_FROM,
      to: process.env.EMAIL_USER, // In production, use admin email list
      subject: `[${alert.severity.toUpperCase()}] ${alert.alertType} - ${alert.deviceId}`,
      html: htmlContent
    });

    // Update alert to mark email notification as sent
    alert.notificationSent.email = true;
    await alert.save();

    console.log('✅ Email alert sent');
    return true;
  } catch (error) {
    console.error('❌ Error sending email alert:', error.message);
    return false;
  }
};

export const sendEmail = async (to, subject, html) => {
  const mailer = initTransporter();
  
  if (!mailer) {
    return false;
  }

  try {
    await mailer.sendMail({
      from: process.env.EMAIL_FROM,
      to,
      subject,
      html
    });

    return true;
  } catch (error) {
    console.error('Error sending email:', error.message);
    return false;
  }
};








