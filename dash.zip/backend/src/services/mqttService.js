import mqtt from 'mqtt';
import DeviceData from '../models/DeviceData.js';
import Device from '../models/Device.js';
import { checkAlerts } from './alertService.js';

class MQTTService {
  constructor() {
    this.client = null;
    this.isConnected = false;
    this.io = null; // Socket.IO instance
  }

  // Initialize MQTT client
  connect(io) {
    this.io = io;

    const options = {
      clientId: process.env.MQTT_CLIENT_ID || 'stormwater_server',
      username: process.env.MQTT_USERNAME,
      password: process.env.MQTT_PASSWORD,
      clean: true,
      reconnectPeriod: 5000,
      connectTimeout: 30000
    };

    // Add SSL options if using mqtts://
    if (process.env.MQTT_BROKER_URL.startsWith('mqtts://')) {
      options.rejectUnauthorized = false; // Set to true in production with proper certs
    }

    this.client = mqtt.connect(process.env.MQTT_BROKER_URL, options);

    this.client.on('connect', () => {
      console.log('✅ MQTT Client connected to broker');
      this.isConnected = true;
      
      // Subscribe to all device data topics
      this.client.subscribe('devices/+/data', (err) => {
        if (err) {
          console.error('❌ MQTT subscription error:', err);
        } else {
          console.log('📡 Subscribed to: devices/+/data');
        }
      });

      // Subscribe to device status topics
      this.client.subscribe('devices/+/status', (err) => {
        if (err) {
          console.error('❌ MQTT subscription error:', err);
        } else {
          console.log('📡 Subscribed to: devices/+/status');
        }
      });
    });

    this.client.on('message', async (topic, message) => {
      try {
        await this.handleMessage(topic, message);
      } catch (error) {
        console.error('❌ Error handling MQTT message:', error);
      }
    });

    this.client.on('error', (error) => {
      console.error('❌ MQTT Client error:', error);
      this.isConnected = false;
    });

    this.client.on('offline', () => {
      console.log('⚠️  MQTT Client offline');
      this.isConnected = false;
    });

    this.client.on('reconnect', () => {
      console.log('🔄 MQTT Client reconnecting...');
    });
  }

  async handleMessage(topic, message) {
    try {
      const payload = JSON.parse(message.toString());
      
      // Extract device ID from topic (devices/DEVICE_ID/data)
      const topicParts = topic.split('/');
      const deviceId = topicParts[1];
      const topicType = topicParts[2]; // 'data' or 'status'

      if (topicType === 'data') {
        await this.handleDeviceData(deviceId, payload);
      } else if (topicType === 'status') {
        await this.handleDeviceStatus(deviceId, payload);
      }
    } catch (error) {
      console.error('Error parsing MQTT message:', error);
    }
  }

  async handleDeviceData(deviceIdFromTopic, payload) {
    try {
      const deviceId = payload.deviceId || deviceIdFromTopic;
      
      console.log(`📥 Received data from device: ${deviceId}`);

      // Update or create device
      await Device.findOneAndUpdate(
        { deviceId },
        {
          deviceId,
          name: payload.deviceId || deviceId,
          location: payload.location || 'Unknown',
          status: 'online',
          lastSeen: new Date()
        },
        { upsert: true, new: true }
      );

      // Save device data
      const deviceData = new DeviceData({
        deviceId,
        location: payload.location || 'Unknown',
        timestamp: new Date(payload.timestamp) || new Date(),
        data: payload.data || {},
        receivedAt: new Date()
      });

      await deviceData.save();

      // Check for alerts
      await checkAlerts(deviceId, payload.data || {});

      // Emit to connected clients via WebSocket
      if (this.io) {
        this.io.emit('deviceData', {
          deviceId,
          data: deviceData
        });
      }

      console.log(`✅ Data saved for device: ${deviceId}`);
    } catch (error) {
      console.error('Error handling device data:', error);
    }
  }

  async handleDeviceStatus(deviceId, payload) {
    try {
      await Device.findOneAndUpdate(
        { deviceId },
        {
          status: payload.status || 'online',
          lastSeen: new Date()
        },
        { upsert: true }
      );

      // Emit to connected clients
      if (this.io) {
        this.io.emit('deviceStatus', {
          deviceId,
          status: payload.status || 'online'
        });
      }
    } catch (error) {
      console.error('Error handling device status:', error);
    }
  }

  // Publish message to device
  publish(topic, message) {
    if (!this.isConnected) {
      console.error('MQTT client not connected');
      return false;
    }

    try {
      this.client.publish(topic, JSON.stringify(message));
      return true;
    } catch (error) {
      console.error('Error publishing MQTT message:', error);
      return false;
    }
  }

  // Send command to device
  sendCommand(deviceId, command) {
    const topic = `devices/${deviceId}/command`;
    return this.publish(topic, command);
  }

  // Disconnect
  disconnect() {
    if (this.client) {
      this.client.end();
      this.isConnected = false;
      console.log('MQTT Client disconnected');
    }
  }
}

// Singleton instance
const mqttService = new MQTTService();

export default mqttService;








