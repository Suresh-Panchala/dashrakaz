import mongoose from 'mongoose';

const deviceSchema = new mongoose.Schema({
  deviceId: {
    type: String,
    required: true,
    unique: true,
    trim: true
  },
  name: {
    type: String,
    required: true,
    trim: true
  },
  location: {
    type: String,
    required: true,
    trim: true
  },
  coordinates: {
    latitude: {
      type: Number,
      default: null
    },
    longitude: {
      type: Number,
      default: null
    }
  },
  status: {
    type: String,
    enum: ['online', 'offline', 'maintenance', 'pending'],
    default: 'pending'
  },
  lastSeen: {
    type: Date,
    default: null
  },
  metadata: {
    firmwareVersion: String,
    hardwareVersion: String,
    installationDate: Date,
    description: String
  },
  isActive: {
    type: Boolean,
    default: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// Update timestamp on save
deviceSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

const Device = mongoose.model('Device', deviceSchema);

export default Device;





