import mongoose from 'mongoose';

const alertSchema = new mongoose.Schema({
  deviceId: {
    type: String,
    required: true,
    index: true
  },
  alertType: {
    type: String,
    required: true,
    enum: [
      'DryRunAlert',
      'HighLevelFloatAlert',
      'Pump_1_Protection',
      'Pump_2_Protection',
      'VoltageLow',
      'VoltageHigh',
      'CurrentHigh',
      'DeviceOffline'
    ]
  },
  severity: {
    type: String,
    enum: ['info', 'warning', 'critical'],
    default: 'warning'
  },
  message: {
    type: String,
    required: true
  },
  value: {
    type: mongoose.Schema.Types.Mixed,
    default: null
  },
  acknowledged: {
    type: Boolean,
    default: false
  },
  acknowledgedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null
  },
  acknowledgedAt: {
    type: Date,
    default: null
  },
  notificationSent: {
    telegram: { type: Boolean, default: false },
    email: { type: Boolean, default: false }
  },
  createdAt: {
    type: Date,
    default: Date.now,
    index: true
  }
});

// Compound index for efficient queries
alertSchema.index({ deviceId: 1, createdAt: -1 });
alertSchema.index({ acknowledged: 1, createdAt: -1 });

const Alert = mongoose.model('Alert', alertSchema);

export default Alert;








