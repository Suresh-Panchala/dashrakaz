import mongoose from 'mongoose';

const deviceDataSchema = new mongoose.Schema({
  deviceId: {
    type: String,
    required: true,
    index: true
  },
  location: {
    type: String,
    required: true
  },
  timestamp: {
    type: Date,
    required: true,
    index: true
  },
  data: {
    // Hydrostatic and Level
    Hydrostatic_Value: { type: Number, default: 0 },
    
    // Alerts
    DryRunAlert: { type: Number, default: 0 },
    HighLevelFloatAlert: { type: Number, default: 0 },
    
    // Pump 1 Status
    Pump_1_Manual: { type: Number, default: 0 },
    Pump_1_Auto: { type: Number, default: 0 },
    Pump_1_Protection: { type: Number, default: 0 },
    Pump_1_Contactor_Feedback: { type: Number, default: 0 },
    
    // Pump 2 Status
    Pump_2_Manual: { type: Number, default: 0 },
    Pump_2_Auto: { type: Number, default: 0 },
    Pump_2_Protection: { type: Number, default: 0 },
    Pump_2_Contactor_Feedback: { type: Number, default: 0 },
    
    // Power Metrics - Pump 1
    POWER_1_R: { type: Number, default: 0 },
    POWER_1_Y: { type: Number, default: 0 },
    POWER_1_B: { type: Number, default: 0 },
    
    // Current Metrics - Pump 1
    IRMS_1_R: { type: Number, default: 0 },
    IRMS_1_Y: { type: Number, default: 0 },
    IRMS_1_B: { type: Number, default: 0 },
    
    // Power Metrics - Pump 2
    POWER_2_R: { type: Number, default: 0 },
    POWER_2_Y: { type: Number, default: 0 },
    POWER_2_B: { type: Number, default: 0 },
    
    // Current Metrics - Pump 2
    IRMS_2_R: { type: Number, default: 0 },
    IRMS_2_Y: { type: Number, default: 0 },
    IRMS_2_B: { type: Number, default: 0 },
    
    // Voltage Metrics - Pump 1
    VRMS_1_R: { type: Number, default: 0 },
    VRMS_1_Y: { type: Number, default: 0 },
    VRMS_1_B: { type: Number, default: 0 },
    
    // Voltage Metrics - Pump 2
    VRMS_2_R: { type: Number, default: 0 },
    VRMS_2_Y: { type: Number, default: 0 },
    VRMS_2_B: { type: Number, default: 0 },
    
    // Energy Metrics - Pump 1
    VAHR_1_R: { type: Number, default: 0 },
    VAHR_1_Y: { type: Number, default: 0 },
    VAHR_1_B: { type: Number, default: 0 },
    
    // Energy Metrics - Pump 2
    VAHR_2_R: { type: Number, default: 0 },
    VAHR_2_Y: { type: Number, default: 0 },
    VAHR_2_B: { type: Number, default: 0 },
    
    // Frequency Metrics - Pump 1
    FREQ_1_R: { type: Number, default: 0 },
    FREQ_1_Y: { type: Number, default: 0 },
    FREQ_1_B: { type: Number, default: 0 },
    
    // Frequency Metrics - Pump 2
    FREQ_2_R: { type: Number, default: 0 },
    FREQ_2_Y: { type: Number, default: 0 },
    FREQ_2_B: { type: Number, default: 0 },
    
    // RHS (Remote Hand Switch)
    RHS_1: { type: Number, default: 0 },
    RHS_2: { type: Number, default: 0 }
  },
  receivedAt: {
    type: Date,
    default: Date.now
  }
});

// Compound index for efficient queries
deviceDataSchema.index({ deviceId: 1, timestamp: -1 });

const DeviceData = mongoose.model('DeviceData', deviceDataSchema);

export default DeviceData;








