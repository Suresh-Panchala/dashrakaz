import mongoose from 'mongoose';

const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGODB_URI, {
      // Mongoose 8.x handles these options by default
    });

    console.log(`✅ MongoDB Connected: ${conn.connection.host}`);

    // Create indexes for better performance
    await createIndexes();

  } catch (error) {
    console.error(`❌ MongoDB Connection Error: ${error.message}`);
    process.exit(1);
  }
};

const createIndexes = async () => {
  try {
    const db = mongoose.connection.db;
    
    // Device Data indexes
    await db.collection('devicedata').createIndex({ deviceId: 1, timestamp: -1 });
    await db.collection('devicedata').createIndex({ timestamp: -1 });
    await db.collection('devicedata').createIndex({ deviceId: 1 });
    
    // Alerts indexes
    await db.collection('alerts').createIndex({ deviceId: 1, createdAt: -1 });
    await db.collection('alerts').createIndex({ acknowledged: 1, createdAt: -1 });
    
    // Devices indexes
    await db.collection('devices').createIndex({ deviceId: 1 }, { unique: true });
    await db.collection('devices').createIndex({ location: 1 });
    
    // Users indexes
    await db.collection('users').createIndex({ email: 1 }, { unique: true });
    await db.collection('users').createIndex({ username: 1 }, { unique: true });

    console.log('✅ Database indexes created');
  } catch (error) {
    console.error('❌ Error creating indexes:', error.message);
  }
};

export default connectDB;








