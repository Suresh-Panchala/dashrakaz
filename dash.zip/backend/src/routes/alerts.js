import express from 'express';
import { authenticate } from '../middleware/auth.js';
import { getAlerts, acknowledgeAlert } from '../services/alertService.js';
import Alert from '../models/Alert.js';

const router = express.Router();

// @route   GET /api/alerts
// @desc    Get alerts with filters
// @access  Private
router.get('/', authenticate, async (req, res) => {
  try {
    const {
      deviceId,
      acknowledged,
      severity,
      startDate,
      endDate,
      limit
    } = req.query;

    const filters = {};
    if (deviceId) filters.deviceId = deviceId;
    if (acknowledged !== undefined) filters.acknowledged = acknowledged === 'true';
    if (severity) filters.severity = severity;
    if (startDate) filters.startDate = startDate;
    if (endDate) filters.endDate = endDate;
    if (limit) filters.limit = parseInt(limit);

    const alerts = await getAlerts(filters);

    res.json({
      success: true,
      count: alerts.length,
      data: alerts
    });
  } catch (error) {
    console.error('Error fetching alerts:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching alerts'
    });
  }
});

// @route   GET /api/alerts/:id
// @desc    Get alert by ID
// @access  Private
router.get('/:id', authenticate, async (req, res) => {
  try {
    const alert = await Alert.findById(req.params.id)
      .populate('acknowledgedBy', 'username email');

    if (!alert) {
      return res.status(404).json({
        success: false,
        message: 'Alert not found'
      });
    }

    res.json({
      success: true,
      data: alert
    });
  } catch (error) {
    console.error('Error fetching alert:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching alert'
    });
  }
});

// @route   PUT /api/alerts/:id/acknowledge
// @desc    Acknowledge an alert
// @access  Private
router.put('/:id/acknowledge', authenticate, async (req, res) => {
  try {
    const alert = await acknowledgeAlert(req.params.id, req.user._id);

    if (!alert) {
      return res.status(404).json({
        success: false,
        message: 'Alert not found'
      });
    }

    res.json({
      success: true,
      data: alert
    });
  } catch (error) {
    console.error('Error acknowledging alert:', error);
    res.status(500).json({
      success: false,
      message: 'Error acknowledging alert'
    });
  }
});

// @route   GET /api/alerts/stats/summary
// @desc    Get alert statistics
// @access  Private
router.get('/stats/summary', authenticate, async (req, res) => {
  try {
    const { deviceId, days = 7 } = req.query;

    const startDate = new Date();
    startDate.setDate(startDate.getDate() - parseInt(days));

    const query = { createdAt: { $gte: startDate } };
    if (deviceId) query.deviceId = deviceId;

    const [total, bySeverity, byType, unacknowledged] = await Promise.all([
      Alert.countDocuments(query),
      Alert.aggregate([
        { $match: query },
        { $group: { _id: '$severity', count: { $sum: 1 } } }
      ]),
      Alert.aggregate([
        { $match: query },
        { $group: { _id: '$alertType', count: { $sum: 1 } } },
        { $sort: { count: -1 } },
        { $limit: 5 }
      ]),
      Alert.countDocuments({ ...query, acknowledged: false })
    ]);

    res.json({
      success: true,
      data: {
        total,
        unacknowledged,
        bySeverity: bySeverity.reduce((acc, item) => {
          acc[item._id] = item.count;
          return acc;
        }, {}),
        topAlertTypes: byType
      }
    });
  } catch (error) {
    console.error('Error fetching alert stats:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching alert statistics'
    });
  }
});

export default router;








