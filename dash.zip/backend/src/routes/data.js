import express from 'express';
import DeviceData from '../models/DeviceData.js';
import { authenticate } from '../middleware/auth.js';
import { dateRangeValidator, deviceIdValidator } from '../middleware/validators.js';
import { exportToCSV, exportToPDF } from '../services/exportService.js';

const router = express.Router();

// @route   GET /api/data/:deviceId
// @desc    Get device data with pagination
// @access  Private
router.get('/:deviceId', authenticate, deviceIdValidator, dateRangeValidator, async (req, res) => {
  try {
    const { deviceId } = req.params;
    const { 
      startDate, 
      endDate, 
      limit = 100, 
      page = 1,
      sortBy = 'timestamp',
      sortOrder = 'desc'
    } = req.query;

    const query = { deviceId };

    // Add date range filter
    if (startDate || endDate) {
      query.timestamp = {};
      if (startDate) {
        query.timestamp.$gte = new Date(startDate);
      }
      if (endDate) {
        query.timestamp.$lte = new Date(endDate);
      }
    }

    const skip = (parseInt(page) - 1) * parseInt(limit);
    const sort = { [sortBy]: sortOrder === 'asc' ? 1 : -1 };

    const [data, total] = await Promise.all([
      DeviceData.find(query)
        .sort(sort)
        .limit(parseInt(limit))
        .skip(skip)
        .lean(),
      DeviceData.countDocuments(query)
    ]);

    res.json({
      success: true,
      count: data.length,
      total,
      page: parseInt(page),
      pages: Math.ceil(total / parseInt(limit)),
      data
    });
  } catch (error) {
    console.error('Error fetching device data:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching device data'
    });
  }
});

// @route   GET /api/data/:deviceId/chart
// @desc    Get aggregated data for charts
// @access  Private
router.get('/:deviceId/chart', authenticate, deviceIdValidator, async (req, res) => {
  try {
    const { deviceId } = req.params;
    const { period = '24h', interval = '1h' } = req.query;

    const now = new Date();
    let startDate;
    let groupFormat;

    // Determine time range and grouping
    switch(period) {
      case '1h':
        startDate = new Date(now.getTime() - 60 * 60 * 1000);
        groupFormat = '%Y-%m-%d %H:%M';
        break;
      case '6h':
        startDate = new Date(now.getTime() - 6 * 60 * 60 * 1000);
        groupFormat = '%Y-%m-%d %H:00';
        break;
      case '24h':
        startDate = new Date(now.getTime() - 24 * 60 * 60 * 1000);
        groupFormat = '%Y-%m-%d %H:00';
        break;
      case '7d':
        startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        groupFormat = '%Y-%m-%d %H:00';
        break;
      case '30d':
        startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        groupFormat = '%Y-%m-%d';
        break;
      default:
        startDate = new Date(now.getTime() - 24 * 60 * 60 * 1000);
        groupFormat = '%Y-%m-%d %H:00';
    }

    const data = await DeviceData.aggregate([
      {
        $match: {
          deviceId,
          timestamp: { $gte: startDate }
        }
      },
      {
        $group: {
          _id: {
            $dateToString: { format: groupFormat, date: '$timestamp' }
          },
          avgHydrostatic: { $avg: '$data.Hydrostatic_Value' },
          avgVoltage1R: { $avg: '$data.VRMS_1_R' },
          avgVoltage1Y: { $avg: '$data.VRMS_1_Y' },
          avgVoltage1B: { $avg: '$data.VRMS_1_B' },
          avgVoltage2R: { $avg: '$data.VRMS_2_R' },
          avgVoltage2Y: { $avg: '$data.VRMS_2_Y' },
          avgVoltage2B: { $avg: '$data.VRMS_2_B' },
          avgCurrent1R: { $avg: '$data.IRMS_1_R' },
          avgCurrent1Y: { $avg: '$data.IRMS_1_Y' },
          avgCurrent1B: { $avg: '$data.IRMS_1_B' },
          avgCurrent2R: { $avg: '$data.IRMS_2_R' },
          avgCurrent2Y: { $avg: '$data.IRMS_2_Y' },
          avgCurrent2B: { $avg: '$data.IRMS_2_B' },
          pump1Status: { $last: '$data.Pump_1_Contactor_Feedback' },
          pump2Status: { $last: '$data.Pump_2_Contactor_Feedback' },
          timestamp: { $first: '$timestamp' }
        }
      },
      {
        $sort: { timestamp: 1 }
      }
    ]);

    res.json({
      success: true,
      count: data.length,
      data
    });
  } catch (error) {
    console.error('Error fetching chart data:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching chart data'
    });
  }
});

// @route   GET /api/data/:deviceId/export/csv
// @desc    Export device data as CSV
// @access  Private
router.get('/:deviceId/export/csv', authenticate, deviceIdValidator, async (req, res) => {
  try {
    const { deviceId } = req.params;
    const { startDate, endDate } = req.query;

    const csv = await exportToCSV(deviceId, startDate, endDate);

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="${deviceId}_${Date.now()}.csv"`);
    res.send(csv);
  } catch (error) {
    console.error('Error exporting CSV:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Error exporting data to CSV'
    });
  }
});

// @route   GET /api/data/:deviceId/export/pdf
// @desc    Export device data as PDF
// @access  Private
router.get('/:deviceId/export/pdf', authenticate, deviceIdValidator, async (req, res) => {
  try {
    const { deviceId } = req.params;
    const { startDate, endDate } = req.query;

    const pdfBuffer = await exportToPDF(deviceId, startDate, endDate);

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${deviceId}_${Date.now()}.pdf"`);
    res.send(pdfBuffer);
  } catch (error) {
    console.error('Error exporting PDF:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Error exporting data to PDF'
    });
  }
});

export default router;








