import express from 'express';
import Device from '../models/Device.js';
import DeviceData from '../models/DeviceData.js';
import { authenticate } from '../middleware/auth.js';
import { createDeviceValidator, deviceIdValidator } from '../middleware/validators.js';

const router = express.Router();

// @route   GET /api/devices
// @desc    Get all devices
// @access  Private
router.get('/', authenticate, async (req, res) => {
  try {
    const devices = await Device.find({ isActive: true })
      .sort({ createdAt: -1 });

    res.json({
      success: true,
      count: devices.length,
      data: devices
    });
  } catch (error) {
    console.error('Error fetching devices:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching devices'
    });
  }
});

// @route   GET /api/devices/:deviceId
// @desc    Get device by ID
// @access  Private
router.get('/:deviceId', authenticate, deviceIdValidator, async (req, res) => {
  try {
    const device = await Device.findOne({ 
      deviceId: req.params.deviceId,
      isActive: true 
    });

    if (!device) {
      return res.status(404).json({
        success: false,
        message: 'Device not found'
      });
    }

    res.json({
      success: true,
      data: device
    });
  } catch (error) {
    console.error('Error fetching device:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching device'
    });
  }
});

// @route   GET /api/devices/:deviceId/latest
// @desc    Get latest data for device
// @access  Private
router.get('/:deviceId/latest', authenticate, deviceIdValidator, async (req, res) => {
  try {
    const latestData = await DeviceData.findOne({ 
      deviceId: req.params.deviceId 
    })
    .sort({ timestamp: -1 });

    if (!latestData) {
      return res.status(404).json({
        success: false,
        message: 'No data found for this device'
      });
    }

    res.json({
      success: true,
      data: latestData
    });
  } catch (error) {
    console.error('Error fetching latest data:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching latest data'
    });
  }
});

// @route   GET /api/devices/:deviceId/stats
// @desc    Get device statistics
// @access  Private
router.get('/:deviceId/stats', authenticate, deviceIdValidator, async (req, res) => {
  try {
    const deviceId = req.params.deviceId;
    const { period = '24h' } = req.query;

    // Calculate time range
    const now = new Date();
    let startDate;
    
    switch(period) {
      case '1h':
        startDate = new Date(now.getTime() - 60 * 60 * 1000);
        break;
      case '6h':
        startDate = new Date(now.getTime() - 6 * 60 * 60 * 1000);
        break;
      case '24h':
        startDate = new Date(now.getTime() - 24 * 60 * 60 * 1000);
        break;
      case '7d':
        startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        break;
      case '30d':
        startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        break;
      default:
        startDate = new Date(now.getTime() - 24 * 60 * 60 * 1000);
    }

    const data = await DeviceData.find({
      deviceId,
      timestamp: { $gte: startDate }
    }).sort({ timestamp: 1 });

    if (data.length === 0) {
      return res.json({
        success: true,
        data: {
          count: 0,
          averages: {},
          min: {},
          max: {}
        }
      });
    }

    // Calculate statistics
    const stats = {
      count: data.length,
      averages: calculateAverages(data),
      min: calculateMin(data),
      max: calculateMax(data)
    };

    res.json({
      success: true,
      data: stats
    });
  } catch (error) {
    console.error('Error fetching device stats:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching device statistics'
    });
  }
});

// @route   POST /api/devices
// @desc    Create new device
// @access  Private/Admin
router.post('/', authenticate, createDeviceValidator, async (req, res) => {
  try {
    // Set device as online when manually added
    const deviceData = {
      ...req.body,
      status: 'online',
      lastSeen: new Date()
    };
    
    const device = new Device(deviceData);
    await device.save();

    res.status(201).json({
      success: true,
      data: device
    });
  } catch (error) {
    console.error('Error creating device:', error);
    res.status(500).json({
      success: false,
      message: 'Error creating device'
    });
  }
});

// @route   DELETE /api/devices/:deviceId
// @desc    Delete device (soft delete)
// @access  Private/Admin
router.delete('/:deviceId', authenticate, deviceIdValidator, async (req, res) => {
  try {
    const device = await Device.findOne({ 
      deviceId: req.params.deviceId,
      isActive: true 
    });

    if (!device) {
      return res.status(404).json({
        success: false,
        message: 'Device not found'
      });
    }

    // Soft delete - just mark as inactive
    device.isActive = false;
    await device.save();

    res.json({
      success: true,
      message: 'Device deleted successfully'
    });
  } catch (error) {
    console.error('Error deleting device:', error);
    res.status(500).json({
      success: false,
      message: 'Error deleting device'
    });
  }
});

// Helper functions
const calculateAverages = (data) => {
  const fields = [
    'Hydrostatic_Value',
    'VRMS_1_R', 'VRMS_1_Y', 'VRMS_1_B',
    'VRMS_2_R', 'VRMS_2_Y', 'VRMS_2_B',
    'IRMS_1_R', 'IRMS_1_Y', 'IRMS_1_B',
    'IRMS_2_R', 'IRMS_2_Y', 'IRMS_2_B',
    'FREQ_1_R', 'FREQ_2_R'
  ];

  const averages = {};
  
  fields.forEach(field => {
    const values = data.map(d => d.data[field]).filter(v => v !== null && v !== undefined);
    if (values.length > 0) {
      averages[field] = values.reduce((sum, val) => sum + val, 0) / values.length;
    }
  });

  return averages;
};

const calculateMin = (data) => {
  const fields = ['VRMS_1_R', 'VRMS_2_R', 'IRMS_1_R', 'IRMS_2_R'];
  const min = {};
  
  fields.forEach(field => {
    const values = data.map(d => d.data[field]).filter(v => v !== null && v !== undefined);
    if (values.length > 0) {
      min[field] = Math.min(...values);
    }
  });

  return min;
};

const calculateMax = (data) => {
  const fields = ['VRMS_1_R', 'VRMS_2_R', 'IRMS_1_R', 'IRMS_2_R', 'Hydrostatic_Value'];
  const max = {};
  
  fields.forEach(field => {
    const values = data.map(d => d.data[field]).filter(v => v !== null && v !== undefined);
    if (values.length > 0) {
      max[field] = Math.max(...values);
    }
  });

  return max;
};

export default router;





