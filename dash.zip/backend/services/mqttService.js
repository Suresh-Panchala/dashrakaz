const mqtt = require('mqtt');
const SensorData = require('../models/SensorData');
const Device = require('../models/Device');

class MQTTService {
  constructor() {
    this.client = null;
    this.isConnected = false;
  }

  connect(brokerUrl, options = {}) {
    console.log(`🔌 Connecting to MQTT broker: ${brokerUrl}`);
    
    const mqttOptions = {
      clean: true,
      connectTimeout: 4000,
      reconnectPeriod: 1000,
      ...options
    };

    // Add authentication if provided
    if (process.env.MQTT_USERNAME && process.env.MQTT_PASSWORD) {
      mqttOptions.username = process.env.MQTT_USERNAME;
      mqttOptions.password = process.env.MQTT_PASSWORD;
    }

    this.client = mqtt.connect(brokerUrl, mqttOptions);

    this.client.on('connect', () => {
      console.log('✅ Connected to MQTT broker');
      this.isConnected = true;
    });

    this.client.on('error', (error) => {
      console.error('❌ MQTT Error:', error);
      this.isConnected = false;
    });

    this.client.on('offline', () => {
      console.log('⚠️ MQTT client is offline');
      this.isConnected = false;
    });

    this.client.on('reconnect', () => {
      console.log('🔄 Reconnecting to MQTT broker...');
    });

    return this.client;
  }

  subscribe(topic, deviceId, deviceName) {
    if (!this.client) {
      console.error('❌ MQTT client not initialized');
      return;
    }

    this.client.subscribe(topic, (err) => {
      if (err) {
        console.error(`❌ Failed to subscribe to topic: ${topic}`, err);
      } else {
        console.log(`📡 Subscribed to topic: ${topic}`);
      }
    });

    this.client.on('message', async (receivedTopic, payload) => {
      if (receivedTopic === topic) {
        try {
          const data = JSON.parse(payload.toString());
          await this.saveToDatabase(data, deviceId, deviceName);
        } catch (error) {
          console.error('❌ Error processing MQTT message:', error);
        }
      }
    });
  }

  async saveToDatabase(data, deviceId, deviceName) {
    try {
      // Create sensor data document
      const sensorData = new SensorData({
        deviceId,
        deviceName,
        timestamp: new Date(),
        
        // Voltage values
        voltageR: data.VR || 0,
        voltageY: data.VY || 0,
        voltageB: data.VB || 0,
        
        // Current values
        currentR: data.CR || 0,
        currentY: data.CY || 0,
        currentB: data.CB || 0,
        
        // Power parameters
        kw: data.KW || 0,
        kva: data.KVA || 0,
        kvar: data.KVAR || 0,
        powerFactor: data.PF || 0,
        frequency: data.F || 0,
        
        // Pump status
        pump1: {
          manual: data.P1M || 0,
          auto: data.P1A || 0,
          rhs: data.P1RHS || 0
        },
        pump2: {
          manual: data.P2M || 0,
          auto: data.P2A || 0,
          rhs: data.P2RHS || 0
        },
        pump3: {
          manual: data.P3M || 0,
          auto: data.P3A || 0,
          rhs: data.P3RHS || 0
        },
        pump4: {
          manual: data.P4M || 0,
          auto: data.P4A || 0,
          rhs: data.P4RHS || 0
        }
      });

      // Save to database
      await sensorData.save();
      
      // Update device's last data received timestamp
      await Device.findOneAndUpdate(
        { deviceId },
        { 
          lastDataReceived: new Date(),
          isActive: true
        },
        { upsert: true }
      );

      console.log(`💾 Data saved for device: ${deviceName} at ${new Date().toISOString()}`);
      
    } catch (error) {
      console.error('❌ Error saving to database:', error);
    }
  }

  disconnect() {
    if (this.client) {
      this.client.end();
      console.log('🔌 Disconnected from MQTT broker');
    }
  }

  getConnectionStatus() {
    return this.isConnected;
  }
}

module.exports = new MQTTService();

