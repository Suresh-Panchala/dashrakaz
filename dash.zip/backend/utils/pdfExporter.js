const PDFDocument = require('pdfkit');

exports.exportToPDF = async (data, device, res) => {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument({ 
        size: 'A4',
        margins: { top: 50, bottom: 50, left: 50, right: 50 }
      });

      // Pipe to response
      doc.pipe(res);

      // Header
      doc.fontSize(20)
         .text('StormWater Monitoring Report', { align: 'center' })
         .moveDown(0.5);

      // Device Info
      doc.fontSize(12)
         .text(`Device: ${device?.name || 'Unknown'}`, { align: 'center' })
         .text(`Device ID: ${device?.deviceId || 'N/A'}`, { align: 'center' })
         .moveDown(0.3);

      // Date Range
      const startDate = new Date(data[0].timestamp).toLocaleString();
      const endDate = new Date(data[data.length - 1].timestamp).toLocaleString();
      doc.fontSize(10)
         .text(`Period: ${startDate} to ${endDate}`, { align: 'center' })
         .text(`Total Records: ${data.length}`, { align: 'center' })
         .moveDown(1);

      // Draw line
      doc.moveTo(50, doc.y)
         .lineTo(545, doc.y)
         .stroke()
         .moveDown(0.5);

      // Summary Statistics
      doc.fontSize(14)
         .text('Summary Statistics', { underline: true })
         .moveDown(0.5);

      // Calculate averages
      const avgVR = (data.reduce((sum, d) => sum + d.voltageR, 0) / data.length).toFixed(2);
      const avgVY = (data.reduce((sum, d) => sum + d.voltageY, 0) / data.length).toFixed(2);
      const avgVB = (data.reduce((sum, d) => sum + d.voltageB, 0) / data.length).toFixed(2);
      const avgKW = (data.reduce((sum, d) => sum + d.kw, 0) / data.length).toFixed(2);
      const avgPF = (data.reduce((sum, d) => sum + d.powerFactor, 0) / data.length).toFixed(2);

      doc.fontSize(10)
         .text(`Average Voltage R: ${avgVR} V`)
         .text(`Average Voltage Y: ${avgVY} V`)
         .text(`Average Voltage B: ${avgVB} V`)
         .text(`Average Power (KW): ${avgKW}`)
         .text(`Average Power Factor: ${avgPF}`)
         .moveDown(1);

      // Recent Data Table
      doc.fontSize(14)
         .text('Recent Data Points', { underline: true })
         .moveDown(0.5);

      // Table headers
      const tableTop = doc.y;
      const colWidth = 80;
      
      doc.fontSize(8);
      doc.text('Timestamp', 50, tableTop, { width: 100 });
      doc.text('VR', 150, tableTop, { width: colWidth });
      doc.text('VY', 210, tableTop, { width: colWidth });
      doc.text('VB', 270, tableTop, { width: colWidth });
      doc.text('KW', 330, tableTop, { width: colWidth });
      doc.text('PF', 390, tableTop, { width: colWidth });
      doc.text('Freq', 450, tableTop, { width: colWidth });

      // Draw line under headers
      doc.moveTo(50, tableTop + 15)
         .lineTo(545, tableTop + 15)
         .stroke();

      let y = tableTop + 20;
      const maxRows = 25; // Limit to prevent overflow

      // Add data rows (most recent 25)
      data.slice(-maxRows).forEach((row, index) => {
        if (y > 720) { // Check if we need a new page
          doc.addPage();
          y = 50;
        }

        const timestamp = new Date(row.timestamp).toLocaleTimeString();
        
        doc.text(timestamp, 50, y, { width: 100 });
        doc.text(row.voltageR.toFixed(1), 150, y, { width: colWidth });
        doc.text(row.voltageY.toFixed(1), 210, y, { width: colWidth });
        doc.text(row.voltageB.toFixed(1), 270, y, { width: colWidth });
        doc.text(row.kw.toFixed(2), 330, y, { width: colWidth });
        doc.text(row.powerFactor.toFixed(2), 390, y, { width: colWidth });
        doc.text(row.frequency.toFixed(1), 450, y, { width: colWidth });

        y += 15;
      });

      // Footer
      doc.fontSize(8)
         .text(
           `Generated on ${new Date().toLocaleString()} | StormWater Monitoring System`,
           50,
           750,
           { align: 'center', width: 495 }
         );

      // Finalize PDF
      doc.end();

      doc.on('finish', () => {
        resolve();
      });

      doc.on('error', (err) => {
        reject(err);
      });

    } catch (error) {
      reject(error);
    }
  });
};

