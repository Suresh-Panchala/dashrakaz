const express = require('express');
const router = express.Router();
const dataController = require('../controllers/dataController');

// Get latest data for a device
router.get('/latest/:deviceId', dataController.getLatestData);

// Get historical data with filters
router.get('/history/:deviceId', dataController.getHistoricalData);

// Get aggregated/statistical data
router.get('/stats/:deviceId', dataController.getStatistics);

// Get data for a specific date range
router.get('/range/:deviceId', dataController.getDateRangeData);

// Export data as CSV
router.get('/export/csv/:deviceId', dataController.exportCSV);

// Export data as PDF
router.get('/export/pdf/:deviceId', dataController.exportPDF);

// Get all devices
router.get('/devices', dataController.getAllDevices);

// Get device info
router.get('/device/:deviceId', dataController.getDeviceInfo);

module.exports = router;

