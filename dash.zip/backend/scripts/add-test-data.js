import mongoose from 'mongoose';
import DeviceData from '../src/models/DeviceData.js';
import Device from '../src/models/Device.js';
import dotenv from 'dotenv';

dotenv.config();

const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('✅ MongoDB connected');
  } catch (error) {
    console.error('❌ MongoDB connection error:', error);
    process.exit(1);
  }
};

const generateTestData = () => {
  const data = [];
  const now = new Date();
  
  // Generate 50 data points over the last 24 hours
  for (let i = 0; i < 50; i++) {
    const timestamp = new Date(now.getTime() - (i * 30 * 60 * 1000)); // Every 30 minutes
    
    data.push({
      deviceId: 'PUMP_001',
      location: 'Test Location',
      timestamp,
      data: {
        Hydrostatic_Value: 50 + Math.random() * 30,
        DryRunAlert: 0,
        HighLevelFloatAlert: 0,
        Pump_1_Manual: Math.random() > 0.5 ? 1 : 0,
        Pump_2_Manual: Math.random() > 0.5 ? 1 : 0,
        Pump_1_Auto: Math.random() > 0.5 ? 1 : 0,
        Pump_2_Auto: Math.random() > 0.5 ? 1 : 0,
        Pump_1_Protection: 0,
        Pump_2_Protection: 0,
        Pump_1_Contactor_Feedback: Math.random() > 0.5 ? 1 : 0,
        Pump_2_Contactor_Feedback: Math.random() > 0.5 ? 1 : 0,
        // Pump 1 parameters
        POWER_1_R: 220 + Math.random() * 20,
        POWER_1_Y: 218 + Math.random() * 20,
        POWER_1_B: 222 + Math.random() * 20,
        IRMS_1_R: 2.0 + Math.random() * 0.5,
        IRMS_1_Y: 2.1 + Math.random() * 0.5,
        IRMS_1_B: 1.9 + Math.random() * 0.5,
        VRMS_1_R: 228 + Math.random() * 6,
        VRMS_1_Y: 227 + Math.random() * 6,
        VRMS_1_B: 230 + Math.random() * 6,
        VAHR_1_R: 1200 + Math.random() * 100,
        VAHR_1_Y: 1210 + Math.random() * 100,
        VAHR_1_B: 1190 + Math.random() * 100,
        FREQ_1_R: 50,
        FREQ_1_Y: 50,
        FREQ_1_B: 50,
        // Pump 2 parameters
        POWER_2_R: 225 + Math.random() * 20,
        POWER_2_Y: 223 + Math.random() * 20,
        POWER_2_B: 227 + Math.random() * 20,
        IRMS_2_R: 1.8 + Math.random() * 0.5,
        IRMS_2_Y: 1.9 + Math.random() * 0.5,
        IRMS_2_B: 2.0 + Math.random() * 0.5,
        VRMS_2_R: 229 + Math.random() * 6,
        VRMS_2_Y: 228 + Math.random() * 6,
        VRMS_2_B: 227 + Math.random() * 6,
        VAHR_2_R: 1300 + Math.random() * 100,
        VAHR_2_Y: 1310 + Math.random() * 100,
        VAHR_2_B: 1290 + Math.random() * 100,
        FREQ_2_R: 50,
        FREQ_2_Y: 50,
        FREQ_2_B: 50,
        // Running hours
        RHS_1: Math.floor(1000 + i * 0.5),
        RHS_2: Math.floor(950 + i * 0.5),
      },
    });
  }
  
  return data;
};

const addTestData = async () => {
  try {
    await connectDB();
    
    // Register the device first
    console.log('📱 Registering device PUMP_001...');
    const existingDevice = await Device.findOne({ deviceId: 'PUMP_001' });
    
    if (!existingDevice) {
      await Device.create({
        deviceId: 'PUMP_001',
        name: 'Primary Pump Station',
        location: 'Test Location - Building A',
        status: 'online',
        isActive: true,
        lastSeen: new Date()
      });
      console.log('✅ Device PUMP_001 registered');
    } else {
      // Update last seen
      existingDevice.lastSeen = new Date();
      existingDevice.status = 'online';
      await existingDevice.save();
      console.log('✅ Device PUMP_001 already exists (updated status)');
    }
    
    console.log('🗑️  Clearing existing test data...');
    await DeviceData.deleteMany({ deviceId: 'PUMP_001' });
    
    console.log('📝 Generating test data...');
    const testData = generateTestData();
    
    console.log('💾 Inserting test data...');
    await DeviceData.insertMany(testData);
    
    console.log(`✅ Successfully added ${testData.length} test data points for PUMP_001`);
    console.log('📊 You can now:');
    console.log('   - View real-time data in Dashboard');
    console.log('   - View charts in Analytics page');
    console.log('   - Export data (CSV/PDF) from both pages');
    
    process.exit(0);
  } catch (error) {
    console.error('❌ Error adding test data:', error);
    process.exit(1);
  }
};

addTestData();

