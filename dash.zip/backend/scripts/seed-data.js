import mongoose from 'mongoose';
import dotenv from 'dotenv';

dotenv.config();

const DeviceSchema = new mongoose.Schema({
  deviceId: String,
  name: String,
  location: String,
  coordinates: {
    latitude: Number,
    longitude: Number
  },
  status: String,
  lastSeen: Date,
  isActive: Boolean,
  createdAt: Date
});

const DeviceDataSchema = new mongoose.Schema({
  deviceId: String,
  location: String,
  timestamp: Date,
  data: Object,
  receivedAt: Date
});

async function seedData() {
  try {
    console.log('\n===========================================');
    console.log('  Seeding Demo Data for StormWater System');
    console.log('===========================================\n');

    await mongoose.connect(process.env.MONGODB_URI);
    console.log('✓ Connected to MongoDB\n');

    const Device = mongoose.model('Device', DeviceSchema);
    const DeviceData = mongoose.model('DeviceData', DeviceDataSchema);

    // Clear existing demo data
    await Device.deleteMany({ deviceId: { $regex: /^Demo_/ } });
    await DeviceData.deleteMany({ deviceId: { $regex: /^Demo_/ } });

    console.log('Creating demo device...');

    // Create demo device
    const demoDevice = new Device({
      deviceId: 'StromWater_Device_1',
      name: 'Demo StormWater Pump Station',
      location: 'khusam',
      coordinates: {
        latitude: 25.2048,
        longitude: 55.2708
      },
      status: 'online',
      lastSeen: new Date(),
      isActive: true,
      createdAt: new Date()
    });

    await demoDevice.save();
    console.log('✓ Demo device created');

    console.log('Generating demo data points...');

    // Generate 100 data points over the last 24 hours
    const now = new Date();
    const dataPoints = [];

    for (let i = 0; i < 100; i++) {
      const timestamp = new Date(now - i * 14.4 * 60 * 1000); // Every ~14 minutes
      
      // Simulate varying data
      const hydrostaticValue = 30 + Math.random() * 40;
      const baseVoltage = 220 + Math.random() * 20;
      const baseCurrent = 1.5 + Math.random() * 2;
      
      dataPoints.push({
        deviceId: 'StromWater_Device_1',
        location: 'khusam',
        timestamp,
        data: {
          Hydrostatic_Value: hydrostaticValue,
          DryRunAlert: Math.random() > 0.95 ? 1 : 0,
          HighLevelFloatAlert: hydrostaticValue > 65 ? 1 : 0,
          Pump_1_Manual: Math.random() > 0.5 ? 1 : 0,
          Pump_2_Manual: 0,
          Pump_1_Auto: Math.random() > 0.5 ? 1 : 0,
          Pump_2_Auto: Math.random() > 0.5 ? 1 : 0,
          Pump_1_Protection: 0,
          Pump_2_Protection: 0,
          Pump_1_Contactor_Feedback: Math.random() > 0.3 ? 1 : 0,
          Pump_2_Contactor_Feedback: Math.random() > 0.6 ? 1 : 0,
          POWER_1_R: baseVoltage,
          POWER_1_Y: baseVoltage - 2,
          POWER_1_B: baseVoltage + 1,
          IRMS_1_R: baseCurrent,
          IRMS_1_Y: baseCurrent + 0.1,
          IRMS_1_B: baseCurrent - 0.1,
          POWER_2_R: baseVoltage,
          POWER_2_Y: baseVoltage - 1,
          POWER_2_B: baseVoltage + 2,
          IRMS_2_R: baseCurrent,
          IRMS_2_Y: baseCurrent + 0.2,
          IRMS_2_B: baseCurrent - 0.2,
          VRMS_1_R: baseVoltage,
          VRMS_1_Y: baseVoltage - 2,
          VRMS_1_B: baseVoltage + 1,
          VRMS_2_R: baseVoltage,
          VRMS_2_Y: baseVoltage - 1,
          VRMS_2_B: baseVoltage + 2,
          VAHR_1_R: 1000 + i * 10,
          VAHR_1_Y: 1020 + i * 10,
          VAHR_1_B: 980 + i * 10,
          VAHR_2_R: 1100 + i * 10,
          VAHR_2_Y: 1120 + i * 10,
          VAHR_2_B: 1080 + i * 10,
          FREQ_1_R: 50,
          FREQ_1_Y: 50,
          FREQ_1_B: 50,
          FREQ_2_R: 50,
          FREQ_2_Y: 50,
          FREQ_2_B: 50,
          RHS_1: 1,
          RHS_2: 0
        },
        receivedAt: timestamp
      });
    }

    await DeviceData.insertMany(dataPoints);
    console.log(`✓ Created ${dataPoints.length} demo data points`);

    console.log('\n✅ Demo data seeded successfully!\n');
    console.log('You can now view the data in the dashboard.\n');

  } catch (error) {
    console.error('❌ Error seeding data:', error.message);
  } finally {
    await mongoose.disconnect();
    process.exit(0);
  }
}

seedData();








