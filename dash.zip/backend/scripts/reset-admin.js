import mongoose from 'mongoose';
import bcrypt from 'bcrypt';
import dotenv from 'dotenv';

dotenv.config();

const UserSchema = new mongoose.Schema({
  username: String,
  email: String,
  password: String,
  role: String,
  isActive: Boolean,
  createdAt: Date
});

async function resetAdmin() {
  try {
    console.log('\n===========================================');
    console.log('  Resetting Admin User');
    console.log('===========================================\n');

    // Connect to MongoDB
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('✓ Connected to MongoDB\n');

    const User = mongoose.model('User', UserSchema);

    // Delete existing admin user
    await User.deleteOne({ username: 'admin' });
    console.log('✓ Removed old admin user (if existed)\n');

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash('admin123', salt);

    // Create new admin user
    const adminUser = new User({
      username: 'admin',
      email: 'admin@stormwater.com',
      password: hashedPassword,
      role: 'admin',
      isActive: true,
      createdAt: new Date()
    });

    await adminUser.save();

    console.log('✅ Admin user created successfully!\n');
    console.log('Login credentials:');
    console.log('  Username: admin');
    console.log('  Password: admin123\n');
    console.log('===========================================\n');

  } catch (error) {
    console.error('❌ Error:', error.message);
  } finally {
    await mongoose.disconnect();
    process.exit(0);
  }
}

resetAdmin();




